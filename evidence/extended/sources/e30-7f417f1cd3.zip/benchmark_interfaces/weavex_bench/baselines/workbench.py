"""Small persistent private/shared text workspace for the comparator."""

from collections import defaultdict
from pathlib import PurePosixPath


class Workbench:
    def __init__(self):
        self.private = defaultdict(dict)
        self.shared = {}
        self.subscriptions = defaultdict(set)
        self.notices = []
        self.version = 0
        self.history = []

    @staticmethod
    def path(path):
        if (
            not isinstance(path, str)
            or "\\" in path
            or ".." in PurePosixPath(path).parts
        ):
            raise PermissionError("use canonical /private/ or /shared/ paths")
        if not (path.startswith("/private/") or path.startswith("/shared/")):
            raise PermissionError(
                "only this session's /private/ and /shared/ are accessible"
            )
        if str(PurePosixPath(path)) != path.rstrip("/"):
            raise PermissionError("noncanonical path")
        return path

    def files(self, actor):
        return {**self.private[actor], **self.shared}

    def write(self, actor, path, content):
        self.path(path)
        if not isinstance(content, str) or len(content.encode()) > 65536:
            raise ValueError("file must be UTF-8 text up to 64 KiB")
        store = self.private[actor] if path.startswith("/private/") else self.shared
        prospective = {**self.files(actor), path: content}
        if sum(len(v.encode()) for v in prospective.values()) > 262144:
            raise ValueError("workspace exceeds 256 KiB")
        if store.get(path) == content:
            return
        store[path] = content
        self.version += 1
        self.history.append(
            {"actor": actor, "path": path, "version": self.version, "content": content}
        )
        if path.startswith("/shared/"):
            for watcher, prefixes in self.subscriptions.items():
                if watcher != actor and any(path.startswith(p) for p in prefixes):
                    self.notices.append(
                        (
                            watcher,
                            {
                                "kind": "shared_file_change",
                                "path": path,
                                "version": self.version,
                                "writer": actor,
                            },
                        )
                    )

    def workspace(self, actor, operation, path, content="", query=""):
        self.path(path)
        files = self.files(actor)
        if operation == "read":
            return {"path": path, "content": files[path], "version": self.version}
        if operation == "write":
            self.write(actor, path, content)
            return {"path": path, "version": self.version}
        if operation in ("list", "search"):
            return {
                p: (c if operation == "search" else len(c))
                for p, c in files.items()
                if p.startswith(path)
                and (operation != "search" or query in c or query in p)
            }
        if operation == "subscribe":
            if not path.startswith("/shared/"):
                raise ValueError("only shared files require subscriptions")
            self.subscriptions[actor].add(path)
            return {"subscribed": path, "version": self.version}
        raise ValueError("unknown workspace operation")
