"""Persistent single-agent or supervisor/worker comparator over a task Session."""

import asyncio
from collections import deque
from time import perf_counter
from jsonschema import Draft202012Validator
from openai import (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    InternalServerError,
)
from ..contracts import SessionStopped, RunResult
from ..reporting import dumps, save_json
from ..weavex.task_gateway import tool_name


def function(name, description, properties=None, required=()):
    return {
        "type": "function",
        "function": {
            "name": name,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties or {},
                "required": list(required),
                "additionalProperties": False,
            },
        },
    }


SEND = function(
    "team_send",
    "Send or reassign work, report results or proactively raise a gap. Recipient has a persistent private session. Delivery wakes it.",
    {"recipient": {"type": "string"}, "content": {"type": "string"}},
    ("recipient", "content"),
)
YIELD = function(
    "team_yield",
    "Park until the next message or subscribed file change. Outstanding work remains in your private history.",
)
REPORT = function(
    "user_report",
    "Deliver a completed stage report to the external user, respecting their reporting constraints.",
    {"content": {"type": "string"}},
    ("content",),
)


class PersistentParticipant:
    def __init__(
        self,
        session,
        recorder,
        *,
        client,
        model,
        max_tokens,
        system="supervisor",
        roles=None,
    ):
        self.session, self.recorder, self.client, self.model = (
            session,
            recorder,
            client,
            model,
        )
        self.max_tokens = max_tokens
        if system not in {"single", "supervisor"}:
            raise ValueError("Unknown comparator")
        if system == "supervisor" and not roles:
            raise ValueError("A supervisor run requires explicit generic colleagues")
        self.entry = "supervisor" if system == "supervisor" else "single"
        self.actors = {
            self.entry: "Resolve the external user task with all available tools."
        }
        if system == "supervisor":
            self.actors.update(roles)
            self.actors[self.entry] = (
                "Coordinate persistent domain workers, delegate/reassign work and integrate evidence. "
                "You may also execute business tools yourself. Workers can report new gaps proactively."
            )
        self.dialogues, self.inboxes = {}, {a: [] for a in self.actors}
        self.ready = deque()
        self.outputs = []
        self.transport_failures = {}
        self.specs = {tool_name(s.name): s for s in session.tools()}
        for actor, purpose in self.actors.items():
            self.dialogues[actor] = [
                {
                    "role": "system",
                    "content": session.instructions
                    + "\n"
                    + purpose
                    + "\nTeam identities: "
                    + ", ".join(self.actors)
                    + "\nEvery colleague retains its own history. Messages are delivered at the next model boundary. "
                    "Your tool results are private until you send or publish them. You may send new concerns without being asked. "
                    "Use team_yield to suspend when no useful work remains; yielding does not erase memory.",
                }
            ]

    def wake(self, actor, content):
        if actor not in self.actors:
            raise ValueError("Unknown team recipient")
        self.inboxes[actor].append(content)
        if actor not in self.ready:
            self.ready.append(actor)

    def tools(self, actor):
        specs = list(self.specs.values())
        result = [function(tool_name(s.name), s.description) for s in specs]
        for tool, spec in zip(result, specs):
            tool["function"]["parameters"] = spec.parameters
        result += [YIELD]
        if len(self.actors) > 1:
            result += [SEND]
        if actor == self.entry:
            result += [REPORT]
        return result

    async def poll(self):
        for event in await self.session.poll():
            self.recorder.emit(
                "baseline.input",
                actor_id=self.entry,
                event=event,
                simulated_time=self.session.now(),
            )
            if event.kind == "stop":
                raise SessionStopped(event.content)
            if event.attachments:
                raise TypeError("Direct multimodal input unsupported")
            self.wake(self.entry, dumps(event))
        if hasattr(self.session, "file_notices"):
            for actor, notice in self.session.file_notices():
                if actor in self.actors:
                    self.wake(actor, dumps(notice))

    async def round(self, actor):
        messages = self.dialogues[actor]
        if self.inboxes[actor]:
            messages.append({"role": "user", "content": "\n".join(self.inboxes[actor])})
            self.inboxes[actor] = []
        schemas = self.tools(actor)
        self.session.before_model()
        self.recorder.emit(
            "model.request",
            actor_id=actor,
            messages=messages.copy(),
            tools=schemas,
            model=self.model,
            max_tokens=self.max_tokens,
            simulated_time=self.session.now(),
        )
        start, usage, error = perf_counter(), None, ""
        try:
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=schemas,
                tool_choice="auto",
                parallel_tool_calls=False,
                max_tokens=self.max_tokens,
                extra_body={"thinking": {"type": "enabled"}},
                stream=False,
            )
            usage = response.usage.model_dump() if response.usage else None
            message = response.choices[0].message.model_dump(exclude_none=True)
            self.recorder.emit(
                "model.raw_response",
                actor_id=actor,
                message=message,
                finish_reason=getattr(response.choices[0], "finish_reason", None),
            )
            # Keep native reasoning/tool call transport, but no API-only metadata.
            message = {
                k: v
                for k, v in message.items()
                if k in {"role", "content", "tool_calls", "reasoning_content"}
            }
            messages.append(message)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            seconds = perf_counter() - start
            self.session.after_model(seconds)
            self.recorder.emit(
                "model.result",
                actor_id=actor,
                seconds=seconds,
                usage=usage,
                error=error,
                simulated_time=self.session.now(),
            )
        calls = message.get("tool_calls") or []
        if len(calls) != 1:
            if not calls:
                messages.append(
                    {
                        "role": "user",
                        "content": "No tool was called and no external effect occurred. Use a task tool, "
                        "user_report for an authorized report, or team_yield to wait for input.",
                    }
                )
                if actor not in self.ready:
                    self.ready.append(actor)
                return
            self.recorder.emit(
                "model.extra_proposals",
                actor_id=actor,
                deferred=calls[1:],
                simulated_time=self.session.now(),
            )
        call = calls[0]
        name, call_id = call["function"]["name"], call["id"]
        parked = False
        try:
            import json

            args = json.loads(call["function"]["arguments"])
            schema = next(
                t["function"]["parameters"]
                for t in schemas
                if t["function"]["name"] == name
            )
            Draft202012Validator(schema).validate(args)
            if name == "team_send":
                self.wake(
                    args["recipient"],
                    dumps({"sender": actor, "content": args["content"]}),
                )
                self.recorder.emit(
                    "team.message",
                    sender=actor,
                    **args,
                    simulated_time=self.session.now(),
                )
                result = {"delivered": True}
            elif name == "team_yield":
                parked, result = True, {"parked": True}
            elif name == "user_report":
                result = await self.session.send(args["content"], call_id)
                self.recorder.emit(
                    "output.delivery", result=result, simulated_time=self.session.now()
                )
                if result.status == "unknown":
                    raise SessionStopped(result.error)
                if result.status == "ok":
                    self.outputs.append(args["content"])
            else:
                spec = self.specs[name]
                if spec.waits_for_input and self.ready:
                    result = {
                        "error": "Other team work is runnable. Yield or continue useful work before waiting."
                    }
                else:
                    self.recorder.emit(
                        "task.request",
                        actor_id=actor,
                        call_id=call_id,
                        tool=spec.name,
                        write=spec.write,
                        arguments=args,
                        simulated_time=self.session.now(),
                    )
                    if hasattr(self.session, "call_for_actor"):
                        result = await self.session.call_for_actor(
                            actor, spec.name, args
                        )
                    else:
                        result = await self.session.call(spec.name, args)
                    self.recorder.emit(
                        "task.result",
                        actor_id=actor,
                        call_id=call_id,
                        tool=spec.name,
                        status=result.status,
                        value=result.value,
                        error=result.error,
                        simulated_time=self.session.now(),
                    )
                    if result.status == "unknown":
                        raise SessionStopped(result.error)
        except SessionStopped:
            raise
        except Exception as exc:
            result = {"error": f"{type(exc).__name__}: {exc}"}
            self.recorder.emit(
                "baseline.tool_rejected", actor_id=actor, tool=name, error=str(exc)
            )
        messages.append(
            {"role": "tool", "tool_call_id": call_id, "content": dumps(result)}
        )
        for extra in calls[1:]:
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": extra["id"],
                    "content": dumps(
                        {
                            "error": "Not executed: this participant executes one proposed tool per round. Resubmit if still needed."
                        }
                    ),
                }
            )
        if not parked and actor not in self.ready:
            self.ready.append(actor)

    async def run(self):
        status, error = "environment_stopped", ""
        try:
            while True:
                await self.poll()
                if self.ready:
                    actor = self.ready.popleft()
                    try:
                        await self.round(actor)
                        self.transport_failures[actor] = 0
                    except (
                        APIConnectionError,
                        APITimeoutError,
                        RateLimitError,
                        InternalServerError,
                    ) as exc:
                        failures = self.transport_failures.get(actor, 0) + 1
                        self.transport_failures[actor] = failures
                        if failures > 2:
                            raise
                        self.dialogues[actor].append(
                            {
                                "role": "user",
                                "content": "The model request failed in transport; no tool proposal was executed. "
                                "Time and the attempt were counted. Reconsider current input before acting.",
                            }
                        )
                        self.recorder.emit(
                            "transport.retry",
                            actor_id=actor,
                            attempt=failures,
                            error=str(exc),
                            simulated_time=self.session.now(),
                        )
                        if actor not in self.ready:
                            self.ready.append(actor)
                else:
                    await self.session.idle()
        except SessionStopped as exc:
            error = str(exc)
            if not getattr(self.session, "stopped", False):
                status = "execution_failed"
        except asyncio.CancelledError:
            status, error = "interrupted", "Participant cancelled"
            raise
        except Exception as exc:
            status, error = "execution_failed", f"{type(exc).__name__}: {exc}"
            raise
        finally:
            if self.recorder.directory:
                save_json(
                    self.recorder.directory / "team-state.json",
                    {
                        "actors": self.actors,
                        "inboxes": self.inboxes,
                        "ready": list(self.ready),
                        "dialogues": self.dialogues,
                    },
                )
            self.recorder.emit(
                "participant.finished",
                status=status,
                error=error,
                usage=self.recorder.usage(),
            )
        return RunResult(
            status, self.outputs, error, self.recorder.usage()["model_calls"]
        )
