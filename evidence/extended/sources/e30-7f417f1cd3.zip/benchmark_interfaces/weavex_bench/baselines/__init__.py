"""Controlled persistent participants; independent of WeaveX internals."""
