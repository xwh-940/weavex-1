"""Model-facing learning session; hidden kinetics stay outside its projections."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from ..contracts import InputEnvelope, SessionStopped, TaskToolSpec, ToolResult
from .learning_physics import (
    CONDITIONS,
    LearningPhysics,
    condition_table,
    transition_records,
)


def schema(
    properties: dict[str, Any], required: list[str] | None = None
) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties if required is None else required),
        "additionalProperties": False,
    }


@dataclass
class LearningBudget:
    max_requests: int = 40
    max_total_tokens: int = 600_000
    max_experiment_batches: int = 4
    experiment_replicas: int = 16


INSTRUCTIONS = """You are participating in a controlled kinetic Ising learning study.
Your task is to form a calibrated, executable conditional probability table from the
authorized transition records and limited new experiments, then use it on a new batch
and revise it only if the returned finite-sample evidence warrants doing so. The exact
transition formula and numerical parameters are not supplied by the apparatus.

The lattice is a periodic 8 by 8 square with binary spins. Coordinates, time labels,
and the fact that one colour of a checkerboard is updated at a time are public. A record
contains a site's spin before its own update, the sum of its four nearest neighbours,
and its spin after the update. It is legitimate to use prior physical knowledge as a
hypothesis, but a claim about this apparatus must be grounded in the records or in a
new finite experiment. Random outcomes are not oracle probabilities.

Two Agents begin with different authorized spatial projections of the same apparatus.
The candidate author receives the learning and feedback notices; the other Agent receives
the learn candidate only when it is ready for fresh use. You may communicate, organize
evidence, and decide whether a candidate deserves revision.
When the apparatus says that another position owns the learning stage, yield and wait for
the candidate-use notice; the host will reject attempts to access the holder's training stage.
The Broker may organize sourced questions but cannot operate the apparatus or read hidden
physical state. Do not assume that a notice proves another Agent adopted a candidate.

The external tools record actual effects. A valid candidate is a full table over the
ten public (center_before, neighbor_sum) conditions; it will be executed exactly as
submitted for the later use batch. Candidate stages are measurement labels, not a
required cognitive sequence: baseline records a pre-data reference; learn freezes a
candidate before use; revision records a post-use version. The final outward answer
should state what was predicted, what evidence was used, and whether the use result
changed or confirmed the candidate.

Use the conditional summary for ordinary estimation. Raw records are available in
fixed pages when their replica/time identity matters; do not repeatedly request
large raw pages merely to recreate the summary.
""".strip()


class LearningSession:
    scope = "ising-learning-prototype-v1"
    instructions = INSTRUCTIONS

    def __init__(
        self,
        *,
        seed: int,
        physics: LearningPhysics,
        recorder,
        budget: LearningBudget | None = None,
    ):
        self.seed, self.physics, self.recorder = seed, physics, recorder
        self.budget = budget or LearningBudget()
        self.stopped = False
        self.stop_reason = ""
        self._time = 0.0
        self._idle = 0
        self.phase = "baseline"
        self.model_requests = 0
        self.experiment_batches = 0
        self.notices: list[tuple[str, dict[str, Any]]] = []
        self.interface_questions: dict[str, str] = {}
        self.candidates: dict[str, dict[str, Any]] = {}
        self.candidate_author: dict[str, str] = {}
        self.stage_candidates: dict[str, str] = {}
        self.learning_owner: str = ""
        self.used_by: str = ""
        self.outputs: list[dict[str, Any]] = []
        records = transition_records(seed + 100, physics, replicas=8)
        # Fixed spatial projections.  Raw records include shared replica/time identity.
        self.training = {
            "agent-left": [row for row in records if row["x"] < physics.size // 2],
            "agent-right": [row for row in records if row["x"] >= physics.size // 2],
        }
        self.usage_records = transition_records(seed + 200, physics, replicas=32)
        self.final_records = transition_records(seed + 300, physics, replicas=128)

    def bind_interface_questions(self, values: dict[str, str]) -> None:
        self.interface_questions = dict(values)

    def now(self) -> float:
        return self._time

    def _status(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "candidate_stages": dict(self.stage_candidates),
            "learning_owner": self.learning_owner or None,
            "experiment_batches_remaining": self.budget.max_experiment_batches
            - self.experiment_batches,
            "model_requests_remaining": self.budget.max_requests - self.model_requests,
            "post_use_requests_reserved": 10,
        }

    def tools(self) -> tuple[TaskToolSpec, ...]:
        table_entry = {
            "type": "object",
            "properties": {
                "center_before": {"type": "integer", "enum": [-1, 1]},
                "neighbor_sum": {"type": "integer", "enum": [-4, -2, 0, 2, 4]},
                "p_plus": {"type": "number", "minimum": 0, "maximum": 1},
            },
            "required": ["center_before", "neighbor_sum", "p_plus"],
            "additionalProperties": False,
        }
        return (
            TaskToolSpec(
                "inspect_study",
                "Read the public study state and remaining allowances.",
                schema({}),
                False,
            ),
            TaskToolSpec(
                "read_training_records",
                "Read this Agent's authorized transition data. The generic conditional summary is compact; raw data is limited to a fixed page.",
                schema(
                    {
                        "view": {"type": "string", "enum": ["raw", "summary"]},
                        "offset": {"type": "integer", "minimum": 0},
                    },
                    required=["view"],
                ),
                False,
            ),
            TaskToolSpec(
                "run_experiment_batch",
                "Spend one shared batch of 16 independent random-start trajectories. The generic conditional summary is compact; raw data is limited to a fixed page.",
                schema(
                    {
                        "view": {"type": "string", "enum": ["raw", "summary"]},
                        "offset": {"type": "integer", "minimum": 0},
                    },
                    required=["view"],
                ),
                True,
            ),
            TaskToolSpec(
                "submit_candidate",
                "Freeze an executable full conditional probability table for the indicated external measurement stage.",
                schema(
                    {
                        "stage": {
                            "type": "string",
                            "enum": ["baseline", "learn", "revision"],
                        },
                        "entries": {
                            "type": "array",
                            "minItems": 10,
                            "maxItems": 10,
                            "items": table_entry,
                        },
                    }
                ),
                True,
            ),
            TaskToolSpec(
                "use_candidate",
                "A non-author actually uses the frozen learn candidate on a fresh finite batch; returns predicted and observed conditional frequencies.",
                schema({"candidate_id": {"type": "string"}}),
                True,
            ),
            TaskToolSpec(
                "deliver_study",
                "Deliver the final study account outward after a revision candidate is frozen.",
                schema(
                    {"report": {"type": "string", "minLength": 1, "maxLength": 8000}}
                ),
                True,
            ),
        )

    def _validate_entries(
        self, entries: list[dict[str, Any]]
    ) -> dict[tuple[int, int], float]:
        table = {
            (int(item["center_before"]), int(item["neighbor_sum"])): float(
                item["p_plus"]
            )
            for item in entries
        }
        if len(table) != len(CONDITIONS) or set(table) != set(CONDITIONS):
            raise ValueError(
                "entries must contain every one of the ten distinct public conditions exactly once"
            )
        return table

    def _candidate_payload(self, candidate_id: str) -> dict[str, Any]:
        values = self.candidates[candidate_id]
        return {
            "candidate_id": candidate_id,
            "stage": values["stage"],
            "entries": values["entries"],
            "author": self.candidate_author[candidate_id],
        }

    def _predict(
        self, candidate_id: str, records: list[dict[str, int]]
    ) -> list[dict[str, Any]]:
        table = self.candidates[candidate_id]["table"]
        result = []
        for center, neighbour_sum in CONDITIONS:
            matching = [
                r
                for r in records
                if (r["center_before"], r["neighbor_sum"]) == (center, neighbour_sum)
            ]
            if matching:
                predicted = table[(center, neighbour_sum)]
                observed = float(np.mean([r["spin_after"] == 1 for r in matching]))
                result.append(
                    {
                        "center_before": center,
                        "neighbor_sum": neighbour_sum,
                        "count": len(matching),
                        "predicted_p_plus": predicted,
                        "observed_p_plus": observed,
                        "squared_error": (predicted - observed) ** 2,
                    }
                )
        return result

    def _queue_notice(self, actor_id: str, content: dict[str, Any]) -> None:
        self.notices.append((actor_id, content))

    @staticmethod
    def _project_records(rows: list[dict[str, int]], arguments: dict[str, Any]) -> Any:
        if arguments["view"] == "summary":
            return condition_table(rows)
        offset = arguments.get("offset", 0)
        page = rows[offset : offset + 64]
        return {
            "records": page,
            "offset": offset,
            "returned": len(page),
            "total_authorized_records": len(rows),
            "next_offset": offset + len(page)
            if offset + len(page) < len(rows)
            else None,
        }

    def file_notices(self):
        values, self.notices = self.notices, []
        for actor_id, payload in values:
            yield (
                actor_id,
                {
                    "interface_question_id": self.interface_questions.get(actor_id, ""),
                    **payload,
                },
            )

    async def poll(self) -> list[InputEnvelope]:
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        return []

    async def idle(self) -> None:
        self._idle += 1
        if self._idle >= 2:
            self.stop("idle_before_final_delivery")
            raise SessionStopped(self.stop_reason)

    def stop(self, reason: str) -> None:
        self.stopped, self.stop_reason = True, reason
        self.recorder.emit("ising_learning.stopped", reason=reason, phase=self.phase)

    def before_model(self) -> None:
        usage = self.recorder.usage()
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        if self.model_requests >= self.budget.max_requests:
            self.stop("model_request_limit")
            raise SessionStopped(self.stop_reason)
        if (
            usage["prompt_tokens"] + usage["completion_tokens"]
            >= self.budget.max_total_tokens
        ):
            self.stop("reported_token_limit")
            raise SessionStopped(self.stop_reason)
        self.model_requests += 1
        self._idle = 0

    def after_model(self, seconds: float) -> None:
        return None

    async def call(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        return ToolResult("error", error="Actor identity is required")

    async def call_for_actor(
        self,
        actor_id: str,
        name: str,
        arguments: dict[str, Any],
        *,
        question_id: str | None = None,
    ) -> ToolResult:
        if self.stopped:
            return ToolResult("error", error="Session has stopped")
        if actor_id not in self.training:
            return ToolResult(
                "error", error="Broker cannot inspect or operate the physical study"
            )
        try:
            if name == "inspect_study":
                return ToolResult("ok", self._status())
            if name == "read_training_records":
                if self.phase == "baseline":
                    raise ValueError(
                        "freeze a baseline candidate before opening training records"
                    )
                if actor_id != self.learning_owner:
                    raise ValueError(
                        "another position owns the learning stage; yield and wait for the candidate-use notice"
                    )
                rows = self.training[actor_id]
                return ToolResult("ok", self._project_records(rows, arguments))
            if name == "run_experiment_batch":
                if self.phase == "baseline":
                    raise ValueError(
                        "freeze a baseline candidate before running new experiments"
                    )
                if actor_id != self.learning_owner:
                    raise ValueError(
                        "another position owns the learning stage; yield and wait for the candidate-use notice"
                    )
                if self.experiment_batches >= self.budget.max_experiment_batches:
                    raise ValueError("shared experiment allowance exhausted")
                if self.phase not in {"baseline", "learn", "use"}:
                    raise ValueError(
                        "new experiments close after the revision stage begins"
                    )
                batch = self.experiment_batches
                self.experiment_batches += 1
                rows = transition_records(
                    self.seed + 1000 + batch,
                    self.physics,
                    replicas=self.budget.experiment_replicas,
                )
                rows = [
                    row
                    for row in rows
                    if (row["x"] < self.physics.size // 2) == (actor_id == "agent-left")
                ]
                return ToolResult(
                    "ok",
                    {
                        "batch": batch + 1,
                        "projection": self._project_records(rows, arguments),
                        "shared_batches_remaining": self.budget.max_experiment_batches
                        - self.experiment_batches,
                    },
                )
            if name == "submit_candidate":
                stage = arguments["stage"]
                valid = {"baseline": "baseline", "learn": "learn", "revision": "use"}
                if self.phase != valid[stage]:
                    raise ValueError(
                        f"stage {stage} is unavailable while study phase is {self.phase}"
                    )
                if stage in self.stage_candidates:
                    raise ValueError(f"stage {stage} already has a frozen candidate")
                if stage in {"learn", "revision"} and actor_id != self.learning_owner:
                    raise ValueError(
                        "only the current learning position may freeze this stage"
                    )
                if stage == "revision" and not self.used_by:
                    raise ValueError(
                        "a different Agent must execute the new-use batch before revision"
                    )
                table = self._validate_entries(arguments["entries"])
                candidate_id = f"W{len(self.candidates)}"
                self.candidates[candidate_id] = {
                    "stage": stage,
                    "entries": arguments["entries"],
                    "table": table,
                }
                self.candidate_author[candidate_id] = actor_id
                self.stage_candidates[stage] = candidate_id
                next_action = ""
                if stage == "baseline":
                    self.phase = "learn"
                    self.learning_owner = actor_id
                    event = {
                        "kind": "learning_stage_open",
                        "content": "A pre-data reference is frozen. Authorized training records and finite experiments are now available.",
                        "status": self._status(),
                    }
                    self._queue_notice(actor_id, event)
                    next_action = (
                        "The baseline is frozen and you own the learning stage. Read the authorized "
                        "training summary or run a finite experiment before deciding whether to freeze W1."
                    )
                    for target in self.training:
                        if target != actor_id:
                            self._queue_notice(
                                target,
                                {
                                    "kind": "await_learning_candidate",
                                    "content": "Another position owns the learning stage. Yield and wait for a candidate-use notice; training tools are unavailable to you in this stage.",
                                    "status": self._status(),
                                },
                            )
                elif stage == "learn":
                    self.phase = "use"
                    event = {
                        "kind": "candidate_ready_for_new_use",
                        "candidate": self._candidate_payload(candidate_id),
                        "content": "A learn-stage candidate is frozen. A different Agent may now use this exact candidate on a new finite batch.",
                        "status": self._status(),
                    }
                    for target in self.training:
                        if target != actor_id:
                            self._queue_notice(target, event)
                    next_action = (
                        "The other Agent has been notified to execute W1 on fresh data. Do not call "
                        "use_candidate yourself; yield and wait for the feedback notice."
                    )
                else:
                    self.phase = "final"
                    event = {
                        "kind": "revision_frozen",
                        "candidate": self._candidate_payload(candidate_id),
                        "content": "The post-use candidate is frozen. Deliver the study result to the human.",
                        "status": self._status(),
                    }
                    self._queue_notice(actor_id, event)
                    next_action = "The revision is frozen. Deliver the final study account with deliver_study."
                self.recorder.emit(
                    "ising_learning.candidate_frozen",
                    candidate_id=candidate_id,
                    actor_id=actor_id,
                    stage=stage,
                    question_id=question_id,
                )
                return ToolResult(
                    "ok",
                    {
                        "candidate": self._candidate_payload(candidate_id),
                        "status": self._status(),
                        "next_action": next_action,
                    },
                )
            if name == "use_candidate":
                candidate_id = arguments["candidate_id"]
                if self.phase != "use" or candidate_id != self.stage_candidates.get(
                    "learn"
                ):
                    raise ValueError(
                        "only the current frozen learn candidate may be used in this stage"
                    )
                if actor_id == self.candidate_author[candidate_id]:
                    raise ValueError(
                        "new-use execution must be performed by the other Agent"
                    )
                if self.used_by:
                    raise ValueError("the finite new-use batch was already executed")
                self.used_by = actor_id
                result = self._predict(candidate_id, self.usage_records)
                self.recorder.emit(
                    "ising_learning.candidate_used",
                    candidate_id=candidate_id,
                    actor_id=actor_id,
                    phase=self.phase,
                )
                event = {
                    "kind": "new_use_result",
                    "candidate_id": candidate_id,
                    "executor": actor_id,
                    "conditional_results": result,
                    "content": "This is a finite fresh-use result. It does not reveal the hidden transition parameters or prescribe a correction.",
                    "status": self._status(),
                }
                self._queue_notice(self.candidate_author[candidate_id], event)
                return ToolResult("ok", event)
            if name == "deliver_study":
                if self.phase != "final":
                    raise ValueError(
                        "freeze a revision candidate before external delivery"
                    )
                if actor_id != self.learning_owner:
                    raise ValueError(
                        "only the feedback-holding learning position may deliver the final account"
                    )
                self.outputs.append(
                    {
                        "delivery_id": f"task-delivery-{len(self.outputs) + 1}",
                        "actor_id": actor_id,
                        "content": arguments["report"],
                        "phase": self.phase,
                    }
                )
                self.stop("completed")
                return ToolResult("ok", {"delivered": True})
            raise ValueError(f"Unknown study tool: {name}")
        except (KeyError, TypeError, ValueError) as exc:
            return ToolResult("error", error=str(exc))

    async def send(self, content: str, delivery_id: str) -> ToolResult:
        if self.phase != "final":
            return ToolResult("error", error="A final candidate has not been frozen")
        self.outputs.append(
            {"delivery_id": delivery_id, "content": content, "phase": self.phase}
        )
        self.stop("completed")
        return ToolResult("ok", {"delivered": True})

    def result(self) -> dict[str, Any]:
        return {
            "phase": self.phase,
            "stop_reason": self.stop_reason,
            "candidate_stages": dict(self.stage_candidates),
            "candidate_authors": dict(self.candidate_author),
            "learning_owner": self.learning_owner,
            "used_by": self.used_by,
            "outputs": list(self.outputs),
            "status": self._status(),
        }

    def private_evaluation_records(self) -> list[dict[str, int]]:
        return list(self.final_records)
