"""Nearest-neighbour square Ising heat-bath dynamics, with explicit RNG streams."""

from dataclasses import dataclass

import numpy as np


ACTIONS = ("none", "north", "east", "south", "west")


@dataclass(frozen=True)
class Physics:
    size: int = 12
    coupling: float = 1.0
    horizon: int = 6
    pulse_sweeps: int = 3
    pulse_strength: float = 2.0

    def __post_init__(self):
        if self.size < 8 or self.size % 2:
            raise ValueError("An even size >= 8 is required for a bipartite torus")
        if self.coupling <= 0 or self.horizon < 1:
            raise ValueError("Positive coupling and horizon required")
        if not 0 < self.pulse_sweeps <= self.horizon or self.pulse_strength <= 0:
            raise ValueError("Invalid pulse duration or strength")


@dataclass
class Case:
    case_id: str
    initial: np.ndarray
    target: tuple[int, int]  # x, y
    temperature: float
    actual_seed: int
    probe_seed: int
    evaluation_seed: int
    # Evaluator-only construction labels. Never serialize this object to an Actor.
    family: str
    pair: str


def indices(center, size, radius=1):
    x, y = center
    return (
        (np.arange(y - radius, y + radius + 1) % size).astype(int),
        (np.arange(x - radius, x + radius + 1) % size).astype(int),
    )


def patch(grid, center, radius=1):
    ys, xs = indices(center, grid.shape[-1], radius)
    return np.take(np.take(grid, ys, axis=-2), xs, axis=-1)


def pulse_sites(action, target, size):
    if action not in ACTIONS:
        raise ValueError("Unknown action")
    x, y = target
    if action == "none":
        return []
    if action in {"north", "south"}:
        dy = -2 if action == "north" else 2
        return [((x + dx) % size, (y + dy) % size) for dx in (-1, 0, 1)]
    dx = -2 if action == "west" else 2
    return [((x + dx) % size, (y + dy) % size) for dy in (-1, 0, 1)]


def energy(grid, coupling=1.0, field=0.0):
    """Count each periodic edge once. Works for a single grid or a batch."""
    g = np.asarray(grid, dtype=float)
    return -coupling * np.sum(
        g * (np.roll(g, -1, axis=-1) + np.roll(g, -1, axis=-2)), axis=(-2, -1)
    ) - np.sum(g * field, axis=(-2, -1))


def heat_bath(grid, temperature, rng, *, field=0.0, coupling=1.0):
    """One sweep: colour 0 then colour 1, each conditionally independent.

    Time is sweep count, not API latency. No diagonal or long-range update term.
    The same random numbers are drawn for every action, enabling paired scoring.
    """
    if temperature <= 0:
        raise ValueError("Temperature must be positive")
    n = grid.shape[-1]
    if grid.shape[-2] != n or n % 2:
        raise ValueError("Need an even square grid")
    yy, xx = np.indices((n, n))
    for parity in (0, 1):
        neighbours = sum(
            np.roll(grid, shift, axis=axis) for axis in (-2, -1) for shift in (-1, 1)
        )
        local = coupling * neighbours + field
        probability = 0.5 * (1.0 + np.tanh(local / temperature))
        proposed = np.where(rng.random(grid.shape) < probability, 1, -1)
        mask = (xx + yy) % 2 == parity
        grid[..., mask] = proposed[..., mask]
    return grid


def rollout(case, action, physics, *, seed, replicas=1, trajectory=False):
    if replicas < 1 or action not in ACTIONS:
        raise ValueError("Invalid rollout request")
    grids = np.repeat(case.initial[None, :, :], replicas, axis=0).astype(np.int8)
    rng = np.random.default_rng(seed)
    field = np.zeros((physics.size, physics.size))
    for x, y in pulse_sites(action, case.target, physics.size):
        field[y, x] = physics.pulse_strength
    frames = [grids[0].copy()] if trajectory else []
    for sweep in range(physics.horizon):
        heat_bath(
            grids,
            case.temperature,
            rng,
            field=field if sweep < physics.pulse_sweeps else 0.0,
            coupling=physics.coupling,
        )
        if trajectory:
            frames.append(grids[0].copy())
    magnetization = patch(grids, case.target).mean(axis=(-2, -1))
    return {
        "final": grids,
        "magnetization": magnetization,
        "success": magnetization > 0,
        "trajectory": frames,
    }


def make_cases(seed, physics=None, count=4):
    """Paired constructions, not equilibrium samples or model-discovered structure.

    Each pair shares its full 5x5 local patch and differs outside it. The second
    pair translates the target and changes temperature. Pair/family labels and
    seeds stay evaluator-private. All arms receive the same cases and streams.
    """
    p = physics or Physics()
    if count not in (1, 2, 4, 6):
        raise ValueError("Use 1, 2, 4, or 6 cases")
    rng = np.random.default_rng(seed)
    cases = []
    for k in range((count + 1) // 2):
        target = ((p.size // 2 + 2 * k) % p.size, (p.size // 2 - 2 * k) % p.size)
        noise = rng.random((p.size, p.size)) < 0.04
        baseline = np.where(noise, 1, -1).astype(np.int8)
        for side in range(2):
            # An external positive sector; square-lattice NN rules are unchanged.
            grid = baseline.copy()
            x, y = target
            orientation = (k + 2 * side) % 4
            for distance in range(3, p.size // 2 + 1):
                for offset in range(-2, 3):
                    dx, dy = [
                        (offset, -distance),
                        (distance, offset),
                        (offset, distance),
                        (-distance, offset),
                    ][orientation]
                    grid[(y + dy) % p.size, (x + dx) % p.size] = 1
            ys, xs = indices(target, p.size, radius=2)
            local = np.where(np.indices((5, 5)).sum(axis=0) % 2, 1, -1)
            grid[np.ix_(ys, xs)] = local
            i = len(cases)
            streams = np.random.SeedSequence([seed, i, 8127]).generate_state(3)
            cases.append(
                Case(
                    case_id=f"trial-{i + 1}",
                    initial=grid,
                    target=target,
                    temperature=(2.0, 2.6, 1.6)[k],
                    actual_seed=int(streams[0]),
                    probe_seed=int(streams[1]),
                    evaluation_seed=int(streams[2]),
                    family=f"sector-{orientation}",
                    pair=f"pair-{k}",
                )
            )
    return cases[:count]
