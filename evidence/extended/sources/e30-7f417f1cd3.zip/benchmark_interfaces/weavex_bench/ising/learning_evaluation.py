"""Private scoring and zero-model calibration for the learning apparatus."""

from __future__ import annotations

from typing import Any

import numpy as np

from .learning_physics import (
    CONDITIONS,
    LearningPhysics,
    conditional_probability,
    transition_records,
)


def _table(candidate: dict[str, Any]) -> dict[tuple[int, int], float]:
    return {
        (int(entry["center_before"]), int(entry["neighbor_sum"])): float(
            entry["p_plus"]
        )
        for entry in candidate["entries"]
    }


def score_candidate(
    candidate: dict[str, Any] | None,
    records: list[dict[str, int]],
    physics: LearningPhysics,
) -> dict[str, Any]:
    if candidate is None:
        return {
            "available": False,
            "n": len(records),
            "brier": None,
            "conditional_mse": None,
            "coverage": 0,
        }
    table = _table(candidate)
    predictions = np.array(
        [table[(row["center_before"], row["neighbor_sum"])] for row in records],
        dtype=float,
    )
    outcomes = np.array([row["spin_after"] == 1 for row in records], dtype=float)
    truth = np.array(
        [
            conditional_probability(row["center_before"], row["neighbor_sum"], physics)
            for row in records
        ],
        dtype=float,
    )
    per_condition = []
    for condition in CONDITIONS:
        mask = np.array(
            [
                (row["center_before"], row["neighbor_sum"]) == condition
                for row in records
            ]
        )
        if mask.any():
            per_condition.append(
                {
                    "center_before": condition[0],
                    "neighbor_sum": condition[1],
                    "n": int(mask.sum()),
                    "submitted_p_plus": table[condition],
                    "true_p_plus": float(conditional_probability(*condition, physics)),
                    "empirical_p_plus": float(outcomes[mask].mean()),
                }
            )
    return {
        "available": True,
        "n": len(records),
        "coverage": len(table),
        "brier": float(np.mean((predictions - outcomes) ** 2)),
        "conditional_mse": float(np.mean((predictions - truth) ** 2)),
        "calibration_bias": float(np.mean(predictions - outcomes)),
        "conditions": per_condition,
    }


def evaluate_learning_session(session) -> dict[str, Any]:
    records = session.private_evaluation_records()
    by_stage = {
        stage: score_candidate(
            session.candidates.get(candidate_id), records, session.physics
        )
        for stage, candidate_id in session.stage_candidates.items()
    }
    return {
        "final_blind_records": len(records),
        "candidate_scores": by_stage,
        "candidate_ids": dict(session.stage_candidates),
        "interpretation": "Brier includes irreducible transition randomness. conditional_mse compares submitted probabilities with the evaluator-only conditional kernel. Both are per campaign diagnostics, not independent LLM samples.",
    }


def marginal_baseline(records: list[dict[str, int]]) -> dict[tuple[int, int], float]:
    value = float(np.mean([row["spin_after"] == 1 for row in records]))
    return {condition: value for condition in CONDITIONS}


def empirical_condition_baseline(
    records: list[dict[str, int]],
) -> dict[tuple[int, int], float]:
    output = {}
    for condition in CONDITIONS:
        values = [
            row["spin_after"] == 1
            for row in records
            if (row["center_before"], row["neighbor_sum"]) == condition
        ]
        output[condition] = float(np.mean(values)) if values else 0.5
    return output


def calibration(seed: int = 918) -> dict[str, Any]:
    """Numerically check that q is identifiable from transition records at a useful scale."""
    configurations = [
        LearningPhysics(coupling=0.30, resample_probability=0.45),
        LearningPhysics(coupling=0.45, resample_probability=0.62),
        LearningPhysics(coupling=0.60, resample_probability=1.0),
    ]
    rows = []
    for index, physics in enumerate(configurations):
        train = transition_records(seed + 10 * index, physics, replicas=8)
        test = transition_records(seed + 10 * index + 1, physics, replicas=256)
        true_table = {
            condition: float(conditional_probability(*condition, physics))
            for condition in CONDITIONS
        }
        marginal = marginal_baseline(train)
        empirical = empirical_condition_baseline(train)

        def mse(table):
            return float(
                np.mean(
                    [
                        (
                            table[(r["center_before"], r["neighbor_sum"])]
                            - conditional_probability(
                                r["center_before"], r["neighbor_sum"], physics
                            )
                        )
                        ** 2
                        for r in test
                    ]
                )
            )

        rows.append(
            {
                "configuration": index + 1,
                "train_transitions": len(train),
                "test_transitions": len(test),
                "marginal_conditional_mse": mse(marginal),
                "empirical_table_conditional_mse": mse(empirical),
                "truth_conditional_mse": mse(true_table),
                "true_table": [
                    {
                        "center_before": center,
                        "neighbor_sum": neighbour_sum,
                        "p_plus": true_table[(center, neighbour_sum)],
                    }
                    for center, neighbour_sum in CONDITIONS
                ],
            }
        )
    return {
        "seed": seed,
        "configurations": rows,
        "interpretation": "The evaluator-only true table must beat the marginal baseline. The empirical table is a same-data generic reference; its result establishes apparatus signal, not model learning.",
    }
