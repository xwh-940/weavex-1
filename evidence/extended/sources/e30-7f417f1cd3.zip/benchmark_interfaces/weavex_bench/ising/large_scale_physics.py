"""16x16 paired worlds for multi-sweep regional prediction calibration."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .learning_physics import LearningPhysics, half_step, random_grid


@dataclass(frozen=True)
class LargeScalePhysics(LearningPhysics):
    size: int = 16
    target_center: tuple[int, int] = (4, 8)
    target_width: int = 4

    def __post_init__(self):
        super().__post_init__()
        if self.target_width < 2 or self.target_width % 2:
            raise ValueError("target_width must be positive and even")


def target_indices(physics: LargeScalePhysics) -> tuple[np.ndarray, np.ndarray]:
    x, y = physics.target_center
    radius = physics.target_width // 2
    return (
        np.arange(y - radius, y + radius, dtype=int) % physics.size,
        np.arange(x - radius, x + radius, dtype=int) % physics.size,
    )


def target_mean(grid: np.ndarray, physics: LargeScalePhysics) -> float:
    ys, xs = target_indices(physics)
    return float(grid[np.ix_(ys, xs)].mean())


def paired_initial_states(
    seed: int, physics: LargeScalePhysics
) -> tuple[np.ndarray, np.ndarray]:
    """Equal 7x7 target neighborhood; distinct remote sector is evaluator-only."""
    rng = np.random.default_rng(seed)
    base = random_grid(rng, physics.size)
    plus, minus = base.copy(), base.copy()
    x, y = physics.target_center
    yy, xx = np.indices((physics.size, physics.size))
    dx = np.minimum((xx - x) % physics.size, (x - xx) % physics.size)
    dy = np.minimum((yy - y) % physics.size, (y - yy) % physics.size)
    local = (dx <= 3) & (dy <= 3)
    remote_right = (xx >= physics.size // 2) & ~local
    plus[remote_right] = 1
    minus[remote_right] = -1
    return plus, minus


def rollout(
    grid: np.ndarray, seed: int, physics: LargeScalePhysics, sweeps: int
) -> list[float]:
    state = grid.copy()
    rng = np.random.default_rng(seed)
    means = []
    for _ in range(sweeps):
        for parity in (0, 1):
            state, _ = half_step(state, parity, rng, physics)
        means.append(target_mean(state, physics))
    return means


def paired_response(
    seed: int, physics: LargeScalePhysics, *, replicas: int = 512, sweeps: int = 4
) -> dict:
    plus, minus = paired_initial_states(seed, physics)
    values_plus = np.array(
        [rollout(plus, seed + 10_000 + i, physics, sweeps) for i in range(replicas)]
    )
    values_minus = np.array(
        [rollout(minus, seed + 10_000 + i, physics, sweeps) for i in range(replicas)]
    )
    delta = values_plus - values_minus
    return {
        "replicas": replicas,
        "sweeps": sweeps,
        "mean_plus": values_plus.mean(axis=0).tolist(),
        "mean_minus": values_minus.mean(axis=0).tolist(),
        "difference": delta.mean(axis=0).tolist(),
        "paired_standard_error": (
            delta.std(axis=0, ddof=1) / np.sqrt(replicas)
        ).tolist(),
    }


def calibration(seed: int = 1201) -> dict:
    physics = LargeScalePhysics(coupling=0.45, resample_probability=0.62)
    result = paired_response(seed, physics)
    signal_to_noise = [
        abs(value) / error if error else None
        for value, error in zip(result["difference"], result["paired_standard_error"])
    ]
    return {
        "physics_private": {
            "size": physics.size,
            "coupling": physics.coupling,
            "resample_probability": physics.resample_probability,
            "target_center": physics.target_center,
            "target_width": physics.target_width,
        },
        "paired_response": result,
        "signal_to_noise": signal_to_noise,
        "interpretation": "The two worlds have the same target 7x7 neighborhood at time zero. Any later difference is propagated through ordinary nearest-neighbour updates, not an added long-range force.",
    }
