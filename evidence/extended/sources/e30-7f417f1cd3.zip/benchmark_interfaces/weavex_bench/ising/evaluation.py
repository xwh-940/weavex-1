"""Independent counterfactual ensembles. Never imported by the Session."""

import numpy as np

from .physics import ACTIONS, Physics, rollout


def evaluate(cases, records, *, physics=None, replicas=512):
    p = physics or Physics()
    selected = {record["trial_id"]: record for record in records}
    scores = []
    for case in cases:
        outcomes = {
            action: rollout(
                case, action, p, seed=case.evaluation_seed, replicas=replicas
            )
            for action in ACTIONS
        }
        probabilities = {a: float(v["success"].mean()) for a, v in outcomes.items()}
        best = max(probabilities, key=probabilities.get)
        record = selected.get(case.case_id)
        action = record["action"] if record else "none"
        samples = outcomes[action]["success"].astype(float)
        baseline = outcomes["none"]["success"].astype(float)
        delta = samples - baseline
        score = {
            "trial_id": case.case_id,
            "pair": case.pair,
            "family": case.family,
            "temperature": case.temperature,
            "replicas": replicas,
            "completed": record is not None,
            "reported": bool(record and record.get("reported")),
            "action": action if record else None,
            "missing_action_scored_as": None if record else "none",
            "probabilities": probabilities,
            "best_action": best,
            "expected_success": probabilities[action],
            "uplift_over_no_action": float(delta.mean()),
            "uplift_mc_se": float(delta.std(ddof=1) / np.sqrt(replicas)),
            "regret": probabilities[best] - probabilities[action],
            "p_success": record["p_success"] if record else None,
            "p_no_action": record["p_no_action"] if record else None,
            "actual_success": record["actual"]["target_positive"] if record else None,
            "expected_brier": None,
            "forecast_squared_error": None,
        }
        if record:
            prediction, q = record["p_success"], probabilities[action]
            score["expected_brier"] = prediction**2 - 2 * prediction * q + q
            score["forecast_squared_error"] = (prediction - q) ** 2
            score["no_action_forecast_squared_error"] = (
                record["p_no_action"] - probabilities["none"]
            ) ** 2
        scores.append(score)
    completed = [s for s in scores if s["completed"]]
    return {
        "trials": scores,
        "summary": {
            "assigned": len(scores),
            "committed": len(completed),
            "reported": sum(s["reported"] for s in scores),
            "completion_rate": len(completed) / len(scores),
            "expected_success_all_trials": float(
                np.mean([s["expected_success"] for s in scores])
            ),
            "mean_uplift_all_trials": float(
                np.mean([s["uplift_over_no_action"] for s in scores])
            ),
            "mean_regret_all_trials": float(np.mean([s["regret"] for s in scores])),
            "forecast_mse_completed_only": float(
                np.mean([s["forecast_squared_error"] for s in completed])
            )
            if completed
            else None,
        },
        "interpretation": "Monte Carlo uncertainty is conditional on each prepared case, not a confidence interval across LLM runs. Missing decisions receive no-action performance and remain explicit failures.",
    }
