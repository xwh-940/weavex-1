"""Current-world regional views with Broker-optional Agent expansion."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from ..contracts import SessionStopped, TaskToolSpec, ToolResult
from .large_scale_physics import (
    LargeScalePhysics,
    paired_initial_states,
    paired_response,
)


SLOTS = ("target_band", "north_remote", "south_remote", "far_right")


@dataclass
class AdaptiveBudget:
    max_requests: int = 56
    max_total_tokens: int = 1_200_000
    max_slots: int = 4


def schema(properties: dict[str, Any], required=None) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties if required is None else required),
        "additionalProperties": False,
    }


class AdaptiveRegionalSession:
    scope = "ising-adaptive-regional-16x16-v1"
    instructions = """You predict a current 16x16 paired Ising world. Preparations A and B have the same target 7x7 neighbourhood but differ farther away. Before forecasting, Agents may claim at most one unoccupied current-world region slot. A Broker may create a new Agent only if it judges another current view useful; it must send that Agent a real Question. Creating an Agent does not itself reveal a view or establish a result. The forecast is six target means at horizons 1,2,4. Submit baseline before reading views; use records a fresh physical outcome; revision may change or retain the forecast. All information is finite and current-world-specific."""

    def __init__(self, *, seed: int, physics: LargeScalePhysics, recorder, budget=None):
        self.seed, self.physics, self.recorder = seed, physics, recorder
        self.budget = budget or AdaptiveBudget()
        self.phase, self.stop_reason, self.stopped = "baseline", "", False
        self.model_requests = 0
        self.slot_owner: dict[str, str] = {}
        self.actor_slot: dict[str, str] = {}
        self.candidates: dict[str, dict] = {}
        self.stages: dict[str, str] = {}
        self.author = ""
        self.used_by = ""
        self.outputs = []
        self.questions: dict[str, str] = {}
        self.notices: list[tuple[str, dict]] = []
        self.plus, self.minus = paired_initial_states(seed + 400, physics)

    def bind_interface_questions(self, values):
        self.questions = dict(values)

    def now(self):
        return 0.0

    def _status(self):
        return {
            "phase": self.phase,
            "claimed_slots": dict(self.slot_owner),
            "model_requests_remaining": self.budget.max_requests - self.model_requests,
        }

    def _agent(self, actor_id):
        return actor_id.startswith("agent-")

    def tools(self):
        values = {
            "type": "array",
            "items": {"type": "number", "minimum": -1, "maximum": 1},
            "minItems": 3,
            "maxItems": 3,
        }
        return (
            TaskToolSpec(
                "inspect_current_world",
                "Read phase, claimed slots, and remaining budget.",
                schema({}),
            ),
            TaskToolSpec(
                "claim_current_view",
                "Claim one unoccupied current-world region slot and observe its A/B means.",
                schema({"slot": {"type": "string", "enum": list(SLOTS)}}),
                True,
            ),
            TaskToolSpec(
                "submit_current_forecast",
                "Freeze six current-world target forecasts.",
                schema(
                    {
                        "stage": {
                            "type": "string",
                            "enum": ["baseline", "learn", "revision"],
                        },
                        "world_a": values,
                        "world_b": values,
                    }
                ),
                True,
            ),
            TaskToolSpec(
                "use_current_forecast",
                "Execute the learned forecast once against the current paired world.",
                schema({"candidate_id": {"type": "string"}}),
                True,
            ),
            TaskToolSpec(
                "deliver_current_study",
                "Deliver the final account after revision.",
                schema(
                    {"report": {"type": "string", "minLength": 1, "maxLength": 8000}}
                ),
                True,
            ),
        )

    def _slot_value(self, slot):
        windows = {
            "target_band": (slice(5, 11), slice(1, 7)),
            "north_remote": (slice(0, 4), slice(8, 12)),
            "south_remote": (slice(12, 16), slice(8, 12)),
            "far_right": (slice(4, 12), slice(12, 16)),
        }
        ys, xs = windows[slot]
        return {
            "slot": slot,
            "world_a_mean": float(self.plus[ys, xs].mean()),
            "world_b_mean": float(self.minus[ys, xs].mean()),
            "shape": [ys.stop - ys.start, xs.stop - xs.start],
            "coordinates": "current-world projection; evaluator parameters remain hidden",
        }

    def file_notices(self):
        values, self.notices = self.notices, []
        for actor_id, payload in values:
            yield (
                actor_id,
                {"interface_question_id": self.questions.get(actor_id, ""), **payload},
            )

    async def poll(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        return []

    async def idle(self):
        self.stop("idle_before_delivery")
        raise SessionStopped(self.stop_reason)

    def stop(self, reason):
        self.stopped, self.stop_reason = True, reason
        self.recorder.emit("ising_adaptive.stopped", reason=reason, phase=self.phase)

    def before_model(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        if self.model_requests >= self.budget.max_requests:
            self.stop("model_request_limit")
            raise SessionStopped(self.stop_reason)
        if (
            sum(
                self.recorder.usage()[key]
                for key in ("prompt_tokens", "completion_tokens")
            )
            >= self.budget.max_total_tokens
        ):
            self.stop("reported_token_limit")
            raise SessionStopped(self.stop_reason)
        self.model_requests += 1

    def after_model(self, seconds):
        return None

    async def call(self, name, arguments):
        return ToolResult("error", error="Actor identity is required")

    async def call_for_actor(self, actor_id, name, arguments, *, question_id=None):
        if not self._agent(actor_id):
            return ToolResult("error", error="Broker cannot operate the physical world")
        try:
            if name == "inspect_current_world":
                return ToolResult("ok", self._status())
            if name == "claim_current_view":
                if self.phase != "learn":
                    raise ValueError("current views open only after baseline")
                if actor_id in self.actor_slot:
                    raise ValueError("each Agent can claim only one slot")
                slot = arguments["slot"]
                if slot in self.slot_owner:
                    raise ValueError("slot already occupied")
                self.slot_owner[slot], self.actor_slot[actor_id] = actor_id, slot
                value = self._slot_value(slot)
                self.recorder.emit(
                    "ising_adaptive.view_claimed", actor_id=actor_id, slot=slot
                )
                return ToolResult("ok", value)
            if name == "submit_current_forecast":
                stage = arguments["stage"]
                expected = {
                    "baseline": "baseline",
                    "learn": "learn",
                    "revision": "use",
                }[stage]
                if self.phase != expected or stage in self.stages:
                    raise ValueError("forecast stage unavailable")
                if stage != "baseline" and actor_id != self.author:
                    raise ValueError("only the learning holder may revise")
                if stage == "learn" and not self.slot_owner:
                    raise ValueError(
                        "claim at least one current view before learned forecast"
                    )
                if stage == "revision" and not self.used_by:
                    raise ValueError("execute learned forecast before revision")
                candidate_id = f"A{len(self.candidates)}"
                self.candidates[candidate_id] = {
                    "stage": stage,
                    "world_a": list(arguments["world_a"]),
                    "world_b": list(arguments["world_b"]),
                    "slot_claims": dict(self.slot_owner),
                }
                self.stages[stage] = candidate_id
                if stage == "baseline":
                    self.phase, self.author = "learn", actor_id
                elif stage == "learn":
                    self.phase = "use"
                else:
                    self.phase = "final"
                return ToolResult(
                    "ok", {"candidate_id": candidate_id, "status": self._status()}
                )
            if name == "use_current_forecast":
                candidate_id = arguments["candidate_id"]
                if (
                    self.phase != "use"
                    or candidate_id != self.stages.get("learn")
                    or self.used_by
                ):
                    raise ValueError("current learned forecast unavailable")
                self.used_by = actor_id
                response = paired_response(
                    self.seed + 400, self.physics, replicas=256, sweeps=4
                )
                actual_a, actual_b = (
                    np.array(response["mean_plus"])[[0, 1, 3]],
                    np.array(response["mean_minus"])[[0, 1, 3]],
                )
                item = self.candidates[candidate_id]
                a, b = np.array(item["world_a"]), np.array(item["world_b"])
                return ToolResult(
                    "ok",
                    {
                        "executor": actor_id,
                        "candidate_id": candidate_id,
                        "actual_a": actual_a.tolist(),
                        "actual_b": actual_b.tolist(),
                        "mse": float(
                            np.mean(
                                np.concatenate(
                                    ((a - actual_a) ** 2, (b - actual_b) ** 2)
                                )
                            )
                        ),
                        "slot_claims": item["slot_claims"],
                    },
                )
            if name == "deliver_current_study":
                if self.phase != "final" or actor_id != self.author:
                    raise ValueError("only forecast author may deliver after revision")
                self.outputs.append(
                    {"actor_id": actor_id, "content": arguments["report"]}
                )
                self.stop("completed")
                return ToolResult("ok", {"delivered": True})
            raise ValueError("Unknown adaptive tool")
        except (KeyError, TypeError, ValueError) as exc:
            return ToolResult("error", error=str(exc))

    async def send(self, content, delivery_id):
        return ToolResult("error", error="Use deliver_current_study")

    def result(self):
        return {
            "phase": self.phase,
            "stop_reason": self.stop_reason,
            "stages": self.stages,
            "candidates": self.candidates,
            "slot_owner": self.slot_owner,
            "used_by": self.used_by,
            "outputs": self.outputs,
            "status": self._status(),
        }
