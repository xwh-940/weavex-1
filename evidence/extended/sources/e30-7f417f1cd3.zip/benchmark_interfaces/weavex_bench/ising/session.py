"""Model-facing local observations and effects; no evaluator access path."""

from dataclasses import dataclass
import json
import math

from ..baselines.workbench import Workbench
from ..contracts import InputEnvelope, SessionStopped, TaskToolSpec, ToolResult
from .physics import ACTIONS, Physics, patch, pulse_sites, rollout


@dataclass
class Budget:
    max_requests: int = 120
    max_total_tokens: int = 2_000_000
    requests: int = 0


def schema(properties, required=None):
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties if required is None else required),
        "additionalProperties": False,
    }


INSTRUCTIONS = """You operate a controlled 2D nearest-neighbour ferromagnetic Ising experiment.
The task is to maximize the probability of positive mean spin in a specified 3x3 target
after a short local-field pulse and relaxation, and give honest probability forecasts.
Each trial supplies temperature and physical parameters. Trials are independently prepared;
the cognitive participant can retain its own history within this campaign. Conclusions
about previous trials are not observations of the current lattice. Random outcomes may differ.

The apparatus uses a periodic even square lattice, J=1, no background field, and checkerboard
heat-bath updates (colour 0 then 1, P(+)=1/(1+exp(-2*local_field/T))). A sweep is two colour
updates. Physical time advances only in probe and commit rollouts; model latency, messages,
and reading do not advance it. This is a controlled stroboscopic experiment, not wall-clock
continuous physics. Coordinates are x rightwards, y downwards, with periodic wrapping.

Every trial allows SIX shared 3x3 local observations, ONE shared experimental probe and
ONE committed action (none/north/east/south/west). These limits belong to the whole participant,
not each Agent. A probe uses a disposable independent replica of the same initial state and
reveals only the final target patch. It does not alter the committed trial and is not an
ensemble probability estimate. commit_trial applies the chosen physical pulse, advances
the real trial and reveals the final target patch. Forecasts must be supplied before this
effect; no tool provides the complete lattice, hidden environment class, random seeds,
alternative-action scores or future truth. inspect_trial reveals parameters and remaining
allowances, not spin values. All observations are private to the caller until disclosed.

Tool arguments carry trial_id, which must be the current trial. Once committed, physical
actions for that trial are closed. A subsequent outward report completes the trial and
admits the next user task. Reports alone do not apply an action. The participant has a
shared model-request and token ceiling; it should return its result within the remaining
resources. Retaining, organizing, communicating or revising knowledge is available, but no
particular representation, decomposition, worker count or experimental strategy is required.
""".strip()


class IsingSession:
    scope = "ising-prototype-v1"
    instructions = INSTRUCTIONS

    def __init__(self, cases, recorder, *, physics=None, budget=None, notebook=False):
        if not cases:
            raise ValueError("At least one trial required")
        self.cases = cases
        self.recorder = recorder
        self.physics = physics or Physics()
        self.budget = budget or Budget()
        self.notebook = Workbench() if notebook else None
        self.stopped = False
        self.stop_reason = ""
        self.index = 0
        self.observations = 0
        self.probes = 0
        self.committed = False
        self.records = []
        self.outputs = []
        self._pending = [self._input()]
        self._idle_count = 0
        self._time = 0.0

    @property
    def case(self):
        return self.cases[self.index]

    def public_status(self):
        p, c = self.physics, self.case
        return {
            "trial_id": c.case_id,
            "size": p.size,
            "target_center": list(c.target),
            "target_width": 3,
            "temperature": c.temperature,
            "coupling": p.coupling,
            "horizon_sweeps": p.horizon,
            "pulse_sweeps": p.pulse_sweeps,
            "pulse_strength": p.pulse_strength,
            "action_sites": {a: pulse_sites(a, c.target, p.size) for a in ACTIONS},
            "observations_remaining": 6 - self.observations,
            "probes_remaining": 1 - self.probes,
            "committed": self.committed,
            "model_requests_remaining": self.budget.max_requests - self.budget.requests,
        }

    def _input(self):
        return InputEnvelope(
            event_id=f"input-{self.case.case_id}",
            kind="user",
            source="human",
            timestamp=getattr(self, "_time", 0.0),
            conversation=self.case.case_id,
            content=(
                "Resolve this trial: select and actually commit one permitted action to "
                "maximize target-positive probability. Before committing, give the probability "
                "of target-positive both for your action and for no pulse. Then report the "
                "actual observation and your basis/remaining uncertainty. The next trial is "
                "admitted after that report. No future observation is supplied in advance.\n"
                + json.dumps(self.public_status(), ensure_ascii=False)
            ),
        )

    def tools(self):
        trial = {"trial_id": {"type": "string"}}
        action = {"action": {"type": "string", "enum": list(ACTIONS)}}
        specs = [
            TaskToolSpec(
                "inspect_trial",
                "Read current parameters and shared allowances; no spins.",
                schema({}),
            ),
            TaskToolSpec(
                "observe_patch",
                "Spend one shared observation to read a current 3x3 patch. Does not advance time.",
                schema(
                    {
                        **trial,
                        "x": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": self.physics.size - 1,
                        },
                        "y": {
                            "type": "integer",
                            "minimum": 0,
                            "maximum": self.physics.size - 1,
                        },
                    }
                ),
            ),
            TaskToolSpec(
                "probe_action",
                "Spend the shared disposable replica experiment. Return one sampled final target patch, not an oracle score.",
                schema({**trial, **action}),
                write=True,
            ),
            TaskToolSpec(
                "commit_trial",
                "Irreversibly commit one action and both probability forecasts, then observe the real trial outcome.",
                schema(
                    {
                        **trial,
                        **action,
                        "p_success": {"type": "number", "minimum": 0, "maximum": 1},
                        "p_no_action": {"type": "number", "minimum": 0, "maximum": 1},
                        "basis": {"type": "string"},
                    }
                ),
                write=True,
            ),
        ]
        if self.notebook is not None:
            specs.append(
                TaskToolSpec(
                    "notebook",
                    "Persistent private text storage. Does not reveal environmental facts.",
                    schema(
                        {
                            "operation": {
                                "type": "string",
                                "enum": ["read", "write", "list", "search"],
                            },
                            "path": {"type": "string"},
                            "content": {"type": "string"},
                            "query": {"type": "string"},
                        },
                        required=["operation", "path"],
                    ),
                    write=True,
                )
            )
        return tuple(specs)

    def stop(self, reason):
        self.stopped, self.stop_reason = True, reason
        self.recorder.emit("ising.stopped", reason=reason, trial_id=self.case.case_id)

    def before_model(self):
        usage = self.recorder.usage()
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        if self.budget.requests >= self.budget.max_requests:
            self.stop("model_request_limit")
            raise SessionStopped(self.stop_reason)
        if (
            usage["prompt_tokens"] + usage["completion_tokens"]
            >= self.budget.max_total_tokens
        ):
            self.stop("reported_token_limit")
            raise SessionStopped(self.stop_reason)
        self.budget.requests += 1
        self._idle_count = 0

    def after_model(self, seconds):
        # Wall time is recorded by the participant, not used as physical time.
        pass

    def now(self):
        return self._time

    async def poll(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        pending, self._pending = self._pending, []
        return pending

    async def idle(self):
        self._idle_count += 1
        if self._idle_count >= 2:
            self.stop("idle_with_unfinished_trial")
            raise SessionStopped(self.stop_reason)

    async def call(self, name, arguments):
        return ToolResult("error", error="Actor identity is required")

    async def call_for_actor(self, actor_id, name, arguments, *, question_id=None):
        if self.stopped:
            return ToolResult("error", error="Session has stopped")
        # Defense in depth in addition to the WeaveX gateway's role check.
        if actor_id == "broker" or actor_id.startswith("broker-"):
            return ToolResult(
                "error", error="Broker cannot inspect or operate the physical world"
            )
        try:
            if name == "inspect_trial":
                return ToolResult("ok", self.public_status())
            if name == "notebook" and self.notebook is not None:
                if not arguments["path"].startswith("/private/"):
                    raise PermissionError(
                        "This comparator has only private notebook storage"
                    )
                return ToolResult("ok", self.notebook.workspace(actor_id, **arguments))
            if arguments.get("trial_id") != self.case.case_id:
                raise ValueError("Stale or missing trial_id; inspect current trial")
            if self.committed:
                raise ValueError("Trial already committed; report before next trial")
            if name == "observe_patch":
                if self.observations >= 6:
                    raise ValueError("Shared observation allowance exhausted")
                x, y = arguments["x"], arguments["y"]
                if any(
                    type(v) is not int or not 0 <= v < self.physics.size for v in (x, y)
                ):
                    raise ValueError("Invalid coordinates")
                self.observations += 1
                result = {
                    "trial_id": self.case.case_id,
                    "sweep": 0,
                    "center": [x, y],
                    "rows_y_columns_x": patch(self.case.initial, (x, y)).tolist(),
                    "observations_remaining": 6 - self.observations,
                }
            elif name in {"probe_action", "commit_trial"}:
                action = arguments["action"]
                if action not in ACTIONS:
                    raise ValueError("Invalid action")
                is_probe = name == "probe_action"
                if is_probe and self.probes >= 1:
                    raise ValueError("Shared experimental probe allowance exhausted")
                if not is_probe:
                    for key in ("p_success", "p_no_action"):
                        value = arguments[key]
                        if (
                            isinstance(value, bool)
                            or not isinstance(value, (int, float))
                            or not math.isfinite(value)
                            or not 0 <= value <= 1
                        ):
                            raise ValueError("Forecasts must be finite probabilities")
                outcome = rollout(
                    self.case,
                    action,
                    self.physics,
                    seed=self.case.probe_seed if is_probe else self.case.actual_seed,
                    trajectory=not is_probe,
                )
                result = {
                    "trial_id": self.case.case_id,
                    "action": action,
                    "sample_kind": "disposable_probe"
                    if is_probe
                    else "committed_trial",
                    "sweep": self.physics.horizon,
                    "target_final": patch(
                        outcome["final"][0], self.case.target
                    ).tolist(),
                    "target_mean_spin": float(outcome["magnetization"][0]),
                    "target_positive": bool(outcome["success"][0]),
                }
                if is_probe:
                    self.probes += 1
                else:
                    self.committed = True
                    self._time += self.physics.horizon
                    record = {
                        "trial_id": self.case.case_id,
                        "actor_id": actor_id,
                        "question_id": question_id,
                        **arguments,
                        "actual": result,
                        "observations": self.observations,
                        "probes": self.probes,
                        "model_requests_at_commit": self.budget.requests,
                    }
                    self.records.append(record)
                    # Full trajectory is evaluator-only, never returned to the caller.
                    self.recorder.emit(
                        "ising.committed_private",
                        record=record,
                        trajectory=[frame.tolist() for frame in outcome["trajectory"]],
                    )
            else:
                raise ValueError("Unknown task tool")
            self.recorder.emit(
                "ising.visible_effect", actor_id=actor_id, tool=name, value=result
            )
            return ToolResult("ok", result)
        except (KeyError, ValueError, PermissionError, TypeError) as exc:
            return ToolResult("error", error=str(exc))

    async def send(self, content, delivery_id):
        if not self.committed:
            return ToolResult(
                "error",
                error="No action committed; text alone does not resolve the trial",
            )
        self.outputs.append(
            {
                "trial_id": self.case.case_id,
                "delivery_id": delivery_id,
                "content": content,
            }
        )
        self.records[-1]["reported"] = True
        if self.index + 1 == len(self.cases):
            self.stop("completed")
        else:
            self.index += 1
            self.observations = self.probes = 0
            self.committed = False
            self._pending.append(self._input())
        return ToolResult("ok", {"delivered": True})
