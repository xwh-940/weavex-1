"""Controlled, locally observed Ising intervention prototype.

Evaluation is kept separate from the model-facing Session.
"""
