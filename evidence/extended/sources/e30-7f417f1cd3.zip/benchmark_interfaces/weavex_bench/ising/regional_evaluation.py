"""Evaluator-only blind scoring for regional forecast candidates."""

from __future__ import annotations

import numpy as np

from .large_scale_physics import paired_response


def evaluate(session, *, replicas: int = 512) -> dict:
    observed = paired_response(
        session.seed + 300, session.physics, replicas=replicas, sweeps=4
    )
    actual_a = np.array(observed["mean_plus"])[[0, 1, 3]]
    actual_b = np.array(observed["mean_minus"])[[0, 1, 3]]
    scores = {}
    for stage, candidate_id in session.stages.items():
        item = session.candidates[candidate_id]
        a, b = np.array(item["world_a"]), np.array(item["world_b"])
        scores[stage] = {
            "candidate_id": candidate_id,
            "mse": float(
                np.mean(np.concatenate(((a - actual_a) ** 2, (b - actual_b) ** 2)))
            ),
        }
    return {
        "replicas": replicas,
        "actual_a": actual_a.tolist(),
        "actual_b": actual_b.tolist(),
        "paired_standard_error": np.array(observed["paired_standard_error"])[
            [0, 1, 3]
        ].tolist(),
        "scores": scores,
        "interpretation": "This fresh paired world was not returned to the running Agents. It measures transfer after the post-use revision, not fit to the use batch.",
    }
