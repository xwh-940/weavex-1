"""Hidden-parameter kinetic Ising apparatus for the learning benchmark.

This module belongs to the instrument and evaluator.  Its parameter values and
transition formula are never projected into model-facing Session inputs.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


CONDITIONS = tuple(
    (center, neighbour_sum) for center in (-1, 1) for neighbour_sum in (-4, -2, 0, 2, 4)
)


@dataclass(frozen=True)
class LearningPhysics:
    size: int = 8
    coupling: float = 0.45
    resample_probability: float = 0.62

    def __post_init__(self):
        if self.size < 8 or self.size % 2:
            raise ValueError(
                "Learning apparatus requires an even lattice of size at least 8"
            )
        if not 0 < self.coupling <= 1.5:
            raise ValueError("coupling must be in (0, 1.5]")
        if not 0 < self.resample_probability <= 1:
            raise ValueError("resample_probability must be in (0, 1]")


def sigmoid(value: np.ndarray | float) -> np.ndarray | float:
    return 1 / (1 + np.exp(-value))


def conditional_probability(
    center: np.ndarray | int, neighbour_sum: np.ndarray | int, physics: LearningPhysics
) -> np.ndarray | float:
    """Evaluator-only P(spin becomes +1) for one checkerboard half step."""
    c = np.asarray(center)
    return (1 - physics.resample_probability) * (
        c == 1
    ) + physics.resample_probability * sigmoid(
        2 * physics.coupling * np.asarray(neighbour_sum)
    )


def neighbour_sums(grid: np.ndarray) -> np.ndarray:
    return sum(
        np.roll(grid, shift, axis=axis) for axis in (-2, -1) for shift in (-1, 1)
    )


def half_step(
    grid: np.ndarray, parity: int, rng: np.random.Generator, physics: LearningPhysics
) -> tuple[np.ndarray, list[dict[str, int]]]:
    """Advance a single colour and return raw site transitions for the instrument."""
    if parity not in (0, 1):
        raise ValueError("parity must be 0 or 1")
    before = grid.copy()
    sums = neighbour_sums(before)
    yy, xx = np.indices((physics.size, physics.size))
    mask = (xx + yy) % 2 == parity
    p_plus = conditional_probability(before, sums, physics)
    redraw = rng.random(grid.shape) < physics.resample_probability
    sampled = np.where(rng.random(grid.shape) < p_plus, 1, -1)
    # p_plus already includes the retain probability.  The branch below uses the
    # original heat-bath probability only when redraw occurs, avoiding a second mix.
    heat_bath = np.where(
        rng.random(grid.shape) < sigmoid(2 * physics.coupling * sums), 1, -1
    )
    grid[mask] = np.where(redraw[mask], heat_bath[mask], before[mask])
    transitions = [
        {
            "x": int(x),
            "y": int(y),
            "parity": parity,
            "center_before": int(before[y, x]),
            "neighbor_sum": int(sums[y, x]),
            "spin_after": int(grid[y, x]),
        }
        for y, x in zip(*np.where(mask))
    ]
    del sampled  # Documents that no hidden conditional probability is returned.
    return grid, transitions


def random_grid(rng: np.random.Generator, size: int) -> np.ndarray:
    return rng.choice(np.array([-1, 1], dtype=np.int8), size=(size, size)).astype(
        np.int8
    )


def trajectory(
    seed: int, physics: LearningPhysics, *, replicas: int = 1, sweeps: int = 1
) -> list[list[dict[str, int]]]:
    """Independent random starts followed by labelled half-step records."""
    if replicas < 1 or sweeps < 1:
        raise ValueError("replicas and sweeps must be positive")
    rng = np.random.default_rng(seed)
    records: list[list[dict[str, int]]] = []
    for replica in range(replicas):
        grid = random_grid(rng, physics.size)
        for sweep in range(sweeps):
            for parity in (0, 1):
                grid, transitions = half_step(grid, parity, rng, physics)
                for event in transitions:
                    event.update({"replica": replica, "sweep": sweep})
                    records.append([event])
    return records


def transition_records(
    seed: int, physics: LearningPhysics, *, replicas: int, sweeps: int = 1
) -> list[dict[str, int]]:
    return [
        event
        for group in trajectory(seed, physics, replicas=replicas, sweeps=sweeps)
        for event in group
    ]


def condition_table(records: list[dict[str, int]]) -> list[dict[str, float | int]]:
    """A generic conditional frequency summary over already authorized records."""
    output = []
    for center, neighbour_sum in CONDITIONS:
        relevant = [
            row
            for row in records
            if row["center_before"] == center and row["neighbor_sum"] == neighbour_sum
        ]
        output.append(
            {
                "center_before": center,
                "neighbor_sum": neighbour_sum,
                "count": len(relevant),
                "empirical_p_plus": float(
                    np.mean([row["spin_after"] == 1 for row in relevant])
                )
                if relevant
                else None,
            }
        )
    return output
