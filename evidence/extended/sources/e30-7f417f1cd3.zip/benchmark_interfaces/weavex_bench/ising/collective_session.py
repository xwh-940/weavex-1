"""Broad local ownership prototype for a 16x16 Ising prediction episode.

This is deliberately an *episode* benchmark.  It audits whether a current forecast
uses distinct local micro observations and a finite response experiment; it does not
claim that one six-number forecast generalises to a different unobserved world.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from ..contracts import SessionStopped, TaskToolSpec, ToolResult
from .large_scale_physics import LargeScalePhysics, rollout
from .learning_physics import random_grid


BROKERS = ("broker-direct", "broker-effective")
PATCHES = tuple(f"cell_{row}_{column}" for row in range(4) for column in range(4))
FRONTIER_PATCH = "cell_1_2"
INITIAL_PATCHES = tuple(slot for slot in PATCHES if slot != FRONTIER_PATCH)


@dataclass
class CollectiveBudget:
    max_requests: int = 96
    max_total_tokens: int = 1_800_000
    require_cross_position_use: bool = True


def schema(properties: dict[str, Any], required=None) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties if required is None else required),
        "additionalProperties": False,
    }


def _paired_frontier_states(seed: int, physics: LargeScalePhysics):
    """Two states differing only in an initially unowned 4x4 frontier patch."""

    rng = np.random.default_rng(seed)
    base = random_grid(rng, physics.size)
    plus, minus = base.copy(), base.copy()
    # target is rows 6..9, columns 2..5.  This patch is three columns away,
    # so an effect may arrive only through normal repeated nearest-neighbour steps.
    plus[4:8, 8:12] = 1
    minus[4:8, 8:12] = -1
    return plus, minus


def _paired_target_response(seed: int, physics: LargeScalePhysics, replicas: int):
    plus, minus = _paired_frontier_states(seed, physics)
    values_plus = np.array(
        [rollout(plus, seed + 10_000 + index, physics, 4) for index in range(replicas)]
    )
    values_minus = np.array(
        [rollout(minus, seed + 10_000 + index, physics, 4) for index in range(replicas)]
    )
    return values_plus, values_minus


class CollectiveRegionalSession:
    """A finite current-world study with broad local positions and two Brokers."""

    scope = "ising-collective-regional-16x16-v1"
    instructions = """This is a current 16x16 Ising prediction episode. Fifteen initial
Agents each have one disjoint 4x4 local cell; together they cover every cell except
one frontier cell. The two current worlds are identical in all initially owned cells
and differ in that unowned cell. Brokers do not read the lattice or invent evidence:
they may only coordinate Questions and carry returned material. A Broker can create a
new Agent when the unresolved frontier needs a distinct local observation; that Agent
must receive a real Question before it can operate. A useful forecast may cite raw
micro observations and a separately obtained finite boundary-response probe. These
are different evidence roles: raw state constrains the present material, while a
probe constrains whether that material affects the target at the requested time.
Submit W0 before observations, W1 after any evidence, let another Agent execute W1,
then W2 and deliver. Citations are auditable but no citation is mandatory: declining
to create or probe remains a legitimate, scoreable result."""

    def __init__(self, *, seed: int, physics: LargeScalePhysics, recorder, budget=None):
        self.seed, self.physics, self.recorder = seed, physics, recorder
        self.budget = budget or CollectiveBudget()
        self.phase, self.stopped, self.stop_reason = "baseline", False, ""
        self.model_requests = 0
        self.initial_owner = {
            f"agent-{index + 1:02d}": slot for index, slot in enumerate(INITIAL_PATCHES)
        }
        self.slot_owner: dict[str, str] = {}
        self.actor_slot: dict[str, str] = {}
        self.micro_evidence: dict[str, dict] = {}
        self.probes: dict[str, dict] = {}
        self.publications: dict[str, dict] = {}
        self.notices: list[tuple[str, dict]] = []
        self.questions: dict[str, str] = {}
        self.candidates: dict[str, dict] = {}
        self.stages: dict[str, str] = {}
        self.author, self.used_by = "", ""
        self.outputs = []
        self.plus, self.minus = _paired_frontier_states(seed + 400, physics)

    def bind_interface_questions(self, values):
        self.questions = dict(values)

    def now(self):
        return 0.0

    def _status(self):
        value = {
            "phase": self.phase,
            "claimed_slots": dict(self.slot_owner),
            "published_evidence": sorted(self.publications),
            "model_requests_remaining": self.budget.max_requests - self.model_requests,
        }
        if self.phase == "use":
            value["available_use_candidate"] = self.stages.get("learn", "")
            value["use_requires_an_agent_other_than"] = self.author
        return value

    @staticmethod
    def _agent(actor_id):
        return actor_id.startswith("agent-")

    def tools(self):
        values = {
            "type": "array",
            "items": {"type": "number", "minimum": -1, "maximum": 1},
            "minItems": 3,
            "maxItems": 3,
        }
        evidence = {
            "type": "array",
            "items": {"type": "string", "minLength": 1},
            "maxItems": 12,
            "uniqueItems": True,
        }
        return (
            TaskToolSpec(
                "inspect_collective_study",
                "Read study state and public evidence identities.",
                schema({}),
            ),
            TaskToolSpec(
                "claim_local_cell",
                "Read the current A/B microscopic spins in your assigned local 4x4 cell.",
                schema({"slot": {"type": "string", "enum": list(PATCHES)}}),
                True,
            ),
            TaskToolSpec(
                "probe_boundary_response",
                "Run a finite, separate paired response experiment for the claimed cell's target coupling.",
                schema({}),
                True,
            ),
            TaskToolSpec(
                "publish_evidence",
                "Publish one evidence item unchanged to a Broker for coordination.",
                schema(
                    {
                        "evidence_id": {"type": "string", "minLength": 1},
                        "target_broker": {"type": "string", "enum": list(BROKERS)},
                    }
                ),
                True,
            ),
            TaskToolSpec(
                "submit_collective_forecast",
                "Freeze target forecasts W0, W1 or W2 and cite actually published evidence IDs.",
                schema(
                    {
                        "stage": {
                            "type": "string",
                            "enum": ["baseline", "learn", "revision"],
                        },
                        "world_a": values,
                        "world_b": values,
                        "micro_evidence_ids": evidence,
                        "effective_probe_ids": evidence,
                    }
                ),
                True,
            ),
            TaskToolSpec(
                "use_collective_forecast",
                "Execute W1 once against finite current-world replicas.",
                schema({"candidate_id": {"type": "string", "minLength": 1}}),
                True,
            ),
            TaskToolSpec(
                "deliver_collective_study",
                "Deliver after W2, or explicitly retain W1 when the returned feedback does not warrant revision.",
                schema(
                    {"report": {"type": "string", "minLength": 1, "maxLength": 8000}}
                ),
                True,
            ),
        )

    def _allowed_slot(self, actor_id):
        if actor_id in self.initial_owner:
            return self.initial_owner[actor_id]
        return FRONTIER_PATCH

    def _cell_value(self, slot):
        _, row, column = slot.split("_")
        y, x = int(row) * 4, int(column) * 4
        a, b = self.plus[y : y + 4, x : x + 4], self.minus[y : y + 4, x : x + 4]
        evidence_id = f"micro:{slot}"
        value = {
            "evidence_id": evidence_id,
            "kind": "raw_current_microstate",
            "slot": slot,
            "coordinates": {"rows": [y, y + 3], "columns": [x, x + 3]},
            "world_a_spins": a.tolist(),
            "world_b_spins": b.tolist(),
            "world_a_mean": float(a.mean()),
            "world_b_mean": float(b.mean()),
        }
        self.micro_evidence[evidence_id] = value
        return value

    def file_notices(self):
        values, self.notices = self.notices, []
        for actor_id, payload in values:
            yield (
                actor_id,
                {"interface_question_id": self.questions.get(actor_id, ""), **payload},
            )

    async def poll(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        return []

    async def idle(self):
        self.stop("idle_before_delivery")
        raise SessionStopped(self.stop_reason)

    def stop(self, reason):
        self.stopped, self.stop_reason = True, reason
        self.recorder.emit("ising_collective.stopped", reason=reason, phase=self.phase)

    def before_model(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        if self.model_requests >= self.budget.max_requests:
            self.stop("model_request_limit")
            raise SessionStopped(self.stop_reason)
        used = sum(
            self.recorder.usage()[key] for key in ("prompt_tokens", "completion_tokens")
        )
        if used >= self.budget.max_total_tokens:
            self.stop("reported_token_limit")
            raise SessionStopped(self.stop_reason)
        self.model_requests += 1

    def after_model(self, seconds):
        return None

    async def call(self, name, arguments):
        return ToolResult("error", error="Actor identity is required")

    def _published(self, evidence_ids, store):
        unknown = set(evidence_ids) - set(store)
        unpublished = set(evidence_ids) - set(self.publications)
        if unknown:
            raise ValueError("unknown evidence: " + ", ".join(sorted(unknown)))
        if unpublished:
            raise ValueError(
                "evidence was not published: " + ", ".join(sorted(unpublished))
            )

    async def call_for_actor(self, actor_id, name, arguments, *, question_id=None):
        if not self._agent(actor_id):
            return ToolResult("error", error="Broker cannot operate the physical world")
        try:
            if name == "inspect_collective_study":
                return ToolResult("ok", self._status())
            if name == "claim_local_cell":
                if self.phase != "learn":
                    raise ValueError("local cells open only after W0")
                if actor_id in self.actor_slot:
                    raise ValueError("each Agent has one local cell")
                slot = arguments["slot"]
                if slot != self._allowed_slot(actor_id):
                    raise ValueError(
                        f"this Actor may only claim {self._allowed_slot(actor_id)}"
                    )
                if slot in self.slot_owner:
                    raise ValueError("local cell already claimed")
                self.slot_owner[slot], self.actor_slot[actor_id] = actor_id, slot
                value = self._cell_value(slot)
                self.recorder.emit(
                    "ising_collective.cell_claimed", actor_id=actor_id, slot=slot
                )
                return ToolResult("ok", value)
            if name == "probe_boundary_response":
                if self.phase != "learn" or actor_id not in self.actor_slot:
                    raise ValueError("claim a local cell before probing")
                slot = self.actor_slot[actor_id]
                probe_id = f"probe:{slot}"
                if probe_id not in self.probes:
                    plus, minus = _paired_target_response(
                        self.seed + 800, self.physics, 96
                    )
                    self.probes[probe_id] = {
                        "evidence_id": probe_id,
                        "kind": "finite_separate_boundary_response",
                        "source_slot": slot,
                        "replicas": 96,
                        "horizons": [1, 2, 4],
                        "target_mean_difference": (
                            plus.mean(axis=0) - minus.mean(axis=0)
                        )[[0, 1, 3]].tolist(),
                        "note": "separate calibration preparation; it does not reveal the current target outcome",
                    }
                self.recorder.emit(
                    "ising_collective.probe", actor_id=actor_id, probe_id=probe_id
                )
                return ToolResult("ok", self.probes[probe_id])
            if name == "publish_evidence":
                evidence_id, target = (
                    arguments["evidence_id"],
                    arguments["target_broker"],
                )
                item = self.micro_evidence.get(evidence_id) or self.probes.get(
                    evidence_id
                )
                if item is None:
                    raise ValueError(
                        "only evidence obtained by a task effect can be published"
                    )
                if self.actor_slot.get(actor_id) != item.get(
                    "slot", item.get("source_slot")
                ):
                    raise ValueError("only the evidence holder can publish it")
                if evidence_id in self.publications:
                    raise ValueError("evidence already published")
                self.publications[evidence_id] = {
                    "owner": actor_id,
                    "target_broker": target,
                    "item": item,
                }
                self.notices.append(
                    (
                        target,
                        {
                            "kind": "published_local_evidence",
                            "owner": actor_id,
                            "evidence": item,
                        },
                    )
                )
                self.recorder.emit(
                    "ising_collective.published",
                    actor_id=actor_id,
                    evidence_id=evidence_id,
                    target=target,
                )
                return ToolResult(
                    "ok", {"published": evidence_id, "target_broker": target}
                )
            if name == "submit_collective_forecast":
                stage = arguments["stage"]
                expected = {
                    "baseline": "baseline",
                    "learn": "learn",
                    "revision": "use",
                }[stage]
                if self.phase != expected or stage in self.stages:
                    raise ValueError("forecast stage unavailable")
                if stage == "revision" and actor_id != self.author:
                    raise ValueError("only the W1 author may revise")
                self._published(arguments["micro_evidence_ids"], self.micro_evidence)
                self._published(arguments["effective_probe_ids"], self.probes)
                candidate_id = f"C{len(self.candidates)}"
                self.candidates[candidate_id] = {
                    "stage": stage,
                    "author": actor_id,
                    "world_a": list(arguments["world_a"]),
                    "world_b": list(arguments["world_b"]),
                    "micro_evidence_ids": list(arguments["micro_evidence_ids"]),
                    "effective_probe_ids": list(arguments["effective_probe_ids"]),
                    "slot_claims": dict(self.slot_owner),
                }
                self.stages[stage] = candidate_id
                if stage == "baseline":
                    self.phase = "learn"
                elif stage == "learn":
                    # W0 is only a pre-evidence reference. The position that
                    # actually assembles W1 becomes the later feedback holder.
                    self.author = actor_id
                    self.phase = "use"
                else:
                    self.phase = "final"
                return ToolResult(
                    "ok", {"candidate_id": candidate_id, "status": self._status()}
                )
            if name == "use_collective_forecast":
                candidate_id = arguments["candidate_id"]
                if (
                    self.phase != "use"
                    or candidate_id != self.stages.get("learn")
                    or self.used_by
                ):
                    raise ValueError("W1 is unavailable for use")
                if self.budget.require_cross_position_use and actor_id == self.author:
                    raise ValueError("a different Agent must execute W1")
                self.used_by = actor_id
                plus, minus = _paired_target_response(
                    self.seed + 400, self.physics, 256
                )
                actual_a, actual_b = (
                    plus.mean(axis=0)[[0, 1, 3]],
                    minus.mean(axis=0)[[0, 1, 3]],
                )
                item = self.candidates[candidate_id]
                predicted = np.array(item["world_a"] + item["world_b"])
                actual = np.concatenate((actual_a, actual_b))
                return ToolResult(
                    "ok",
                    {
                        "candidate_id": candidate_id,
                        "executor": actor_id,
                        "actual_a": actual_a.tolist(),
                        "actual_b": actual_b.tolist(),
                        "mse": float(np.mean((predicted - actual) ** 2)),
                        "cited_micro": item["micro_evidence_ids"],
                        "cited_effective": item["effective_probe_ids"],
                        "cross_position_use": actor_id != self.author,
                    },
                )
            if name == "deliver_collective_study":
                if self.phase not in {"use", "final"} or actor_id != self.author:
                    raise ValueError("only the W1 author may deliver after feedback")
                self.outputs.append(
                    {
                        "actor_id": actor_id,
                        "content": arguments["report"],
                        "retained_w1": self.phase == "use",
                    }
                )
                self.stop("completed")
                return ToolResult("ok", {"delivered": True})
            raise ValueError("unknown collective tool")
        except (KeyError, TypeError, ValueError) as exc:
            return ToolResult("error", error=str(exc))

    async def send(self, content, delivery_id):
        return ToolResult("error", error="Use deliver_collective_study")

    def result(self):
        return {
            "phase": self.phase,
            "stop_reason": self.stop_reason,
            "stages": self.stages,
            "candidates": self.candidates,
            "slot_owner": self.slot_owner,
            "micro_evidence": self.micro_evidence,
            "probes": self.probes,
            "publications": self.publications,
            "used_by": self.used_by,
            "outputs": self.outputs,
            "status": self._status(),
        }
