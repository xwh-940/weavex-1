"""Fixed-two-Agent 16x16 regional prediction session."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np

from ..contracts import SessionStopped, TaskToolSpec, ToolResult
from .large_scale_physics import LargeScalePhysics, paired_response


HORIZONS = (1, 2, 4)


@dataclass
class RegionalBudget:
    max_requests: int = 48
    max_total_tokens: int = 1_200_000
    max_experiment_batches: int = 2
    experiment_replicas: int = 64


def schema(properties: dict[str, Any], required=None) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties if required is None else required),
        "additionalProperties": False,
    }


INSTRUCTIONS = """You are studying multi-sweep regional prediction on a periodic 16 by 16
nearest-neighbour binary-spin lattice. The target is a 4 by 4 region. You must predict its
mean spin after 1, 2, and 4 complete checkerboard sweeps in two labeled preparations A and B.
The target's 7 by 7 neighbourhood is the same in A and B at time zero; other authorized
records and finite experiments may reveal whether a more remote difference matters later.

The hidden transition formula and parameters are not supplied. A forecast is six numbers:
the three horizons for A and B. It will be executed on fresh paired worlds exactly as supplied.
The baseline is a pre-data reference; after it, one Agent owns learning access. The other
Agent waits to execute the learned candidate on fresh data. A post-use revision may change
or retain the forecast, but must be grounded in the finite use result. Do not call a task tool
without first receiving your current input.
""".strip()


class RegionalSession:
    scope = "ising-regional-16x16-v1"
    instructions = INSTRUCTIONS

    def __init__(self, *, seed: int, physics: LargeScalePhysics, recorder, budget=None):
        self.seed, self.physics, self.recorder = seed, physics, recorder
        self.budget = budget or RegionalBudget()
        self.stopped = False
        self.stop_reason = ""
        self.phase = "baseline"
        self.model_requests = self.experiment_batches = 0
        self.learning_owner = ""
        self.candidates: dict[str, dict[str, Any]] = {}
        self.authors: dict[str, str] = {}
        self.stages: dict[str, str] = {}
        self.used_by = ""
        self.outputs = []
        self.notices: list[tuple[str, dict]] = []
        self.questions: dict[str, str] = {}

    def bind_interface_questions(self, values):
        self.questions = dict(values)

    def now(self):
        return 0.0

    def _status(self):
        return {
            "phase": self.phase,
            "learning_owner": self.learning_owner or None,
            "experiment_batches_remaining": self.budget.max_experiment_batches
            - self.experiment_batches,
            "model_requests_remaining": self.budget.max_requests - self.model_requests,
        }

    def tools(self):
        forecasts = {
            "type": "array",
            "items": {"type": "number", "minimum": -1, "maximum": 1},
            "minItems": 3,
            "maxItems": 3,
        }
        return (
            TaskToolSpec(
                "inspect_regional_study",
                "Read the current study phase and remaining resources.",
                schema({}),
            ),
            TaskToolSpec(
                "read_regional_training",
                "Read the learning holder's finite paired regional-response summary.",
                schema({}),
            ),
            TaskToolSpec(
                "run_regional_experiment",
                "Spend one shared finite paired-response experiment batch.",
                schema({}),
                True,
            ),
            TaskToolSpec(
                "submit_regional_forecast",
                "Freeze six regional mean forecasts for a measurement stage.",
                schema(
                    {
                        "stage": {
                            "type": "string",
                            "enum": ["baseline", "learn", "revision"],
                        },
                        "world_a": forecasts,
                        "world_b": forecasts,
                    }
                ),
                True,
            ),
            TaskToolSpec(
                "use_regional_forecast",
                "A non-author executes the frozen learned regional forecast on fresh paired worlds.",
                schema({"candidate_id": {"type": "string"}}),
                True,
            ),
            TaskToolSpec(
                "deliver_regional_study",
                "Deliver the final account after the revision forecast is frozen.",
                schema(
                    {"report": {"type": "string", "minLength": 1, "maxLength": 8000}}
                ),
                True,
            ),
        )

    def _response(self, seed, replicas):
        return paired_response(seed, self.physics, replicas=replicas, sweeps=4)

    @staticmethod
    def _summary(response):
        return {
            key: response[key]
            for key in (
                "replicas",
                "sweeps",
                "mean_plus",
                "mean_minus",
                "paired_standard_error",
            )
        }

    def _notice(self, actor_id, payload):
        self.notices.append((actor_id, payload))

    def file_notices(self):
        values, self.notices = self.notices, []
        for actor_id, payload in values:
            yield (
                actor_id,
                {"interface_question_id": self.questions.get(actor_id, ""), **payload},
            )

    async def poll(self):
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        return []

    async def idle(self):
        self.stop("idle_before_final_delivery")
        raise SessionStopped(self.stop_reason)

    def stop(self, reason):
        self.stopped, self.stop_reason = True, reason
        self.recorder.emit("ising_regional.stopped", reason=reason, phase=self.phase)

    def before_model(self):
        usage = self.recorder.usage()
        if self.stopped:
            raise SessionStopped(self.stop_reason)
        if self.model_requests >= self.budget.max_requests:
            self.stop("model_request_limit")
            raise SessionStopped(self.stop_reason)
        if (
            usage["prompt_tokens"] + usage["completion_tokens"]
            >= self.budget.max_total_tokens
        ):
            self.stop("reported_token_limit")
            raise SessionStopped(self.stop_reason)
        self.model_requests += 1

    def after_model(self, seconds):
        return None

    async def call(self, name, arguments):
        return ToolResult("error", error="Actor identity is required")

    def _candidate(self, candidate_id):
        item = self.candidates[candidate_id]
        return {
            "candidate_id": candidate_id,
            "stage": item["stage"],
            "world_a": item["world_a"],
            "world_b": item["world_b"],
            "author": self.authors[candidate_id],
        }

    async def call_for_actor(self, actor_id, name, arguments, *, question_id=None):
        if actor_id not in {"agent-left", "agent-right"}:
            return ToolResult("error", error="Broker cannot operate the physical study")
        try:
            if name == "inspect_regional_study":
                return ToolResult("ok", self._status())
            if name in {"read_regional_training", "run_regional_experiment"}:
                if actor_id != self.learning_owner or self.phase != "learn":
                    raise ValueError(
                        "training access belongs only to the current learning holder"
                    )
                if name == "read_regional_training":
                    return ToolResult(
                        "ok", self._summary(self._response(self.seed + 100, 128))
                    )
                if self.experiment_batches >= self.budget.max_experiment_batches:
                    raise ValueError("shared regional experiment allowance exhausted")
                self.experiment_batches += 1
                return ToolResult(
                    "ok",
                    self._summary(
                        self._response(
                            self.seed + 1000 + self.experiment_batches,
                            self.budget.experiment_replicas,
                        )
                    ),
                )
            if name == "submit_regional_forecast":
                stage = arguments["stage"]
                required_phase = {
                    "baseline": "baseline",
                    "learn": "learn",
                    "revision": "use",
                }[stage]
                if self.phase != required_phase or stage in self.stages:
                    raise ValueError("forecast stage is unavailable")
                if stage != "baseline" and actor_id != self.learning_owner:
                    raise ValueError("only the learning holder may freeze this stage")
                if stage == "revision" and not self.used_by:
                    raise ValueError("fresh use must occur before revision")
                candidate_id = f"R{len(self.candidates)}"
                self.candidates[candidate_id] = {
                    "stage": stage,
                    "world_a": list(arguments["world_a"]),
                    "world_b": list(arguments["world_b"]),
                }
                self.authors[candidate_id] = actor_id
                self.stages[stage] = candidate_id
                if stage == "baseline":
                    self.phase, self.learning_owner = "learn", actor_id
                    self._notice(
                        actor_id,
                        {
                            "kind": "regional_learning_open",
                            "training": self._summary(
                                self._response(self.seed + 100, 128)
                            ),
                            "status": self._status(),
                        },
                    )
                    self._notice(
                        "agent-right" if actor_id == "agent-left" else "agent-left",
                        {"kind": "await_regional_candidate", "status": self._status()},
                    )
                elif stage == "learn":
                    self.phase = "use"
                    other = "agent-right" if actor_id == "agent-left" else "agent-left"
                    self._notice(
                        other,
                        {
                            "kind": "regional_candidate_ready",
                            "candidate": self._candidate(candidate_id),
                            "status": self._status(),
                        },
                    )
                else:
                    self.phase = "final"
                    self._notice(
                        actor_id,
                        {
                            "kind": "regional_revision_ready",
                            "candidate": self._candidate(candidate_id),
                            "status": self._status(),
                        },
                    )
                return ToolResult(
                    "ok",
                    {
                        "candidate": self._candidate(candidate_id),
                        "status": self._status(),
                    },
                )
            if name == "use_regional_forecast":
                candidate_id = arguments["candidate_id"]
                if (
                    self.phase != "use"
                    or candidate_id != self.stages.get("learn")
                    or actor_id == self.authors[candidate_id]
                    or self.used_by
                ):
                    raise ValueError(
                        "only the non-author may execute the current learned forecast once"
                    )
                self.used_by = actor_id
                observed = self._response(self.seed + 200, 256)
                candidate = self.candidates[candidate_id]
                a, b = np.array(candidate["world_a"]), np.array(candidate["world_b"])
                actual_a = np.array(observed["mean_plus"])[[0, 1, 3]]
                actual_b = np.array(observed["mean_minus"])[[0, 1, 3]]
                result = {
                    "candidate_id": candidate_id,
                    "executor": actor_id,
                    "predicted_a": a.tolist(),
                    "predicted_b": b.tolist(),
                    "observed_a": actual_a.tolist(),
                    "observed_b": actual_b.tolist(),
                    "mse": float(
                        np.mean(
                            np.concatenate(((a - actual_a) ** 2, (b - actual_b) ** 2))
                        )
                    ),
                    "standard_error": np.array(observed["paired_standard_error"])[
                        [0, 1, 3]
                    ].tolist(),
                }
                self._notice(
                    self.authors[candidate_id],
                    {
                        "kind": "regional_fresh_use_result",
                        **result,
                        "status": self._status(),
                    },
                )
                return ToolResult("ok", result)
            if name == "deliver_regional_study":
                if self.phase != "final" or actor_id != self.learning_owner:
                    raise ValueError(
                        "only the learning holder may deliver after revision"
                    )
                self.outputs.append(
                    {"actor_id": actor_id, "content": arguments["report"]}
                )
                self.stop("completed")
                return ToolResult("ok", {"delivered": True})
            raise ValueError("Unknown regional tool")
        except (KeyError, TypeError, ValueError) as exc:
            return ToolResult("error", error=str(exc))

    async def send(self, content, delivery_id):
        return ToolResult("error", error="Use deliver_regional_study")

    def result(self):
        return {
            "phase": self.phase,
            "stop_reason": self.stop_reason,
            "stages": dict(self.stages),
            "authors": dict(self.authors),
            "candidates": {
                candidate_id: {
                    "stage": value["stage"],
                    "world_a": list(value["world_a"]),
                    "world_b": list(value["world_b"]),
                }
                for candidate_id, value in self.candidates.items()
            },
            "used_by": self.used_by,
            "outputs": list(self.outputs),
            "status": self._status(),
        }
