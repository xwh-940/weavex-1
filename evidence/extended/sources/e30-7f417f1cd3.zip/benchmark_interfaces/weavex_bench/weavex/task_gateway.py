"""The only external-effect dispatcher; core responsibilities stay in Runtime."""

import hashlib
import re

from jsonschema import Draft202012Validator, ValidationError
from weavex.execution import ToolExecution
from weavex.protocol import Observation

from ..contracts import SessionStopped
from ..reporting import json_value


def tool_name(name: str) -> str:
    clean = re.sub(r"[^a-zA-Z0-9_-]", "_", name)
    return "task__" + clean[:42] + "_" + hashlib.sha256(name.encode()).hexdigest()[:8]


class TaskGateway:
    def __init__(self, session, recorder):
        self.session, self.recorder = session, recorder
        self.specs = {tool_name(spec.name): spec for spec in session.tools()}
        if len(self.specs) != len(session.tools()):
            raise ValueError("Duplicate external tools")
        self.execution_guard = None
        for spec in self.specs.values():
            Draft202012Validator.check_schema(spec.parameters)

    def schemas(self, actor):
        if actor.role != "agent":
            return []
        return [
            {
                "type": "function",
                "function": {
                    "name": name,
                    "description": spec.description,
                    "parameters": {
                        "type": "object",
                        "additionalProperties": False,
                        "properties": {
                            "question_id": {"type": "string"},
                            "arguments": spec.parameters,
                        },
                        "required": ["question_id", "arguments"],
                        **(
                            {"$defs": spec.parameters["$defs"]}
                            if "$defs" in spec.parameters
                            else {}
                        ),
                    },
                },
            }
            for name, spec in self.specs.items()
        ]

    async def execute(self, host, proposal):
        try:
            if host.turn_ended or not host.input_received:
                raise PermissionError(
                    "Task actions require receive_input and an active turn"
                )
            if host.actor_spec.role != "agent":
                raise PermissionError("No task grant for this Actor")
            schema = next(
                (
                    t["function"]["parameters"]
                    for t in self.schemas(host.actor_spec)
                    if t["function"]["name"] == proposal.name
                ),
                None,
            )
            if schema is None:
                raise PermissionError("Unknown task tool")
            Draft202012Validator(schema).validate(dict(proposal.arguments))
            question = proposal.arguments["question_id"]
            if question not in {
                q.act_id for q in host.situation().answer_responsibilities
            }:
                raise PermissionError(
                    "Task action requires this Actor's current direct Question responsibility"
                )
            if self.execution_guard:
                reason = self.execution_guard(host, self.specs[proposal.name])
                if reason:
                    raise PermissionError(reason)
        except (PermissionError, ValidationError) as exc:
            self.recorder.emit(
                "task.rejected",
                actor_id=host.actor_id,
                call_id=proposal.call_id,
                tool=proposal.name,
                error=str(exc),
                simulated_time=self.session.now(),
            )
            return ToolExecution(Observation(proposal.name, False, error=str(exc)))
        spec = self.specs[proposal.name]
        self.recorder.emit(
            "task.request",
            actor_id=host.actor_id,
            call_id=proposal.call_id,
            tool=spec.name,
            write=spec.write,
            activation_id=host.activation_id,
            arguments=proposal.arguments["arguments"],
            simulated_time=self.session.now(),
        )
        arguments = dict(proposal.arguments["arguments"])
        if hasattr(self.session, "call_for_actor"):
            result = await self.session.call_for_actor(
                host.actor_id, spec.name, arguments, question_id=question
            )
        else:
            result = await self.session.call(spec.name, arguments)
        raw = json_value(result.value)
        self.recorder.emit(
            "task.result",
            actor_id=host.actor_id,
            call_id=proposal.call_id,
            tool=spec.name,
            status=result.status,
            value=raw,
            error=result.error,
            simulated_time=self.session.now(),
        )
        if result.status == "unknown":
            raise SessionStopped(
                f"Unknown external effect; no automatic retry: {result.error}"
            )
        value = {"result": raw, "status": result.status}
        return ToolExecution(
            Observation(
                proposal.name, result.status == "ok", value=value, error=result.error
            )
        )
