"""Observe real outward Acts and report independent external delivery effects."""

from dataclasses import replace

from weavex.communication import emit_act

from ..contracts import SessionStopped


class OutputBridge:
    def __init__(self, runtime, session, recorder):
        self.runtime, self.session, self.recorder = runtime, session, recorder
        self.deliveries = {}
        self.outputs = []

    async def deliver(self, observation):
        if observation.source not in {"send_act", "reply_act"} or not isinstance(
            observation.value, dict
        ):
            return observation
        act_id = observation.value.get("act_id")
        if not act_id:
            return observation
        act = self.runtime.inquiry.act(act_id)
        if act.recipient != "human" or act.kind not in {"answer", "incremental"}:
            return observation
        if act_id not in self.deliveries:
            text = act.payload.get("answer" if act.kind == "answer" else "content", "")
            started = self.session.now()
            result = await self.session.send(text, act_id)
            self.deliveries[act_id] = result
            self.recorder.emit(
                "output.delivery",
                act_id=act_id,
                content=text,
                result=result,
                started_at=started,
                simulated_time=self.session.now(),
            )
            if result.status == "unknown":
                raise SessionStopped(
                    "User delivery effect unknown; automatic resend disabled"
                )
            if result.status == "ok":
                self.outputs.append(text)
            else:
                emit_act(
                    self.runtime,
                    thread_id=act.thread_id,
                    kind="environment_notice",
                    sender=f"benchmark:{self.session.scope}",
                    recipient=act.sender,
                    reply_to=act.act_id,
                    payload={
                        "content": f"External delivery failed for {act_id}: {result.error}"
                    },
                )
        result = self.deliveries[act_id]
        return replace(
            observation,
            value={
                **observation.value,
                "external_delivery": {"status": result.status, "error": result.error},
            },
        )
