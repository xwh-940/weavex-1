"""Composition against existing WeaveX extension points."""
