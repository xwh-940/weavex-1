"""Cooperative execution of unchanged Runtime.step coroutines.

FIFO arrivals are started by Runtime itself. One Actor has at most one live
activation, and only one complete model/effect round can run at a time. A parked
activation retains its Host and coroutine; no fabricated yield or requeued Act.
"""

import asyncio
from collections import deque
from dataclasses import dataclass

from weavex.arrival import arrival_id, arrival_recipient


@dataclass
class Permit:
    actor_id: str
    future: asyncio.Future


class CooperativeScheduler:
    def __init__(self, runtime, session, recorder, receive_pending):
        self.runtime, self.session, self.recorder = runtime, session, recorder
        self.receive_pending = receive_pending
        self.active = {}
        self.ready = deque()
        self.boundary = asyncio.Event()
        self.running_task = None
        self.enabled = False
        self.last_status = {}

    async def checkpoint(self, host):
        if not self.enabled:
            return
        task = asyncio.current_task()
        if self.active.get(host.actor_id) is not task:
            raise RuntimeError("Activation is not owned by this scheduler")
        future = asyncio.get_running_loop().create_future()
        self.ready.append(Permit(host.actor_id, future))
        if self.running_task is task:
            self.boundary.set()
        await future

    def pending_input_count(self, actor_id):
        return sum(arrival_recipient(item) == actor_id for item in self.runtime.queue)

    def other_work(self, actor_id):
        return bool(self.runtime.queue) or any(
            p.actor_id != actor_id and not p.future.done() for p in self.ready
        )

    def task_rejection(self, host, spec):
        if not self.enabled:
            return None
        if self.pending_input_count(host.actor_id):
            return (
                "New input is pending for this Actor. Finish this activation with "
                "yield_turn, then receive_input in the next activation before further task effects."
            )
        if spec.waits_for_input and self.other_work(host.actor_id):
            return (
                "Environment waiting is deferred while participant work is runnable. "
                "Give other Actors an opportunity to respond; use yield_turn when awaiting input."
            )
        return None

    def actor_status(self, host):
        count = self.pending_input_count(host.actor_id) if self.enabled else 0
        if not self.enabled or not host.input_received:
            return None
        state = (host.activation_id, count)
        if self.last_status.get(host.actor_id) == state:
            return None
        self.last_status[host.actor_id] = state
        return {
            "kind": "benchmark_execution_status",
            "source": "interface_scheduler",
            "activation_id": host.activation_id,
            "pending_input_for_this_actor": count,
            "task_effects_deferred": bool(count),
            "instruction": (
                "Your current activation already received input. New arrivals are queued for "
                "this Actor. Use yield_turn to let the next activation receive them. "
                "Task tools are deferred. "
                "This is execution metadata, not a new user task or a judgment about its answer."
            )
            if count
            else (
                "This Actor has no queued new input at this boundary. This status supersedes "
                "earlier pending-input statuses. Continue under the current Question responsibilities. "
                "This says nothing about task completion or whether future input is expected."
            ),
        }

    def _done(self, task):
        if task is self.running_task:
            self.boundary.set()

    def _reap(self):
        for actor_id, task in list(self.active.items()):
            if task.done():
                del self.active[actor_id]
                task.result()  # Propagate actual failures; never relabel them as idle.

    async def _start_arrivals(self):
        while self.runtime.queue:
            arrival = self.runtime.queue[0]
            actor_id = arrival_recipient(arrival)
            if actor_id in self.active:
                break  # Keep FIFO, including head-of-line blocking until model yield.
            self.recorder.emit(
                "scheduler.activation_started",
                actor_id=actor_id,
                activation_id=arrival_id(arrival),
                simulated_time=self.session.now(),
            )
            task = asyncio.create_task(self.runtime.step(), name=f"weavex:{actor_id}")
            self.active[actor_id] = task
            task.add_done_callback(self._done)
            # Runtime.step pops the FIFO head and parks at the first checkpoint.
            await asyncio.sleep(0)
            self._reap()

    async def run(self):
        self.enabled = True
        try:
            while True:
                self._reap()
                await self.receive_pending()
                await self._start_arrivals()
                while self.ready and self.ready[0].future.done():
                    self.ready.popleft()
                if not self.ready:
                    if self.active:
                        raise RuntimeError(
                            "Active turns must be parked at round checkpoints"
                        )
                    await self.session.idle()
                    continue
                permit = self.ready.popleft()
                self.running_task = self.active[permit.actor_id]
                self.boundary.clear()
                self.recorder.emit(
                    "scheduler.round_granted",
                    actor_id=permit.actor_id,
                    simulated_time=self.session.now(),
                )
                permit.future.set_result(None)
                await self.boundary.wait()
                self.running_task = None
        finally:
            # Normal exit occurs at a completed round, so no task effect is cut in half.
            for task in self.active.values():
                if not task.done():
                    task.cancel()
            await asyncio.gather(*self.active.values(), return_exceptions=True)
            self.active.clear()
            self.ready.clear()
            self.running_task = None
            self.enabled = False
