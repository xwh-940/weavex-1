"""Retain provider-native per-Actor transport with the actual combined schemas."""

from time import perf_counter
from contextvars import ContextVar
from types import SimpleNamespace

from weavex.provider import OpenAICompatibleModel


class BenchmarkModel(OpenAICompatibleModel):
    def __init__(self, client, *, session, gateway, recorder, **kwargs):
        self._raw_client = client
        self._request_identity = ContextVar("benchmark_model_request")
        self._unexecuted_messages = {}
        proxy = SimpleNamespace(
            chat=SimpleNamespace(
                completions=SimpleNamespace(create=self._create_completion)
            )
        )
        super().__init__(proxy, **kwargs)
        self.session = session
        self.gateway = gateway
        self.recorder = recorder

    async def _create_completion(self, **kwargs):
        response = await self._raw_client.chat.completions.create(**kwargs)
        actor_id, activation_id = self._request_identity.get()
        choice = response.choices[0]
        if hasattr(choice.message, "model_dump"):
            message = choice.message.model_dump(exclude_none=True)
        else:
            # Preserve the attribute-based provider contract used by core and tests.
            message = {"role": getattr(choice.message, "role", "assistant")}
            for key in ("content", "reasoning_content"):
                value = getattr(choice.message, key, None)
                if value is not None:
                    message[key] = value
            if getattr(choice.message, "tool_calls", None):
                message["tool_calls"] = [
                    {
                        "id": call.id,
                        "type": "function",
                        "function": {
                            "name": call.function.name,
                            "arguments": call.function.arguments,
                        },
                    }
                    for call in choice.message.tool_calls
                ]
        self.recorder.emit(
            "model.raw_response",
            actor_id=actor_id,
            activation_id=activation_id,
            message=message,
            finish_reason=getattr(choice, "finish_reason", None),
        )
        if not message.get("tool_calls"):
            self._unexecuted_messages[actor_id] = {
                k: v
                for k, v in message.items()
                if k in {"role", "content", "reasoning_content"}
            }
        return response

    def take_unexecuted_message(self, actor_id):
        return self._unexecuted_messages.pop(actor_id, None)

    def protocol_tools(self, value):
        return super().protocol_tools(value) + self.gateway.schemas(value.actor)

    async def decide(self, value):
        self.session.before_model()
        identity_token = self._request_identity.set(
            (value.actor.actor_id, value.activation_id)
        )
        # These records are private evaluation artifacts, never Actor input.
        self.recorder.emit(
            "model.request",
            actor_id=value.actor.actor_id,
            activation_id=value.activation_id,
            messages=self._provider_messages(value),
            tools=self.protocol_tools(value),
            model=self.model,
            max_tokens=self.max_tokens,
            thinking="enabled",
            simulated_time=self.session.now(),
        )
        start = perf_counter()
        error = ""
        try:
            proposal = await super().decide(value)
            self.recorder.emit(
                "model.response",
                actor_id=value.actor.actor_id,
                tool_name=proposal.name,
                arguments=dict(proposal.arguments),
                assistant_content=proposal.assistant_content,
                transport=self._actor_transport.get(value.actor.actor_id, {}).get(
                    proposal.call_id, {}
                ),
            )
            return proposal
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            self._request_identity.reset(identity_token)
            seconds = perf_counter() - start
            self.session.after_model(seconds)
            usage = self.take_provider_usage(value.actor.actor_id, value.activation_id)
            self.recorder.emit(
                "model.result",
                actor_id=value.actor.actor_id,
                seconds=seconds,
                usage=usage,
                error=error,
                simulated_time=self.session.now(),
            )
