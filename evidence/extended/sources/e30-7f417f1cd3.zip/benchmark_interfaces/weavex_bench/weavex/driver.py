"""External turn loop using unmodified Host effects and native delivery cursors."""

import itertools
from openai import (
    APIConnectionError,
    APITimeoutError,
    RateLimitError,
    InternalServerError,
)

from weavex.dialogue import (
    assistant_raw_tool_call_message,
    assistant_tool_call_message,
    decision_tool_proposal,
    tool_message,
    turn_message,
)
from weavex.execution import ToolProposal
from weavex.protocol import ModelToolCall, ModelToolCallEnvelope
from weavex.provider import ModelNoToolCall, ModelToolRejection
from weavex.runner import NativeTurnDriver

from ..contracts import SessionStopped
from ..reporting import dumps


class BenchmarkTurnDriver(NativeTurnDriver):
    def __init__(self, model, tools, gateway, recorder, *, max_rounds=None):
        super().__init__(model, tools, max_rounds=max_rounds or 12)
        self.round_limit = max_rounds
        self.gateway, self.recorder = gateway, recorder
        self.output_bridge = None
        self.stopped = lambda: False
        self.before_round = None
        self.checkpoint = None
        self.execution_status = None
        self.transport_retries = 0

    async def activate(self, host):
        try:
            await super().activate(host)
        except SessionStopped as exc:
            if not self.stopped():
                raise
            host.trace("benchmark.activation.stopped", {"reason": str(exc)})

    async def _activate(self, host):
        observations = []
        session = self._session_for(host.actor_id)
        session.dialogue.append(turn_message())
        self.gateway.schemas(host.actor_spec)
        transport_failures = 0
        for round_number in itertools.count(1):
            if self.checkpoint:
                await self.checkpoint(host)
            if self.before_round:
                await self.before_round()
            if self.stopped():
                raise SessionStopped("Official environment stopped")
            if self.round_limit is not None and round_number > self.round_limit:
                raise RuntimeError(
                    f"Actor {host.actor_id} exceeded {self.round_limit} rounds"
                )
            if self.execution_status:
                status = self.execution_status(host)
                if status:
                    session.dialogue.append({"role": "user", "content": dumps(status)})
                    self.recorder.emit(
                        "scheduler.actor_status",
                        actor_id=host.actor_id,
                        activation_id=host.activation_id,
                        status=status,
                    )
            value = self.model_input(
                host,
                tuple(observations),
                host.capability_catalog(),
                dialogue_includes_turn=True,
                input_received=host.input_received,
            )
            try:
                decision = await self.model.decide(value)
                transport_failures = 0
            except (
                APIConnectionError,
                APITimeoutError,
                RateLimitError,
                InternalServerError,
            ) as exc:
                transport_failures += 1
                if transport_failures > self.transport_retries:
                    raise
                session.dialogue.append(
                    {
                        "role": "user",
                        "content": "The model request failed in transport; no tool proposal was executed. "
                        "Time and the request attempt were still counted. Reconsider currently delivered input before acting.",
                    }
                )
                self.recorder.emit(
                    "transport.retry",
                    actor_id=host.actor_id,
                    attempt=transport_failures,
                    error=str(exc),
                    simulated_time=self.gateway.session.now(),
                )
                continue
            except ModelNoToolCall as missing:
                # A text-only or output-truncated response is not a business effect.
                # Preserve provider-native transport and allow a counted next round,
                # matching the persistent comparator's handling of this condition.
                native = None
                if hasattr(self.model, "take_unexecuted_message"):
                    native = self.model.take_unexecuted_message(host.actor_id)
                session.dialogue.append(
                    native
                    or {"role": "assistant", "content": missing.assistant_content}
                )
                session.dialogue.append(
                    {
                        "role": "user",
                        "content": "No tool was called and no external effect occurred. Continue with an available tool, or yield_turn to wait for input.",
                    }
                )
                self.recorder.emit(
                    "model.no_tool",
                    actor_id=host.actor_id,
                    activation_id=host.activation_id,
                    assistant_content=missing.assistant_content,
                )
                continue
            except ModelToolRejection as rejection:
                assistant, call_id = assistant_raw_tool_call_message(
                    rejection.tool_call,
                    fallback_call_id=session.new_call_id(host.actor_id),
                    content=rejection.assistant_content,
                )
                session.dialogue.append(assistant)
                observation = host.rejected_observation(
                    rejection.tool_call.name, str(rejection)
                )
                session.dialogue.append(tool_message(call_id, observation))
                observations.append(observation)
                continue
            finally:
                self._trace_provider_usage(host, round_number)
            call_id = session.new_call_id(host.actor_id)
            proposal = (
                ToolProposal(
                    decision.call_id or call_id,
                    decision.name,
                    decision.arguments,
                    decision.assistant_content,
                )
                if isinstance(decision, ToolProposal)
                else decision_tool_proposal(
                    decision,
                    actor_role=host.actor_spec.role,
                    fallback_call_id=call_id,
                    fallback_reply_to=host.activation_id,
                    fallback_question_id=host.default_question_id(),
                )
            )
            external = proposal.name.startswith("task__")
            if external:
                assistant, call_id = assistant_raw_tool_call_message(
                    ModelToolCallEnvelope(
                        proposal.call_id, proposal.name, dumps(dict(proposal.arguments))
                    ),
                    fallback_call_id=proposal.call_id,
                    content=proposal.assistant_content,
                )
            else:
                assistant, call_id = assistant_tool_call_message(
                    ModelToolCall(proposal.call_id, proposal.name, proposal.arguments),
                    fallback_call_id=proposal.call_id,
                    content=proposal.assistant_content,
                )
            session.dialogue.append(assistant)
            host.trace(
                "model.decision",
                {
                    "round": round_number,
                    "tool_name": proposal.name,
                    "arguments": dict(proposal.arguments),
                    "assistant_content": proposal.assistant_content,
                },
            )
            received = host.input_received
            self.recorder.emit(
                "core.tool_start" if not external else "activation.task_start",
                actor_id=host.actor_id,
                activation_id=host.activation_id,
                call_id=call_id,
                tool=proposal.name,
                simulated_time=self.gateway.session.now(),
            )
            execution = (
                await self.gateway.execute(host, proposal)
                if external
                else await host.execute(proposal)
            )
            observation = execution.observation
            if not external:
                self.recorder.emit(
                    "core.tool_end",
                    actor_id=host.actor_id,
                    activation_id=host.activation_id,
                    call_id=call_id,
                    tool=proposal.name,
                    ok=observation.ok,
                    value=observation.value,
                    simulated_time=self.gateway.session.now(),
                )
            if proposal.name == "receive_input" and observation.ok:
                self.recorder.emit(
                    "core.input_received",
                    actor_id=host.actor_id,
                    activation_id=host.activation_id,
                    simulated_time=self.gateway.session.now(),
                )
            if self.output_bridge and not external and observation.ok:
                observation = await self.output_bridge.deliver(observation)
            if external:
                session.dialogue.append(
                    {
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": dumps(
                            {
                                "source": observation.source,
                                "ok": observation.ok,
                                "value": observation.value,
                                "error": observation.error,
                            }
                        ),
                    }
                )
            else:
                session.dialogue.append(
                    tool_message(call_id, session.project_observation(observation))
                )
            if received and proposal.name not in {"receive_input", "yield_turn"}:
                observations.append(observation)
            if execution.turn_ended:
                return
