"""Fresh Runtime per external participant; persistent Actors within a scenario."""

import asyncio
from dataclasses import replace

from weavex.capabilities import build_default_tools
from weavex.defaults import broker_spec
from weavex.initialization import InitialActor, initialize_runtime
from weavex.local_world import LocalWorlds
from weavex.prompts import AGENT_INSTRUCTIONS
from weavex.runtime import PrototypeRuntime

from ..contracts import RunResult, SessionStopped
from ..reporting import save_json
from .driver import BenchmarkTurnDriver
from .input_bridge import InputBridge
from .model_port import BenchmarkModel
from .output_bridge import OutputBridge
from .task_gateway import TaskGateway
from .scheduler import CooperativeScheduler


INTERFACE_INSTRUCTIONS = """
External task tools are available to Semantic Agents, not Brokers. A task effect requires
receive_input and the calling Agent's current direct question_id; task tools do not spend
world_ops. An OR statement, message or Answer does not perform an external business effect.
Task results remain in the caller's dialogue. Environment notices are raw, nonreplyable facts.
Outward Acts to human are delivered only after a successful external send effect. Yielding
lets queued work proceed; idle does not prove task success.
""".strip()

SCHEDULER_INSTRUCTIONS = """
At model/tool round boundaries the interface may pause an activation to run another
Actor. This preserves the Host and private dialogue and is not yield_turn. When this
Actor has queued new input, yield_turn is needed to finish the current activation so
the next one can call receive_input. A scheduler status message reports only this
Actor's pending inbox count, not the meaning or contents of the new input.
Task tools are deferred while this Actor has pending input; environment wait tools
are also deferred while other participant work is runnable. Core tools remain governed
by the original Host. No synthetic Answer, yield, grounding or budget refill is added.
""".strip()


class Participant:
    def __init__(
        self,
        session,
        recorder,
        *,
        client=None,
        model=None,
        model_port=None,
        max_tokens=None,
        max_rounds=None,
        initial_actors: tuple[InitialActor, ...] | None = None,
    ):
        self.session, self.recorder = session, recorder
        gateway = TaskGateway(session, recorder)
        if model_port is None and (
            client is None or model is None or max_tokens is None
        ):
            raise ValueError("Provide client, model and max_tokens, or a model_port")
        port = model_port or BenchmarkModel(
            client,
            session=session,
            gateway=gateway,
            recorder=recorder,
            model=model,
            max_tokens=max_tokens,
        )
        tools = build_default_tools()
        self.driver = BenchmarkTurnDriver(
            port, tools, gateway, recorder, max_rounds=max_rounds
        )
        self.driver.transport_retries = 2
        instructions = "\n\n".join(
            (INTERFACE_INSTRUCTIONS, SCHEDULER_INSTRUCTIONS, session.instructions)
        )
        self.runtime = PrototypeRuntime(
            self.driver,
            tools,
            local_worlds=LocalWorlds(),
            broker_id=next(
                (
                    item.spec.actor_id
                    for item in initial_actors or ()
                    if item.spec.role == "broker"
                ),
                "broker",
            ),
            agent_base_instructions=AGENT_INSTRUCTIONS + "\n\n" + instructions,
        )
        if initial_actors is None:
            spec = broker_spec()
            self.runtime.register_actor(
                replace(spec, instructions=spec.instructions + "\n" + instructions)
            )
            self.runtime.freeze_initial_actors()
        else:
            declarations = tuple(
                InitialActor(
                    replace(
                        item.spec,
                        instructions=item.spec.instructions + "\n\n" + instructions,
                    ),
                    item.question,
                    item.budget,
                )
                for item in initial_actors
            )
            questions = initialize_runtime(self.runtime, declarations)
            if hasattr(session, "bind_interface_questions"):
                session.bind_interface_questions(
                    {question.recipient: question.act_id for question in questions}
                )
        self.input = InputBridge(self.runtime, session.scope, recorder)
        self.input.clock = session.now
        self.output = OutputBridge(self.runtime, session, recorder)
        self.driver.output_bridge = self.output
        self.driver.stopped = lambda: getattr(session, "stopped", False)
        self.driver.before_round = self.receive_pending
        self.scheduler = CooperativeScheduler(
            self.runtime, session, recorder, self.receive_pending
        )
        self.driver.checkpoint = self.scheduler.checkpoint
        self.driver.execution_status = self.scheduler.actor_status
        gateway.execution_guard = self.scheduler.task_rejection

    async def receive_pending(self):
        if getattr(self.session, "stopped", False):
            raise SessionStopped("External session stopped")
        for event in await self.session.poll():
            self.input.accept(event)
        if hasattr(self.session, "file_notices"):
            from weavex.communication import emit_act
            from ..reporting import dumps

            for actor_id, notice in self.session.file_notices():
                question_id = notice.get("interface_question_id")
                q = self.runtime.inquiry.act(question_id) if question_id else None
                if q is None:
                    # Dynamically created Agents are not part of the initial
                    # declaration map.  A Session notice may still be delivered,
                    # but only after the ordinary Runtime Question exists.
                    candidates = self.runtime.inquiry.direct_questions(actor_id)
                    q = next(
                        (
                            item
                            for item in reversed(candidates)
                            if not self.runtime.inquiry.question_has_direct_answer(item)
                        ),
                        None,
                    )
                if q is None or q.recipient != actor_id or q.kind != "question":
                    self.recorder.emit(
                        "file_notice.undeliverable", actor_id=actor_id, notice=notice
                    )
                    continue
                act = emit_act(
                    self.runtime,
                    thread_id=q.thread_id,
                    kind="environment_notice",
                    sender=f"benchmark:{self.session.scope}",
                    recipient=actor_id,
                    reply_to=q.act_id,
                    payload={"content": dumps(notice)},
                )
                self.recorder.emit(
                    "file_notice.delivered",
                    actor_id=actor_id,
                    act_id=act.act_id,
                    notice=notice,
                    simulated_time=self.session.now(),
                )

    async def run(self):
        status, error = "environment_stopped", ""
        try:
            await self.scheduler.run()
        except SessionStopped as exc:
            error = str(exc)
            if not getattr(self.session, "stopped", False):
                status = "execution_failed"
        except asyncio.CancelledError:
            status, error = "interrupted", "Participant cancelled"
            raise
        except Exception as exc:
            status, error = "execution_failed", f"{type(exc).__name__}: {exc}"
            raise
        finally:
            self.recorder.emit(
                "participant.finished",
                status=status,
                error=error,
                usage=self.recorder.usage(),
            )
            if self.recorder.directory:
                snapshot = self.runtime.snapshot()
                save_json(
                    self.recorder.directory / "core-snapshot.json",
                    snapshot,
                )
                save_json(self.recorder.directory / "usage.json", self.recorder.usage())
        return RunResult(
            status, self.output.outputs, error, self.recorder.usage()["model_calls"]
        )
