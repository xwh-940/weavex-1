"""Deliver task inputs as Acts without constructing semantic representations."""

from weavex.communication import emit_act

from ..contracts import SessionStopped, UnsupportedInput
from ..reporting import dumps


class InputBridge:
    def __init__(self, runtime, scope, recorder):
        self.runtime, self.scope, self.recorder = runtime, scope, recorder
        self.roots = {}
        self.seen = set()
        self.clock = None

    def accept(self, event):
        if event.kind == "stop":
            raise SessionStopped(event.content)
        if event.attachments:
            raise UnsupportedInput(
                "Direct multimodal attachments require a compatible model profile"
            )
        if event.event_id in self.seen:
            return None
        root = self.roots.get(event.conversation)
        if event.kind in {"continuation", "notice"} and root is None:
            raise UnsupportedInput("Input has no explicit known conversation")
        if event.kind == "user":
            if root is not None:
                raise UnsupportedInput(
                    "A second root requires a new explicit conversation ID"
                )
            act = self.runtime.inject_human(event.content)
            self.roots[event.conversation] = act
        elif event.kind == "continuation":
            act = self.runtime.reply_human(
                thread_id=root.thread_id, reply_to=root.act_id, content=event.content
            )
        elif event.kind == "notice":
            # Raw string avoids core recursive filtering of business field names.
            act = emit_act(
                self.runtime,
                thread_id=root.thread_id,
                kind="environment_notice",
                sender=event.source,
                recipient=root.recipient,
                reply_to=root.act_id,
                payload={
                    "content": event.content,
                    "provenance": dumps(
                        {
                            "notification_emitted_at": event.timestamp,
                            "scope": self.scope,
                            "interface_delivery_id": event.event_id,
                        }
                    ),
                },
            )
        else:
            raise UnsupportedInput(f"Unsupported event kind: {event.kind}")
        self.seen.add(event.event_id)
        self.recorder.emit(
            "input.delivered",
            event=event,
            act_id=act.act_id,
            delivered_at=self.clock() if self.clock else None,
        )
        return act
