"""Benchmark-neutral contracts. Evaluation is deliberately outside Session."""

from dataclasses import dataclass, field
from typing import Any, Literal, Protocol


@dataclass(frozen=True)
class TaskToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]
    write: bool = False
    waits_for_input: bool = False


@dataclass(frozen=True)
class InputEnvelope:
    event_id: str
    kind: Literal["user", "continuation", "notice", "stop"]
    content: str
    source: str
    timestamp: float
    conversation: str = "default"
    attachments: tuple[Any, ...] = ()


@dataclass(frozen=True)
class ToolResult:
    status: Literal["ok", "error", "unknown"]
    value: Any = None
    error: str = ""


class Session(Protocol):
    scope: str
    instructions: str
    stopped: bool

    def tools(self) -> tuple[TaskToolSpec, ...]: ...
    async def call(self, name: str, arguments: dict[str, Any]) -> ToolResult: ...
    async def send(self, content: str, delivery_id: str) -> ToolResult: ...
    async def poll(self) -> list[InputEnvelope]: ...
    async def idle(self) -> None: ...
    def now(self) -> float: ...
    def before_model(self) -> None: ...
    def after_model(self, seconds: float) -> None: ...


class SessionStopped(RuntimeError):
    pass


class UnsupportedInput(RuntimeError):
    pass


@dataclass
class RunResult:
    status: str
    output: list[str] = field(default_factory=list)
    error: str = ""
    calls: int = 0
