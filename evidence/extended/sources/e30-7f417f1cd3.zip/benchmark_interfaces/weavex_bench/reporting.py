"""Append-only external telemetry, separate from model-visible data."""

import dataclasses
import enum
import json
from pathlib import Path
from threading import Lock
from typing import Any
from datetime import date, datetime, time


def json_value(value: Any) -> Any:
    if value is None or isinstance(value, (str, bool, int, float)):
        return value
    if isinstance(value, enum.Enum):
        return json_value(value.value)
    if isinstance(value, (datetime, date, time)):
        return value.isoformat()
    if dataclasses.is_dataclass(value):
        return json_value(dataclasses.asdict(value))
    if isinstance(value, dict):
        return {str(k): json_value(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [json_value(v) for v in value]
    if hasattr(value, "model_dump"):
        return json_value(value.model_dump(mode="json"))
    # Unknown external objects must have an explicitly supported representation.
    raise TypeError(f"Unsupported payload type: {type(value).__name__}")


def dumps(value: Any) -> str:
    return json.dumps(json_value(value), ensure_ascii=False, separators=(",", ":"))


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(json_value(value), ensure_ascii=False, indent=2), encoding="utf-8"
    )


class Recorder:
    def __init__(self, directory: Path | None = None):
        self.directory = directory
        self.events: list[dict] = []
        self.lock = Lock()
        if directory:
            directory.mkdir(parents=True, exist_ok=True)

    def emit(self, kind: str, **data) -> None:
        with self.lock:
            record = json_value(
                {"sequence": len(self.events) + 1, "kind": kind, **data}
            )
            self.events.append(record)
            if self.directory:
                with (self.directory / "interface.jsonl").open(
                    "a", encoding="utf-8"
                ) as stream:
                    stream.write(dumps(record) + "\n")

    def usage(self) -> dict:
        calls = [e for e in self.events if e["kind"] == "model.result"]
        return {
            "model_calls": len(calls),
            "wall_seconds": sum(e["seconds"] for e in calls),
            "prompt_tokens": sum(
                (e.get("usage") or {}).get("prompt_tokens", 0) for e in calls
            ),
            "completion_tokens": sum(
                (e.get("usage") or {}).get("completion_tokens", 0) for e in calls
            ),
            "usage_missing_calls": sum(not bool(e.get("usage")) for e in calls),
            "task_calls": sum(e["kind"] == "task.result" for e in self.events),
        }
