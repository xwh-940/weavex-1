"""Beiling industrial safety-review experiment environment.

The package owns one fictional case world, its hidden evaluation and the
benchmark Session that turns a facility restart request into a continuing
review responsibility.  It is an environment extension: the WeaveX core
Runtime, protocol and tool effects are not modified here.
"""

from .scenario import (
    CASE_TITLE,
    DOCUMENTS,
    INSTRUCTIONS,
    HIDDEN_TRUTH,
    build_world,
    classify_directive_fallback,
    facility_response,
    final_outcome,
    judge_user_prompt,
    select_branch,
)
from .session import SafetyReviewSession

__all__ = [
    "CASE_TITLE",
    "DOCUMENTS",
    "HIDDEN_TRUTH",
    "INSTRUCTIONS",
    "SafetyReviewSession",
    "build_world",
    "classify_directive_fallback",
    "facility_response",
    "final_outcome",
    "judge_user_prompt",
    "select_branch",
]
