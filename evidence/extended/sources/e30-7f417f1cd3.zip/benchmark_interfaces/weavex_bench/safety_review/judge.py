"""Independent model judge for the safety-review environment.

The judge sees the hidden truth and the office's directive, and returns only a
structured classification.  It is an evaluator: its output is logged outside
the Actors and never delivered to them.
"""

from __future__ import annotations

from typing import Any

from weavex.provider_usage import response_usage_data

from .scenario import (
    CASE_TWO_JUDGE_SYSTEM,
    COMPLIANCE_JUDGE_SYSTEM,
    REVISION_JUDGE_SYSTEM,
    NEW_POSITION_JUDGE_SYSTEM,
    PROCESS_JUDGE_SYSTEM,
    PROPAGATION_JUDGE_SYSTEM,
    REUSE_JUDGE_SYSTEM,
    JUDGE_SYSTEM,
    REVIEW_JUDGE_SYSTEM,
    judge_case_two_prompt,
    judge_compliance_prompt,
    judge_revision_prompt,
    judge_new_position_prompt,
    judge_process_prompt,
    judge_propagation_prompt,
    judge_reuse_prompt,
    judge_review_prompt,
    judge_user_prompt,
    parse_case_two_judgement,
    parse_compliance_judgement,
    parse_revision_judgement,
    parse_new_position_judgement,
    parse_process_judgement,
    parse_propagation_judgement,
    parse_reuse_judgement,
    parse_judgement,
    parse_review_judgement,
)


class LLMJudge:
    def __init__(self, client, model: str, *, max_tokens: int = 2048) -> None:
        self.client = client
        self.model = model
        self.max_tokens = max_tokens
        self.records: list[dict[str, Any]] = []

    async def __call__(
        self, directive: str, phase: str, *, variant: str | None = None
    ) -> dict[str, Any]:
        if phase == "review":
            system = REVIEW_JUDGE_SYSTEM
            prompt = judge_review_prompt(directive)
            parser = parse_review_judgement
        elif phase == "case_two":
            system = CASE_TWO_JUDGE_SYSTEM
            prompt = judge_case_two_prompt(directive)
            parser = parse_case_two_judgement
        elif phase == "compliance":
            system = COMPLIANCE_JUDGE_SYSTEM
            prompt = judge_compliance_prompt(directive)
            parser = parse_compliance_judgement
        elif phase == "revision":
            system = REVISION_JUDGE_SYSTEM
            prompt = judge_revision_prompt(directive)
            parser = parse_revision_judgement
        elif phase == "new_position":
            system = NEW_POSITION_JUDGE_SYSTEM
            prompt = judge_new_position_prompt(
                directive,
                office_record_present=variant != "record_absent",
                dynamic_record_present=variant == "record_present_dynamic",
            )
            parser = parse_new_position_judgement
        elif phase == "reuse_check":
            system = REUSE_JUDGE_SYSTEM
            prompt = judge_reuse_prompt(
                directive, criterion_reachable=variant == "criterion_reachable"
            )
            parser = parse_reuse_judgement
        elif phase == "process_check":
            system = PROCESS_JUDGE_SYSTEM
            prompt = judge_process_prompt(
                directive,
                record_present=variant != "record_absent",
                self_report=variant == "self_report",
            )
            parser = parse_process_judgement
        elif phase == "propagation_check":
            system = PROPAGATION_JUDGE_SYSTEM
            prompt = judge_propagation_prompt(
                directive, structure=variant or "identity"
            )
            parser = parse_propagation_judgement
        else:
            system = JUDGE_SYSTEM
            prompt = judge_user_prompt(directive, phase)
            parser = parse_judgement
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": prompt},
        ]
        last_error = ""
        for attempt in (1, 2):
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=self.max_tokens,
                stream=False,
            )
            raw = str(getattr(response.choices[0].message, "content", "") or "")
            try:
                value = parser(raw)
            except ValueError as exc:
                last_error = str(exc)
                self.records.append(
                    {
                        "phase": phase,
                        "attempt": attempt,
                        "directive": directive,
                        "raw_response": raw,
                        "parse_error": last_error,
                        "usage": response_usage_data(response),
                    }
                )
                messages = [
                    *messages,
                    {"role": "assistant", "content": raw},
                    {
                        "role": "user",
                        "content": (
                            "上一次回复不是合法 JSON。请只输出一个 JSON 对象，"
                            "不要解释、不要 Markdown 代码块。"
                        ),
                    },
                ]
                continue
            self.records.append(
                {
                    "phase": phase,
                    "attempt": attempt,
                    "directive": directive,
                    "raw_response": raw,
                    "judgement": value,
                    "usage": response_usage_data(response),
                }
            )
            return value
        raise ValueError(f"judge response was not valid JSON: {last_error}")

    def summary(self) -> dict[str, Any]:
        prompt = sum(
            (item["usage"] or {}).get("prompt_tokens", 0)
            for item in self.records
        )
        completion = sum(
            (item["usage"] or {}).get("completion_tokens", 0)
            for item in self.records
        )
        return {
            "calls": len(self.records),
            "prompt_tokens": prompt,
            "completion_tokens": completion,
        }


__all__ = ["LLMJudge"]
