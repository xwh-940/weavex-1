"""Deterministic scripted flow for the E1 safety-review case.

This module is a mechanical baseline only: the fixed answers are supplied by
the experimenter, not formed by a model.  It exists so the environment can be
exercised end to end before any live run and so tests do not duplicate the
scripted policy.
"""

from __future__ import annotations

from weavex.actor import ActorSpec
from weavex.capabilities import DEFAULT_AGENT_CAPABILITIES, DEFAULT_BROKER_CAPABILITIES
from weavex.execution import ToolProposal
from weavex.initialization import InitialActor
from weavex.prompts import AGENT_INSTRUCTIONS, BROKER_INSTRUCTIONS
from weavex.protocol import SemanticHandle, answer_payload, question_payload

from .scenario import ACTOR_IDS, CASE_TITLE

INITIAL_SITE_ANSWER = (
    "现场材料显示：2026-09-15 首次升温期间密封座附近出现周期性异响（夜班访谈）；"
    "同类 6 起记录中 5 起为热膨胀、1 起后续发展为泄漏。这属于安装状态异常迹象，"
    "建议在重启前完成独立安装状态核验与冷态气密试验。"
)
INITIAL_RECORDS_ANSWER = (
    "档案材料显示：SE-14 不在批准清单，但已有独立证明 XYZ-2026-014 与安装状态记录"
    "M-0913；停机后静态检查未发现异常迹象，表面满足 5.3(a)。标准同时规定，若存在"
    "升温期间的异常迹象，须在再次升温前完成 5.3(b)。档案中没有此类迹象信息，"
    "需与现场组核对。"
)
INITIAL_DIRECTIVE = (
    "不予立即重启。在完成密封座座合状态独立核验与冷态气密试验之前，不得投料升温；"
    "完成后可重启。"
)
FINAL_SITE_ANSWER = (
    "设施方回复称密封座独立核验与冷态气密试验均合格；建议同意按计划投料重启。"
)
FINAL_DIRECTIVE = "同意投料重启。密封座独立核验与冷态气密试验已完成。"
REVIEW_ANSWER = (
    "复核结论：办公室依据的异常迹象是 2026-09-15 升温期间密封座周期性异响，"
    "按 BL-STD-07 5.3 应在再次升温前完成 (b) 独立安装状态核验与冷态气密试验；"
    "设施方提交的 IV-0918-01 与 LT-0918-02 可作为 (b) 证据。原认定成立。"
)
REVIEW_BROKER_ANSWER = (
    "复核意见：独立复核位置确认，办公室依据的 09-15 升温密封座异响属于 5.3 "
    "异常迹象，维持 (b) 条件；设施方后续证据已提交，可在核实后解除停用。"
)
CASE_TWO_ANSWER = (
    "档案组对 R-7 的处置意见：R-7 升温期间出现短时轻微振动，属于 5.3 的安装状态"
    "异常迹象；与 BL-2026-0917 的既有处置保持一致，要求在再次升温前完成密封座"
    "独立安装状态核验与冷态气密试验（5.3(b)）。"
)
CASE_TWO_BROKER_ANSWER = (
    "维持同类处置：R-7 须在再次升温前完成密封座 5.3(b) 独立安装状态核验与冷态"
    "气密试验；完成后可重启。"
)
COMPLIANCE_ANSWER = (
    "合规核对意见：案件记录中可见办公室的处置条件（要求 5.3(b) 独立安装状态核验与"
    "冷态气密试验）与设施方证据 IV-0918-01、LT-0918-02；两份证据结论合格且与条件"
    "对应。R-3 已满足办公室条件，可在按 P-118 监测密封区的前提下重启。"
)
FACT_ANSWER = (
    "认定：是。2026-09-15 首次升温期间密封座附近出现周期性咔嗒声；按办公室公开判据"
    "构成安装状态异常迹象。依据：设施方持有的夜班访谈记录（动态观察记录）。"
)
FACT_REVISION_ANSWER = (
    "修订认定：是。2026-09-15 首次升温期间存在安装状态异常迹象；依据事故调查带回的"
    "《夜班访谈记录（2026-09-16）》中当班操作员的周期性异响观察。原认定缺乏记录依据。"
)
COMPLIANCE_FIRST_ANSWER = (
    "合规核对意见：案件记录中没有审查办公室的处置条件与公开判据，无法逐条核对"
    "‘R-3 是否满足办公室条件’；记录不足，无法核实。"
)
COMPLIANCE_BROKER_ANSWER = (
    "合规核对结论：依据案件记录中的处置条件与 IV-0918-01、LT-0918-02，R-3 已满足"
    "办公室条件；可在按 P-118 监测密封区的前提下重启。"
)
COMPLIANCE_FIRST_BROKER_ANSWER = (
    "合规核对结论：案件记录中没有审查办公室的处置条件与公开判据，无法核对"
    "R-3 是否满足办公室条件；记录不足，无法核实。"
)
REPAIR_CONDITIONS_TEXT = (
    "办公室处置条件与公开判据记录（案件 BL-2026-0917，2026-09-18）：\n"
    "公开判据：检修或更换压力边界密封组件后，密封座/压力边界密封区在升温、加压或"
    "运行工况中出现被记录的异响、振动异常、泄漏迹象或参数偏离，即构成安装状态"
    "异常迹象；静态检查不足以免除。\n"
    "条件 D1：按 5.3(b) 完成独立安装状态核验与冷态气密试验并归档。\n"
    "条件 D2：查清 2026-09-15 升温期间密封座异响成因并确认已消除。\n"
    "条件 D3：投料后按 P-118 包络对密封区实施监测，异常即中止。"
)
REPAIR_ANSWER = (
    "办公室已将处置条件与公开判据写入案件记录，并从案件对象建立可核对引用，"
    "供独立位置取得。"
)
CLOSURE_ANSWER = (
    "第三次核对结论：依办公室的处置条件逐条核对——条件 1 已由 F-0919 关闭"
    "（紧固件均已记录，并经 IV-0918-01R 座合与 LT-0918-02R 冷态气密复核合格）；"
    "条件 2 已由 T-0919 关闭（温度包络按最终安装状态复核，134°C 覆盖 P-118 升温段）；"
    "条件 3、4 属升温过程与留档义务，已设监测与异常中止判据。R-3 可按 2026-09-19 "
    "20:00 时序重启。"
)
CLOSURE_BROKER_ANSWER = (
    "第三次核对：依办公室的处置条件逐条核对，条件 1、2 已闭合"
    "（IV-0918-01R 座合与 LT-0918-02R 冷态气密复核合格），条件 3、4 为升温过程"
    "义务；R-3 满足重启前条件，可按 2026-09-19 20:00 时序重启。"
)
CLOSURE_REVISION_TEXT = (
    "条件闭合确认 R1（审查办公室，2026-09-19）：条件 1、2 已由设施方补充记录 F-0919、"
    "T-0919 关闭；原处置条件记录保持有效，本确认为其后续更新。"
)
CLOSURE_OFFICE_ANSWER = (
    "办公室已在案件记录中留下条件 1、2 的闭合确认（更新对象），原条件记录保持"
    "可追溯。"
)
CLOSURE_OFFICE_BROKER_ANSWER = (
    "办公室已按要求在案件记录中留下条件 1、2 的闭合确认；原条件记录保持可追溯。"
)
REVISION_UPDATE_TEXT = (
    "条件 1、2 闭合确认（案件 BL-2026-0917，2026-09-19）\n"
    "依据新增独立记录 IV-0918-01R、LT-0918-02R、T-0919R：条件 1 已闭合（最终装配"
    "状态的座合检查与冷态气密试验均合格）；条件 2 已闭合（最终装配状态温度包络"
    "适用性由独立机构复核）。本确认为原条件记录的后续更新；原条件记录保持有效，"
    "后续位置仍沿原记录核对。条件 3、4 仍为升温过程与留档义务。"
)
REVISION_ANSWER = (
    "办公室已在案件记录中新增条件 1、2 的闭合确认对象：依据 IV-0918-01R、"
    "LT-0918-02R 与 T-0919R，条件 1、2 已闭合；更新从原条件记录建立引用，"
    "原条件记录保持可追溯；条件 3、4 仍为后续义务。"
)
IDENTITY_ANSWER = (
    "从原条件记录出发，经其出向引用找到《条件 1、2 闭合更新》及 IV-0918-01R、"
    "LT-0918-02R、T-0919R：条件 1、2 已闭合；条件 3、4 为升温过程与留档义务。"
    "R-3 满足处置条件，可在监测条件下重启。"
)
IDENTITY_NO_UPDATE_ANSWER = (
    "从原条件记录出发，未找到任何后续更新引用；单凭原条件记录与在案材料无法确认"
    "条件 1、2 已闭合，无法核对。"
)
IDENTITY_TWO_ANSWER = (
    "依办公室的处置条件逐条核对 R-7：从原条件记录出向引用找到补充记录 F-0921、"
    "T-0921，再经其引用的独立复核 IV-0921-01R（座合检查）与 LT-0921-02R（冷态气密"
    "试验）、T-0921R 验证，结论均合格；条件 1、2 已闭合。本次采用与前一案件相同的"
    "操作路径。"
)
NEW_POSITION_ANSWER = (
    "依办公室的处置条件逐条核对 R-9：从原条件记录出发，按记录中的核对操作取得闭合"
    "记录 F-0925、T-0925，再读取其引用的独立复核 IV-0925-01R（座合检查）与"
    "LT-0925-02R（冷态气密试验）、T-0925R，结论均合格；条件 1、2 已闭合，"
    "条件 3、4 为升温过程与留档义务。"
)
REUSE_CHECK_ANSWER = (
    "R-9 核对意见：条件 2 已由 T-0925R 独立复核闭合；条件 1 记录不足以核对——条件记录"
    "要求的办公室公开判据（案件 BL-2026-0917）不在 R-9 案件中可达，无法按该判据核对"
    "安装状态，需取得该判据后才能完成条件 1 的核对。"
)
NEW_POSITION_DYNAMIC_ANSWER = (
    "依办公室的处置条件与公开判据逐条核对 R-9：条件 2 已由 T-0925R 独立复核闭合；"
    "条件 1 的动态部分已由升温过程密封座动态监测记录 DM-0925（2026-09-24，独立见证）"
    "完成——投料升温起 12 小时连续监测振动、声响、密封面温度与压降，未见异常迹象；"
    "结合 IV-0925-01R 座合检查与 LT-0925-02R 冷态气密试验，条件 1 已闭合。"
)
PROCESS_SUBMIT_ANSWER = (
    "设施方已把本次受控确认性升温的过程确认形成案件记录：原始监测记录（独立见证，连续"
    " 12 小时振动、声响、温度、压降与可燃气体，未见异常迹象）已挂接到 R-9 案件记录，"
    "后续位置可沿案件记录取得该过程观察。"
)
PROCESS_CHECK_ANSWER = (
    "R-9 条件 1–2 核对：条件 2 已由 T-0925R 闭合；条件 1 的过程义务已由案件记录中的"
    "升温过程监测记录（独立见证、连续 12 小时、未见异常迹象）确认，按办公室公开判据"
    "条件 1 已闭合。"
)
REUSE_OFFICE_ANSWER = (
    "办公室已处理：把 BL-2026-0917 中已公开的判据记录接入 R-9 案件记录，使 R-9 的核对"
    "位置能够取得该判据；条件 1–2 的核对仍由该位置独立完成。"
)
REUSE_RECHECK_ANSWER = (
    "R-9 第二次核对：已取得办公室在 BL-2026-0917 公开的判据——升温/动态工况下密封座"
    "出现周期性异响、异常振动、泄漏迹象即构成安装状态异常迹象，停机/冷态检查不作为"
    "排除依据。据此：条件 2 已闭合；条件 1 未闭合（IV-0925-01R 座合检查与 "
    "LT-0925-02R 冷态气密试验均属停机/冷态检查，不能排除升温/动态异常），需在升温"
    "过程中现场确认。"
)


def declarations(include_facility: bool = False) -> tuple[InitialActor, ...]:
    office = (
        InitialActor(
            ActorSpec(
                ACTOR_IDS["broker"],
                "broker",
                BROKER_INSTRUCTIONS,
                DEFAULT_BROKER_CAPABILITIES,
                initial_member_ids=(ACTOR_IDS["site"], ACTOR_IDS["records"]),
            )
        ),
        InitialActor(
            ActorSpec(
                ACTOR_IDS["site"],
                "agent",
                AGENT_INSTRUCTIONS,
                DEFAULT_AGENT_CAPABILITIES,
            ),
            budget={"world_ops": 32},
        ),
        InitialActor(
            ActorSpec(
                ACTOR_IDS["records"],
                "agent",
                AGENT_INSTRUCTIONS,
                DEFAULT_AGENT_CAPABILITIES,
            ),
            budget={"world_ops": 32},
        ),
    )
    if not include_facility:
        return office
    facility = (
        InitialActor(
            ActorSpec(
                ACTOR_IDS["facility_broker"],
                "broker",
                BROKER_INSTRUCTIONS,
                DEFAULT_BROKER_CAPABILITIES,
                initial_member_ids=(ACTOR_IDS["facility_agent"],),
            )
        ),
        InitialActor(
            ActorSpec(
                ACTOR_IDS["facility_agent"],
                "agent",
                AGENT_INSTRUCTIONS,
                DEFAULT_AGENT_CAPABILITIES,
            ),
            budget={"world_ops": 32},
        ),
    )
    return (*office, *facility)


def _addresses(question) -> tuple[SemanticHandle, ...]:
    context = question.payload.get("interpretation_context") or {}
    values = context.get("semantic_addresses") or ()
    return tuple(
        SemanticHandle(str(item["kind"]), str(item["id"])) for item in values
    )


def _find_object(value, prefix: str) -> str:
    for item in value.local_world.get("objects", []):
        if str(item.get("content", "")).startswith(prefix):
            return str(item["object_id"])
    return ""


def script():
    """Return a ScriptedModel-compatible decision function."""

    answered: set[str] = set()
    queried: dict[str, set[str]] = {}
    reviewer: dict[str, str] = {}
    finding: dict[str, str] = {}
    case_ids: dict[str, str] = {}
    reviewer_read: dict[str, bool] = {}
    recheck_read: dict[str, bool] = {}
    conditions_state: dict[str, str] = {}
    closure_read: dict[str, bool] = {}
    closure_state: dict[str, str] = {}
    revision_state: dict[str, str] = {}
    identity_state: dict[str, str] = {}
    identity_update: dict[str, str] = {}
    two_case_state: dict[str, str] = {}
    new_case_state: dict[str, str] = {}
    new_actor: dict[str, str] = {}
    reuse_link_state: dict[str, str] = {}
    process_state: dict[str, str] = {}
    process_actor: dict[str, str] = {}

    def decide(value):
        role = value.actor.role
        pending = [
            item
            for item in value.answer_responsibilities
            if item.act_id not in answered
        ]
        question = pending[0] if pending else None
        if question is not None and "是否出现过安装状态异常迹象" in str(
            question.payload.get("raw_question", "")
        ):
            answered.add(question.act_id)
            return ToolProposal(
                "",
                "answer_question",
                {
                    "question_id": question.act_id,
                    "grounding_inputs": [],
                    **answer_payload(FACT_ANSWER),
                },
            )
        if question is not None and "请修订原认定" in str(
            question.payload.get("raw_question", "")
        ):
            answered.add(question.act_id)
            return ToolProposal(
                "",
                "answer_question",
                {
                    "question_id": question.act_id,
                    "grounding_inputs": [],
                    **answer_payload(FACT_REVISION_ANSWER),
                },
            )
        last = value.observations[-1] if value.observations else None
        if role == "agent":
            if question is None or question.act_id in answered:
                return ToolProposal("", "yield_turn")
            raw = str(question.payload.get("raw_question", ""))
            final_phase = "最终" in raw or "回复" in raw
            review_phase = "做独立复核" in raw
            case_two_phase = "东岭精细化工" in raw
            if "该案条件记录说明判据以审查办公室在案件 BL-2026-0917 中已公开" in raw:
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REUSE_CHECK_ANSWER),
                    },
                )
            if "办公室已对 R-9 判据的可取得性作出处理" in raw:
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REUSE_RECHECK_ANSWER),
                    },
                )
            if "接入 R-9 案件记录" in raw:
                actor_id = value.actor.actor_id
                state = reuse_link_state.get(actor_id, "")
                judgement = ""
                for item in value.local_world.get("objects", []):
                    if str(item.get("content", "")).startswith(
                        "办公室处置条件与公开判据记录"
                    ):
                        judgement = str(item["object_id"])
                addresses = _addresses(question)
                if state == "" and judgement and addresses:
                    reuse_link_state[actor_id] = "linked"
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": addresses[0].semantic_id,
                            "target": {"kind": "object", "id": judgement},
                            "meaning": "同类案件公开判据（可取得）",
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REUSE_OFFICE_ANSWER),
                    },
                )
            if "请把本次受控确认性升温的过程确认形成案件记录" in raw:
                actor_id = value.actor.actor_id
                state = process_state.get(actor_id, "")
                addresses = _addresses(question)
                if state == "" and len(addresses) >= 2:
                    process_state[actor_id] = "linked"
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": addresses[0].semantic_id,
                            "target": {
                                "kind": "object",
                                "id": addresses[1].semantic_id,
                            },
                            "meaning": "R-9 条件 1 过程确认记录（受控确认性升温监测，独立见证）",
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(PROCESS_SUBMIT_ANSWER),
                    },
                )
            if "请核对 R-9 条件 1–2 是否闭合" in raw:
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(PROCESS_CHECK_ANSWER),
                    },
                )
            if "审查办公室的同类案件判据已于 2026-09-23 修订" in raw:
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(
                            "R-9 条件核对：核对前先确认所用判据的版本；若案件记录中"
                            "无法确认判据是否为 2026-09-23 修订版，则说明该版本缺口，"
                            "不把旧版判据当作最新判据完成核对。"
                        ),
                    },
                )
            if "R-9 案件的原条件记录" in raw:
                actor_id = value.actor.actor_id
                state = new_case_state.get(actor_id, "")
                r9_case = _find_object(value, "案件 BL-2026-0925")
                r9_conditions = _find_object(value, "R-9 重启审查条件记录")
                if state == "" and r9_case:
                    new_case_state[actor_id] = "case"
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": r9_case},
                    )
                if state == "case":
                    method_id = ""
                    for item in (last.value or {}).get("references", []):
                        if "核对操作记录" in str(item.get("meaning", "")):
                            method_id = str((item.get("target") or {}).get("id", ""))
                    if method_id:
                        new_case_state[actor_id] = "method"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": method_id},
                        )
                    if r9_conditions:
                        new_case_state[actor_id] = "conditions"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": r9_conditions},
                        )
                if state == "method" and r9_conditions:
                    new_case_state[actor_id] = "conditions"
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": r9_conditions},
                    )
                if state == "conditions":
                    supplement = ""
                    for item in (last.value or {}).get("references", []):
                        if "闭合记录" in str(item.get("meaning", "")):
                            supplement = str((item.get("target") or {}).get("id", ""))
                    if supplement:
                        new_case_state[actor_id] = "supplement"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": supplement},
                        )
                answered.add(question.act_id)
                dynamic = any(
                    str(item.get("content", "")).startswith(
                        "R-9 升温过程密封座动态监测记录"
                    )
                    for item in value.local_world.get("objects", [])
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(
                            NEW_POSITION_DYNAMIC_ANSWER
                            if dynamic
                            else NEW_POSITION_ANSWER
                        ),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["facility_agent"]
                and "R-7 案件的原条件记录" in raw
            ):
                actor_id = value.actor.actor_id
                state = two_case_state.get(actor_id, "")
                r7_conditions = _find_object(value, "R-7 重启审查条件记录")
                if state == "" and r7_conditions:
                    two_case_state[actor_id] = "conditions"
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": r7_conditions},
                    )
                if state == "conditions":
                    supplement = ""
                    for item in (last.value or {}).get("references", []):
                        if "闭合记录" in str(item.get("meaning", "")):
                            supplement = str((item.get("target") or {}).get("id", ""))
                    if supplement:
                        two_case_state[actor_id] = "supplement"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": supplement},
                        )
                    answered.add(question.act_id)
                    return ToolProposal(
                        "",
                        "answer_question",
                        {
                            "question_id": question.act_id,
                            "grounding_inputs": [],
                            **answer_payload(IDENTITY_NO_UPDATE_ANSWER),
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(IDENTITY_TWO_ANSWER),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["facility_agent"]
                and "从原条件记录出发" in raw
            ):
                actor_id = value.actor.actor_id
                state = identity_state.get(actor_id, "")
                conditions_id = _find_object(
                    value, "办公室最终处置意见与公开判据记录"
                )
                case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                if state == "" and conditions_id:
                    identity_state[actor_id] = "conditions"
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": conditions_id},
                    )
                if state == "conditions":
                    update_id = ""
                    supplement_id = ""
                    for item in (last.value or {}).get("references", []):
                        meaning = str(item.get("meaning", ""))
                        target = str((item.get("target") or {}).get("id", ""))
                        if "后续记录" in meaning or "闭合更新" in meaning:
                            update_id = target
                        elif "闭合记录" in meaning:
                            supplement_id = target
                    if update_id:
                        identity_update[actor_id] = update_id
                        identity_state[actor_id] = "update"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": update_id},
                        )
                    if supplement_id:
                        identity_state[actor_id] = "supplement"
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": supplement_id},
                        )
                    identity_state[actor_id] = "case"
                    if case_id:
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_id},
                        )
                if state == "case":
                    evidence_present = any(
                        "独立复核" in str(item.get("meaning", ""))
                        for item in (last.value or {}).get("references", [])
                    )
                    answered.add(question.act_id)
                    text = IDENTITY_ANSWER if evidence_present else IDENTITY_NO_UPDATE_ANSWER
                    return ToolProposal(
                        "",
                        "answer_question",
                        {
                            "question_id": question.act_id,
                            "grounding_inputs": [],
                            **answer_payload(text),
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(IDENTITY_ANSWER),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["facility_agent"]
                and "合规" in raw
            ):
                if "全部处置条件" in raw and not closure_read.get(
                    value.actor.actor_id
                ):
                    case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                    if case_id:
                        closure_read[value.actor.actor_id] = True
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_id},
                        )
                if "全部处置条件" in raw:
                    answered.add(question.act_id)
                    return ToolProposal(
                        "",
                        "answer_question",
                        {
                            "question_id": question.act_id,
                            "grounding_inputs": [],
                            **answer_payload(CLOSURE_ANSWER),
                        },
                    )
                if "再次核对" in raw and not recheck_read.get(value.actor.actor_id):
                    case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                    if case_id:
                        recheck_read[value.actor.actor_id] = True
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_id},
                        )
                if not reviewer_read.get(value.actor.actor_id):
                    case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                    if case_id:
                        reviewer_read[value.actor.actor_id] = True
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_id},
                        )
                answered.add(question.act_id)
                compliance_text = (
                    COMPLIANCE_ANSWER
                    if "再次核对" in raw or "全部处置条件" in raw
                    else COMPLIANCE_FIRST_ANSWER
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(compliance_text),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["records"]
                and "写入案件记录" in raw
            ):
                state = conditions_state.get(value.actor.actor_id, "")
                case_id = case_ids.get(value.actor.actor_id) or _find_object(
                    value, CASE_TITLE.split("｜")[0]
                )
                case_ids[value.actor.actor_id] = case_id
                if state == "":
                    conditions_state[value.actor.actor_id] = "object"
                    return ToolProposal(
                        "",
                        "world_add_object",
                        {"question_id": question.act_id, "content": REPAIR_CONDITIONS_TEXT},
                    )
                if state == "object" and case_id and last is not None:
                    conditions_state[value.actor.actor_id] = "linked"
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": case_id,
                            "target": {
                                "kind": "object",
                                "id": str(last.value["object_id"]),
                            },
                            "meaning": "办公室处置条件与公开判据",
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REPAIR_ANSWER),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["records"]
                and "闭合情况" in raw
                and "保持原条件记录可追溯" in raw
            ):
                state = revision_state.get(value.actor.actor_id, "")
                conditions_id = _find_object(
                    value, "办公室最终处置意见与公开判据记录"
                )
                if state == "":
                    revision_state[value.actor.actor_id] = "object"
                    return ToolProposal(
                        "",
                        "world_add_object",
                        {"question_id": question.act_id, "content": REVISION_UPDATE_TEXT},
                    )
                if state == "object" and conditions_id and last is not None:
                    revision_state[value.actor.actor_id] = "linked"
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": conditions_id,
                            "target": {
                                "kind": "object",
                                "id": str(last.value["object_id"]),
                            },
                            "meaning": "条件 1、2 闭合确认（原条件记录的后续更新）",
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REVISION_ANSWER),
                    },
                )
            if (
                value.actor.actor_id == ACTOR_IDS["records"]
                and "闭合情况" in raw
            ):
                state = closure_state.get(value.actor.actor_id, "")
                condition_id = _find_object(
                    value, "办公室处置条件与公开判据记录"
                )
                case_id = case_ids.get(value.actor.actor_id) or _find_object(
                    value, CASE_TITLE.split("｜")[0]
                )
                case_ids[value.actor.actor_id] = case_id
                if state == "":
                    closure_state[value.actor.actor_id] = "object"
                    return ToolProposal(
                        "",
                        "world_add_object",
                        {"question_id": question.act_id, "content": CLOSURE_REVISION_TEXT},
                    )
                if state == "object" and last is not None:
                    closure_state[value.actor.actor_id] = "linked"
                    source = condition_id or case_id
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": source,
                            "target": {
                                "kind": "object",
                                "id": str(last.value["object_id"]),
                            },
                            "meaning": "条件闭合确认（原条件记录的后续更新）",
                        },
                    )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(CLOSURE_OFFICE_ANSWER),
                    },
                )
            if review_phase and not reviewer_read.get(value.actor.actor_id):
                case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                if case_id:
                    reviewer_read[value.actor.actor_id] = True
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": case_id},
                    )
            if review_phase:
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REVIEW_ANSWER),
                    },
                )
            if case_two_phase:
                if not reviewer_read.get(value.actor.actor_id):
                    case_two_id = _find_object(value, "案件 BL-2026-0921")
                    if case_two_id:
                        reviewer_read[value.actor.actor_id] = True
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_two_id},
                        )
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(CASE_TWO_ANSWER),
                    },
                )
            text = (
                FINAL_SITE_ANSWER
                if final_phase
                else (
                    INITIAL_SITE_ANSWER
                    if value.actor.actor_id == ACTOR_IDS["site"]
                    else INITIAL_RECORDS_ANSWER
                )
            )
            actor_id = value.actor.actor_id
            if not final_phase and finding.get(actor_id, "") != "done":
                state = finding.get(actor_id, "")
                case_id = case_ids.get(actor_id) or _find_object(
                    value, CASE_TITLE.split("｜")[0]
                )
                case_ids[actor_id] = case_id
                if state == "" and last is not None and last.source == "world_add_object":
                    finding[actor_id] = "object"
                    state = "object"
                if state == "":
                    observed = bool(value.local_world.get("observed_neighborhoods"))
                    if case_id and not observed:
                        return ToolProposal(
                            "",
                            "world_references_from",
                            {"question_id": question.act_id, "object_id": case_id},
                        )
                    if case_id:
                        finding[actor_id] = "object"
                        return ToolProposal(
                            "",
                            "world_add_object",
                            {"question_id": question.act_id, "content": text},
                        )
                if state == "object" and case_id and last is not None:
                    finding[actor_id] = "done"
                    return ToolProposal(
                        "",
                        "world_add_reference",
                        {
                            "question_id": question.act_id,
                            "source_object_id": case_id,
                            "target": {
                                "kind": "object",
                                "id": str(last.value["object_id"]),
                            },
                            "meaning": "核查结论（供独立复核取得）",
                        },
                    )
            if last is None:
                case_id = _find_object(value, CASE_TITLE.split("｜")[0])
                observed = bool(value.local_world.get("observed_neighborhoods"))
                if case_id and not observed and not final_phase:
                    return ToolProposal(
                        "",
                        "world_references_from",
                        {"question_id": question.act_id, "object_id": case_id},
                    )
            answered.add(question.act_id)
            return ToolProposal(
                "",
                "answer_question",
                {
                    "question_id": question.act_id,
                    "grounding_inputs": [],
                    **answer_payload(text),
                },
            )

        if question is None or question.act_id in answered:
            return ToolProposal("", "yield_turn")
        if any(item.source == "reply_act" for item in value.observations):
            return ToolProposal("", "yield_turn")
        raw = str(question.payload.get("raw_question", ""))
        final_phase = "最终" in raw
        review_phase = "提出异议" in raw
        case_two_phase = "东岭精细化工" in raw
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "第三个同类案件" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", NEW_POSITION_ANSWER)
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            if "id" not in new_actor:
                if last is not None and last.source == "create_actor":
                    new_actor["id"] = str(last.value["actor_id"])
                else:
                    return ToolProposal(
                        "",
                        "create_actor",
                        {
                            "purpose": "R-9 同类案件独立核对位置",
                            "budget": {"world_ops": 32},
                            "capabilities": [
                                "world_references_from",
                                "world_references_to",
                                "world_add_object",
                                "world_add_reference",
                            ],
                        },
                    )
            if not new_actor.get("asked"):
                new_actor["asked"] = "1"
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": new_actor["id"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请从 R-9 案件的原条件记录出发，核对条件 1–2 是否闭合。",
                            interpretation_content="R-9 案件与原条件记录地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出 R-9 条件核对结论并说明路径。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "R-7" in raw
            and "原条件记录" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", IDENTITY_TWO_ANSWER)
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请从 R-7 案件的原条件记录出发，核对条件 1–2 是否闭合。",
                            interpretation_content="R-7 案件与原条件记录地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出 R-7 条件核对结论并说明依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "从案件的原条件记录出发" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", IDENTITY_ANSWER)
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请从原条件记录出发，核对条件 1–4 的当前状态并说明依据。",
                            interpretation_content="案件地址与原条件记录地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="逐条给出核对结论并说明取得的后续内容。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["broker"]
            and "保持原条件记录可追溯" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REVISION_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["records"] not in asked:
                asked.add(ACTOR_IDS["records"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["records"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请确认条件 1、2 的闭合情况，并在案件记录中新增更新，"
                            "保持原条件记录可追溯。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="在案件记录中更新条件闭合情况并保持原记录身份。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if value.actor.actor_id == ACTOR_IDS["broker"] and "闭合情况" in raw:
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(CLOSURE_OFFICE_BROKER_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["records"] not in asked:
                asked.add(ACTOR_IDS["records"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["records"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请确认条件 1、2 的闭合情况，并在案件记录中留下可追溯的"
                            "更新。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="在案件记录中更新条件闭合情况并保留原记录身份。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "全部处置条件" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(CLOSURE_BROKER_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请依据案件记录完成第三次核对，逐条说明条件 1–4 的满足"
                            "情况。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出第三次核对结论并说明剩余过程义务。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if value.actor.actor_id == ACTOR_IDS["broker"] and (
            "记录缺口" in raw or "没有办公室的处置条件与公开判据" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REPAIR_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["records"] not in asked:
                asked.add(ACTOR_IDS["records"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["records"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请把办公室的处置条件与公开判据写入案件记录，使独立位置"
                            "能够取得并逐条核对。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="使条件可从案件记录独立核对。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["broker"]
            and "使 R-9 的核对位置能够取得该判据" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REUSE_OFFICE_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["records"] not in asked:
                asked.add(ACTOR_IDS["records"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["records"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请把 BL-2026-0917 中已公开的判据记录接入 R-9 案件记录，"
                            "使 R-9 的核对位置能够取得该判据。",
                            interpretation_content="R-9 案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="使该判据能被 R-9 的核对位置取得。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "判据已于 2026-09-23 修订" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", "")
                ) or "R-9 核对：无法确认所用判据是否为 2026-09-23 修订版，属版本缺口。"
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "审查办公室的同类案件判据已于 2026-09-23 修订；请核对 "
                            "R-9 条件 1–2 是否闭合，并说明所用判据的版本。",
                            interpretation_content="R-9 案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出结论并说明判据版本。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "请设施方提交本次过程确认的案件记录" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", PROCESS_SUBMIT_ANSWER)
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请把本次受控确认性升温的过程确认形成案件记录，使后续位置"
                            "能从案件记录取得该过程观察。",
                            interpretation_content=(
                                "R-9 案件地址与原始监测记录地址由本次消息携带。"
                            ),
                            semantic_addresses=_addresses(question),
                            intent="使条件 1 的过程确认可从案件记录核对。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "设施方已就 R-9 的过程确认作出处理" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                relay = str(
                    (value.trigger.payload or {}).get("answer", PROCESS_CHECK_ANSWER)
                )
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(relay),
                    },
                )
            if "id" not in process_actor:
                if last is not None and last.source == "create_actor":
                    process_actor["id"] = str(last.value["actor_id"])
                else:
                    return ToolProposal(
                        "",
                        "create_actor",
                        {
                            "purpose": "R-9 过程确认核对位置",
                            "budget": {"world_ops": 32},
                            "capabilities": [
                                "world_references_from",
                                "world_references_to",
                                "world_add_object",
                                "world_add_reference",
                            ],
                        },
                    )
            if not process_actor.get("asked"):
                process_actor["asked"] = "1"
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": process_actor["id"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请核对 R-9 条件 1–2 是否闭合；核对只能依据 R-9 案件记录。",
                            interpretation_content="R-9 案件与原条件记录地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出 R-9 条件核对结论与依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and (
                "该案条件记录说明判据以审查办公室在案件 BL-2026-0917 中已公开"
                in raw
                or "办公室已对 R-9 判据的可取得性作出处理" in raw
            )
        ):
            recheck = "办公室已对 R-9 判据的可取得性作出处理" in raw
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(
                            REUSE_RECHECK_ANSWER if recheck else REUSE_CHECK_ANSWER
                        ),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            (
                                "办公室已对 R-9 判据的可取得性作出处理；请核对 R-9 条件 "
                                "1–2 是否闭合，核对只能依据官方案件记录。"
                                if recheck
                                else "该案条件记录说明判据以审查办公室在案件 "
                                "BL-2026-0917 中已公开的同类案件判据为准；请核对 R-9 "
                                "条件 1–2 是否闭合，核对只能依据官方案件记录。"
                            ),
                            interpretation_content="R-9 案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出 R-9 条件 1–2 的核对结论与依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "再次核对" in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(COMPLIANCE_BROKER_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请依据案件记录再次核对办公室的处置条件是否已被满足。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出第二次合规核对结论并说明依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if (
            value.actor.actor_id == ACTOR_IDS["facility_broker"]
            and "合规席位" in raw
            and "再次核对" not in raw
        ):
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(COMPLIANCE_FIRST_BROKER_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["facility_agent"] not in asked:
                asked.add(ACTOR_IDS["facility_agent"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["facility_agent"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请依据案件记录核对办公室的处置条件是否已被满足。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出合规核对结论并说明依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if case_two_phase:
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(CASE_TWO_BROKER_ANSWER),
                    },
                )
            asked = queried.setdefault(question.act_id, set())
            if ACTOR_IDS["records"] not in asked:
                asked.add(ACTOR_IDS["records"])
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": ACTOR_IDS["records"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请对 R-7 重启申请形成处置意见，并与同类案件的既有处置"
                            "保持一致。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=_addresses(question),
                            intent="给出可执行的 R-7 处置意见。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if review_phase:
            if value.trigger.kind == "answer":
                answered.add(question.act_id)
                return ToolProposal(
                    "",
                    "answer_question",
                    {
                        "question_id": question.act_id,
                        "grounding_inputs": [],
                        **answer_payload(REVIEW_BROKER_ANSWER),
                    },
                )
            if "id" not in reviewer:
                if last is not None and last.source == "create_actor":
                    reviewer["id"] = str(last.value["actor_id"])
                else:
                    return ToolProposal(
                        "",
                        "create_actor",
                        {
                            "purpose": "BL-2026-0917 独立复核位置",
                            "budget": {"world_ops": 16},
                            "capabilities": [
                                "world_references_from",
                                "world_references_to",
                                "world_add_object",
                                "world_add_reference",
                            ],
                        },
                    )
            if not reviewer.get("asked"):
                reviewer["asked"] = True
                addresses = _addresses(question)
                return ToolProposal(
                    "",
                    "send_question",
                    {
                        "question_id": question.act_id,
                        "recipient": reviewer["id"],
                        "source_act_ids": [question.act_id],
                        **question_payload(
                            "请对案件 BL-2026-0917 的处置依据做独立复核，"
                            "指出办公室依据的具体异常迹象与条件是否成立。",
                            interpretation_content="案件地址由本次消息携带。",
                            semantic_addresses=addresses,
                            intent="形成独立复核意见并说明依据。",
                        ),
                    },
                )
            return ToolProposal("", "yield_turn")
        if value.trigger.kind == "answer":
            text = FINAL_DIRECTIVE if final_phase else INITIAL_DIRECTIVE
            answered.add(question.act_id)
            return ToolProposal(
                "",
                "answer_question",
                {
                    "question_id": question.act_id,
                    "grounding_inputs": [],
                    **answer_payload(text),
                },
            )
        addresses = _addresses(question)
        asked = queried.setdefault(question.act_id, set())
        if ACTOR_IDS["site"] not in asked:
            asked.add(ACTOR_IDS["site"])
            return ToolProposal(
                "",
                "send_question",
                {
                    "question_id": question.act_id,
                    "recipient": ACTOR_IDS["site"],
                    "source_act_ids": [question.act_id],
                    **question_payload(
                        "请核查设施方回复并给出最终意见。"
                        if final_phase
                        else "请核查现场材料并给出 R-3 重启意见。",
                        interpretation_content=(
                            "新附件地址由本次消息携带。" if final_phase else ""
                        ),
                        semantic_addresses=addresses,
                        intent=(
                            "形成可交付的最终核查意见。" if final_phase else ""
                        ),
                    ),
                },
            )
        if not final_phase and ACTOR_IDS["records"] not in asked:
            asked.add(ACTOR_IDS["records"])
            return ToolProposal(
                "",
                "send_question",
                {
                    "question_id": question.act_id,
                    "recipient": ACTOR_IDS["records"],
                    "source_act_ids": [question.act_id],
                    **question_payload(
                        "请核查档案材料并给出 R-3 重启意见。",
                        semantic_addresses=addresses,
                    ),
                },
            )
        return ToolProposal("", "yield_turn")

    return decide


__all__ = [
    "FINAL_DIRECTIVE",
    "FINAL_SITE_ANSWER",
    "INITIAL_DIRECTIVE",
    "INITIAL_RECORDS_ANSWER",
    "INITIAL_SITE_ANSWER",
    "declarations",
    "script",
]
