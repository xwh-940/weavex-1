"""E0/E1 runner for the Beiling safety-review experiment.

Modes:
  calibrate  no model calls; checks that the decisive distinction spans the two
             Agent positions and that the response policy separates outcomes.
  smoke      deterministic scripted participant; mechanical end-to-end baseline.
  live       real model run with an independent model judge.

All artifacts are written under this directory's ``runs/<name>/``.
"""
# ruff: noqa: E402

from __future__ import annotations

import argparse
import asyncio
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time
from typing import Mapping

if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [
    str(ROOT / "src"),
    str(ROOT / "benchmark_interfaces"),
]

from openai import AsyncOpenAI

from weavex.provider import ScriptedModel
from weavex_bench.reporting import Recorder, save_json
from weavex_bench.safety_review import (
    CASE_TITLE,
    DOCUMENTS,
    SafetyReviewSession,
    classify_directive_fallback,
    facility_response,
    final_outcome,
    select_branch,
)
from weavex_bench.safety_review.judge import LLMJudge
from weavex_bench.safety_review.scenario import (
    ACTOR_IDS,
    CROSS_ORG_FACILITY_KEYS,
    RECORDS_KEYS,
    SITE_KEYS,
)
from weavex_bench.safety_review.smoke import declarations, script
from weavex_bench.weavex.participant import Participant

ANOMALY_TERMS = ("咔嗒",)
COMPLIANCE_TERMS = ("XYZ-2026-014", "M-0913", "5.3(a)")


def freeze_sources(directory: Path) -> dict[str, str]:
    paths = list((ROOT / "src" / "weavex").rglob("*.py"))
    paths += list((ROOT / "src" / "weavex" / "prompts").glob("*.md"))
    paths += list((ROOT / "benchmark_interfaces" / "weavex_bench").rglob("*.py"))
    paths += [HERE / "run.py"]
    hashes: dict[str, str] = {}
    for path in paths:
        target = directory / "source" / path.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)
        hashes[path.relative_to(ROOT).as_posix()] = hashlib.sha256(
            path.read_bytes()
        ).hexdigest()
    save_json(directory / "source-hashes.json", hashes)
    return hashes


def _contains(text: str, terms: tuple[str, ...]) -> bool:
    return any(term in text for term in terms)


def calibration_report() -> dict:
    site_text = "\n".join(DOCUMENTS[key] for key in SITE_KEYS if key in DOCUMENTS)
    records_text = "\n".join(
        DOCUMENTS[key] for key in RECORDS_KEYS if key in DOCUMENTS
    )
    shared_keys = tuple(sorted(set(SITE_KEYS) & set(RECORDS_KEYS)))
    shared_text = "\n".join(DOCUMENTS[key] for key in shared_keys)
    matrix = []
    for directive in (
        "允许重启，运行期间加强监测。",
        "暂停运行，待办公室进一步评估。",
        "在完成密封座座合状态独立核验与冷态气密试验之前不得投料升温。",
    ):
        judgement = classify_directive_fallback(directive)
        branch = select_branch(judgement, phase="initial")
        if branch == "hold_letter":
            weak = classify_directive_fallback(
                "同意投料重启，XYZ-2026-014 与安装状态记录符合 5.3(a)。"
            )
            strong = classify_directive_fallback(
                "同意投料重启；密封座独立核验与冷态试验已完成。"
            )
            outcomes = {
                "release": final_outcome(branch, judgement, weak)["outcome"],
                "control": final_outcome(branch, judgement, strong)["outcome"],
                "retain": final_outcome(
                    branch,
                    judgement,
                    classify_directive_fallback("维持停用，待进一步评估。"),
                )["outcome"],
            }
        elif branch == "unsafe_restart":
            outcomes = {
                "release": final_outcome(branch, judgement, judgement)["outcome"]
            }
        else:
            outcomes = {
                "release": final_outcome(
                    branch,
                    judgement,
                    classify_directive_fallback("同意投料重启，核验已完成。"),
                )["outcome"]
            }
        matrix.append(
            {
                "directive": directive,
                "judgement": judgement,
                "branch": branch,
                "outcomes": outcomes,
            }
        )
    checks = {
        "anomaly_only_in_site_bucket": _contains(site_text, ANOMALY_TERMS)
        and not _contains(records_text, ANOMALY_TERMS),
        "compliance_reading_only_in_records_bucket": _contains(
            records_text, COMPLIANCE_TERMS
        )
        and not _contains(site_text, COMPLIANCE_TERMS),
        "shared_bucket_does_not_bridge_them": not (
            _contains(shared_text, ANOMALY_TERMS)
            and _contains(shared_text, COMPLIANCE_TERMS)
        ),
        "shared_incident_has_no_anomaly_term": not _contains(
            shared_text, ANOMALY_TERMS
        ),
        "no_single_bucket_contains_both_decisive_facts": not (
            _contains(site_text, COMPLIANCE_TERMS)
            or _contains(records_text, ANOMALY_TERMS)
        ),
        "records_bucket_plausibly_looks_compliant": _contains(
            records_text, COMPLIANCE_TERMS
        )
        and "未发现异常声响" in records_text,
        "response_not_in_initial_materials": all(
            facility_response(branch) not in "\n".join(DOCUMENTS.values())
            for branch in ("unsafe_restart", "hold_letter", "compliant_controlled")
        ),
        "allow_and_blanket_hold_are_not_ideal": (
            matrix[0]["outcomes"]["release"] == "unsafe_event"
            and matrix[1]["outcomes"]["retain"] == "safe_over_hold"
        ),
        "seal_specific_control_reaches_safe_controlled": (
            matrix[2]["outcomes"]["release"] == "safe_controlled"
        ),
    }
    return {
        "purpose": (
            "E0 cheap-path calibration: the decisive combination must span the two "
            "private material buckets, and only a seal-specific independent control "
            "reaches safe_controlled."
        ),
        "not_model_evidence": True,
        "checks": checks,
        "matrix": matrix,
        "site_documents": list(SITE_KEYS),
        "records_documents": list(RECORDS_KEYS),
        "shared_documents": list(shared_keys),
    }


def mechanism_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    runtime = participant.runtime
    acts = [act for values in runtime.threads.values() for act in values]
    world = runtime.local_worlds.world
    environment_objects = set(session.objects.values()) | {
        item["object_id"] for item in session.responses
    }
    for item in session.responses:
        environment_objects.update(
            evidence["object_id"] for evidence in item.get("evidence", [])
        )
    actor_objects = [
        value.object_id
        for value in world.snapshot().objects.values()
        if value.object_id not in environment_objects
    ]
    delta_created = [
        trace
        for trace in runtime.traces
        if trace.kind == "local_world_delta.created"
    ]
    response_deltas = [
        trace
        for trace in delta_created
        if session.responses
        and session.responses[0]["reference_id"]
        in json.dumps(trace.payload, ensure_ascii=False)
    ]
    return {
        "actors": sorted(runtime.actors),
        "act_count": len(acts),
        "acts_by_sender_kind": {
            f"{act.sender}:{act.kind}": sum(
                1
                for item in acts
                if item.sender == act.sender and item.kind == act.kind
            )
            for act in acts
        },
        "broker_question_recipients": sorted(
            {
                act.recipient
                for act in acts
                if act.sender.startswith("broker") and act.kind == "question"
            }
        ),
        "agent_answer_senders": sorted(
            {act.sender for act in acts if act.kind == "answer"}
        ),
        "world_objects_total": len(world.snapshot().objects),
        "world_references_total": len(world.snapshot().references),
        "actor_created_objects": len(actor_objects),
        "environment_objects": len(environment_objects),
        "observed_neighborhoods": {
            actor_id: len(
                runtime.local_worlds.view_for(actor_id).get(
                    "observed_neighborhoods", []
                )
            )
            for actor_id in runtime.actors
            if runtime.actors[actor_id].spec.role == "agent"
        },
        "local_world_delta_created": len(delta_created),
        "response_reference_deltas": len(response_deltas),
        "judge_errors": list(session.judge_errors),
        **review_metrics(participant, session),
        **case_two_metrics(participant, session),
        **compliance_metrics(participant, session),
        **closure_metrics(participant, session),
        **revision_metrics(participant, session),
        **identity_metrics(participant, session),
        **two_case_metrics(participant, session),
        **new_position_metrics(participant, session),
        **cross_org_metrics(participant, session),
    }


def cross_org_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    """E35: did the office open a new coordination context and reach the facility?"""

    runtime = participant.runtime
    acts = [act for values in runtime.threads.values() for act in values]
    initial_brokers = {ACTOR_IDS["broker"], ACTOR_IDS["facility_broker"]}
    actor_roles = {
        actor_id: state.spec.role for actor_id, state in runtime.actors.items()
    }
    created_brokers = [
        trace.actor_id
        for trace in runtime.traces
        if trace.kind == "actor.created"
        and (trace.payload or {}).get("role") == "broker"
    ]
    external_questions = [
        {
            "act_id": act.act_id,
            "sender": act.sender,
            "recipient": act.recipient,
            "raw_question": str((act.payload or {}).get("raw_question", ""))[:160],
        }
        for act in acts
        if act.kind == "question"
        and actor_roles.get(act.sender) == "agent"
        and actor_roles.get(act.recipient) == "broker"
        and act.recipient not in initial_brokers
    ]
    facility_questions = [
        {"act_id": act.act_id, "sender": act.sender}
        for act in acts
        if act.kind == "question" and act.recipient == ACTOR_IDS["facility_agent"]
    ]
    facility_answers = [
        {"act_id": act.act_id, "recipient": act.recipient}
        for act in acts
        if act.kind == "answer" and act.sender == ACTOR_IDS["facility_agent"]
    ]
    facility_material_objects = {
        session.objects[key]
        for key in CROSS_ORG_FACILITY_KEYS
        if key in session.objects
    }
    material_deliveries = []
    for act in acts:
        addresses = (act.payload or {}).get("semantic_addresses") or ()
        delivered = {
            str(item.get("id"))
            for item in addresses
            if isinstance(item, Mapping) and item.get("kind") == "object"
        }
        if delivered & facility_material_objects:
            material_deliveries.append(
                {
                    "act_id": act.act_id,
                    "kind": act.kind,
                    "sender": act.sender,
                    "recipient": act.recipient,
                }
            )
    return {
        "cross_org_enabled": (
            session.enable_cross_org_probe or session.enable_fact_probe
        ),
        "cross_org_complete": (
            session.enable_cross_org_complete or session.enable_fact_probe
        ),
        "fact_probe": session.enable_fact_probe,
        "e39_provenance": session.enable_e39_provenance,
        "e41_anchor_link": session.enable_e41_anchor_link,
        "created_brokers": created_brokers,
        "external_questions": external_questions,
        "facility_questions": facility_questions,
        "facility_answers": facility_answers,
        "facility_material_deliveries": material_deliveries,
    }


def review_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    runtime = participant.runtime
    review_question = next(
        (item for item in session.human_questions if item["stage"] == "review"), None
    )
    result: dict = {
        "review_sender": "",
        "review_sender_created_by": "",
        "created_actors": [],
        "review_agent_answers": 0,
        "review_agent_reads": 0,
    }
    created = {
        actor_id: actor.spec.created_by
        for actor_id, actor in runtime.actors.items()
        if actor.spec.created_by and actor.spec.created_by != "initialization"
    }
    result["created_actors"] = sorted(created)
    acts = [act for values in runtime.threads.values() for act in values]
    result["review_agent_answers"] = sum(
        act.kind == "answer" and act.sender in created for act in acts
    )
    result["review_agent_reads"] = sum(
        event.get("kind") == "core.tool_end"
        and event.get("actor_id") in created
        and event.get("tool") == "world_references_from"
        and event.get("ok")
        for event in participant.recorder.events
    )
    if review_question is None:
        return result
    answer = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to == review_question["act_id"]
        ),
        None,
    )
    if answer is not None:
        result["review_sender"] = answer.sender
        if answer.sender in runtime.actors:
            result["review_sender_created_by"] = (
                runtime.actors[answer.sender].spec.created_by
            )
    snapshot = runtime.local_worlds.world.snapshot()
    environment_objects = set(session.objects.values()) | {
        item["object_id"] for item in session.responses
    }
    for item in session.responses:
        environment_objects.update(
            evidence["object_id"] for evidence in item.get("evidence", [])
        )
    actor_objects = {
        object_id
        for object_id in snapshot.objects
        if object_id not in environment_objects
    }
    reached: set[str] = set()
    frontier = {session.objects["case"]}
    for _ in range(3):
        following = set()
        for reference in snapshot.references.values():
            if reference.source_object_id not in frontier:
                continue
            target = reference.target_address
            object_id = getattr(target, "object_id", "")
            if object_id:
                following.add(object_id)
        reached |= following
        frontier = following
    result["determination_reachable_from_case"] = sorted(reached & actor_objects)
    return result


def case_two_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    runtime = participant.runtime
    question = next(
        (item for item in session.human_questions if item["stage"] == "case_two"),
        None,
    )
    result: dict = {
        "case_two_sender": "",
        "case_two_sender_created_by": "",
        "case_two_handler": "",
        "case_two_handler_created_by": "",
        "case_two_reads_case_one": 0,
    }
    if question is None:
        return result
    acts = [act for values in runtime.threads.values() for act in values]
    answer = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to == question["act_id"]
        ),
        None,
    )
    if answer is None:
        return result
    result["case_two_sender"] = answer.sender
    if answer.sender in runtime.actors:
        result["case_two_sender_created_by"] = (
            runtime.actors[answer.sender].spec.created_by
        )
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    handler_id = handler.sender if handler is not None else answer.sender
    result["case_two_handler"] = handler_id
    if handler_id in runtime.actors:
        result["case_two_handler_created_by"] = (
            runtime.actors[handler_id].spec.created_by
        )
    case_one_ids = {
        session.objects["case"],
        session.objects["site_dossier"],
        session.objects["records_dossier"],
    }
    result["case_two_reads_case_one"] = sum(
        event.get("kind") == "core.tool_end"
        and event.get("actor_id") == handler_id
        and event.get("tool") == "world_references_from"
        and event.get("ok")
        and any(
            object_id in json.dumps(event.get("value") or {}, ensure_ascii=False)
            for object_id in case_one_ids
        )
        for event in participant.recorder.events
    )
    return result


def compliance_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    runtime = participant.runtime
    question = next(
        (item for item in session.human_questions if item["stage"] == "compliance"),
        None,
    )
    result: dict = {
        "compliance_handler": "",
        "compliance_handler_created_by": "",
        "compliance_reads_case": 0,
        "compliance_verdict": "",
        "conditions_reachable_from_case": [],
        "recheck_verdict": "",
    }
    if question is None:
        return result
    acts = [act for values in runtime.threads.values() for act in values]
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    if handler is not None:
        result["compliance_handler"] = handler.sender
        if handler.sender in runtime.actors:
            result["compliance_handler_created_by"] = (
                runtime.actors[handler.sender].spec.created_by
            )
    handler_id = result["compliance_handler"]
    case_one_ids = {
        session.objects["case"],
        session.objects["records_dossier"],
    }
    result["compliance_reads_case"] = sum(
        event.get("kind") == "core.tool_end"
        and event.get("actor_id") == handler_id
        and event.get("tool") == "world_references_from"
        and event.get("ok")
        and any(
            object_id in json.dumps(event.get("value") or {}, ensure_ascii=False)
            for object_id in case_one_ids
        )
        for event in participant.recorder.events
    )
    if session.compliance is not None:
        result["compliance_verdict"] = (
            session.compliance.get("judgement", {}).get("verdict", "")
        )
    if session.recheck is not None:
        result["recheck_verdict"] = (
            session.recheck.get("judgement", {}).get("verdict", "")
        )
    snapshot = runtime.local_worlds.world.snapshot()
    environment_objects = set(session.objects.values()) | {
        item["object_id"] for item in session.responses
    }
    for item in session.responses:
        environment_objects.update(
            evidence["object_id"] for evidence in item.get("evidence", [])
        )
    actor_objects = {
        object_id
        for object_id in snapshot.objects
        if object_id not in environment_objects
    }
    reached: set[str] = set()
    frontier = {session.objects["case"]}
    for _ in range(3):
        following = set()
        for reference in snapshot.references.values():
            if reference.source_object_id not in frontier:
                continue
            target = reference.target_address
            object_id = getattr(target, "object_id", "")
            if object_id:
                following.add(object_id)
        reached |= following
        frontier = following
    result["conditions_reachable_from_case"] = sorted(reached & actor_objects)
    return result


def closure_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    runtime = participant.runtime
    question = next(
        (item for item in session.human_questions if item["stage"] == "closure"),
        None,
    )
    result: dict = {
        "closure_handler": "",
        "closure_reads_case": 0,
        "closure_verdict": "",
        "records_linked_to_conditions": [],
        "closure_office_reply": "",
    }
    if session.closure is not None:
        result["closure_verdict"] = (
            session.closure.get("judgement", {}).get("verdict", "")
        )
    if session.closure_office is not None:
        result["closure_office_reply"] = session.closure_office.get("content", "")[:400]
    snapshot = runtime.local_worlds.world.snapshot()
    environment_objects = set(session.objects.values()) | {
        item["object_id"] for item in session.responses
    }
    for item in session.responses:
        environment_objects.update(
            evidence["object_id"] for evidence in item.get("evidence", [])
        )
    actor_objects = {
        object_id
        for object_id in snapshot.objects
        if object_id not in environment_objects
    }
    condition_records = [
        object_id
        for object_id in actor_objects
        if "条件" in snapshot.objects[object_id].content
        or "判据" in snapshot.objects[object_id].content
    ]
    linked: set[str] = set()
    for reference in snapshot.references.values():
        source = reference.source_object_id
        target = getattr(reference.target_address, "object_id", "")
        if source in condition_records and target in actor_objects:
            linked.add(target)
        if target in condition_records and source in actor_objects:
            linked.add(source)
    result["records_linked_to_conditions"] = sorted(linked - set(condition_records))
    if question is None:
        return result
    acts = [act for values in runtime.threads.values() for act in values]
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    if handler is not None:
        result["closure_handler"] = handler.sender
        case_ids = {session.objects["case"]} | set(condition_records)
        result["closure_reads_case"] = sum(
            event.get("kind") == "core.tool_end"
            and event.get("actor_id") == handler.sender
            and event.get("tool") == "world_references_from"
            and event.get("ok")
            and any(
                object_id in json.dumps(event.get("value") or {}, ensure_ascii=False)
                for object_id in case_ids
            )
            for event in participant.recorder.events
        )
    return result


def revision_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    result: dict = {
        "revision_verdict": "",
        "revision_object_created": False,
        "identity_preserved": False,
        "original_record_unchanged": False,
        "revision_objects": [],
    }
    if session.revision is not None:
        judgement = session.revision.get("judgement", {})
        result["revision_verdict"] = (
            "revision_grounded" if judgement.get("revision_grounded") else "unclear"
        )
    if not session.revision_prestate:
        return result
    conditions_id = session.revision_prestate.get("conditions", "")
    snapshot = participant.runtime.local_worlds.world.snapshot()
    if conditions_id in snapshot.objects:
        result["original_record_unchanged"] = (
            snapshot.objects[conditions_id].content
            == session.revision_prestate.get("conditions_content", "")
        )
    prestate_objects = {
        value
        for key, value in session.revision_prestate.items()
        if key != "conditions_content"
    }
    environment_objects = (
        set(session.objects.values()) | prestate_objects
    )
    revision_objects = [
        object_id
        for object_id in snapshot.objects
        if object_id not in environment_objects
    ]
    result["revision_objects"] = revision_objects
    result["revision_object_created"] = bool(revision_objects)
    for reference in snapshot.references.values():
        source = reference.source_object_id
        target = getattr(reference.target_address, "object_id", "")
        if source == conditions_id and target in revision_objects:
            result["identity_preserved"] = True
        if target == conditions_id and source in revision_objects:
            result["identity_preserved"] = True
    return result


def identity_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    result: dict = {
        "identity_with_revision": session.identity_with_revision,
        "identity_handler": "",
        "identity_reads": 0,
        "reached_update": False,
        "used_evidence": False,
        "identity_verdict": "",
        "structure": session.identity_structure,
        "path_reads": [],
    }
    if session.identity_check is not None:
        result["identity_verdict"] = (
            session.identity_check.get("judgement", {}).get("verdict", "")
        )
    if not session.identity_prestate:
        return result
    update_id = session.identity_prestate.get("update", "")
    evidence_ids = {
        session.identity_prestate.get(key, "")
        for key in ("evidence_iv", "evidence_lt", "evidence_t")
    } - {""}
    question = next(
        (
            item
            for item in session.human_questions
            if item["stage"] == "identity_check"
        ),
        None,
    )
    if question is None:
        return result
    acts = [
        act
        for values in participant.runtime.threads.values()
        for act in values
    ]
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    handler_id = handler.sender if handler is not None else ""
    result["identity_handler"] = handler_id
    cutoff = next(
        (
            event["sequence"]
            for event in participant.recorder.events
            if event.get("kind") == "safety.human_question"
            and event.get("stage") == "identity_check_two"
        ),
        10**9,
    )
    for event in participant.recorder.events:
        if (
            event.get("kind") != "core.tool_end"
            or event.get("sequence", 0) > cutoff
            or event.get("actor_id") != handler_id
            or event.get("tool") != "world_references_from"
            or not event.get("ok")
        ):
            continue
        result["identity_reads"] += 1
        text = json.dumps(event.get("value") or {}, ensure_ascii=False)
        if update_id and update_id in text:
            result["reached_update"] = True
        if any(object_id in text for object_id in evidence_ids):
            result["used_evidence"] = True
    prestate_ids = {
        key: value
        for key, value in session.identity_prestate.items()
        if key != "conditions_content" and value
    }
    path_reads = set()
    for event in participant.recorder.events:
        if (
            event.get("kind") != "core.tool_end"
            or event.get("actor_id") != handler_id
            or event.get("tool") != "world_references_from"
            or not event.get("ok")
        ):
            continue
        text = json.dumps(event.get("value") or {}, ensure_ascii=False)
        for key, object_id in prestate_ids.items():
            if object_id in text:
                path_reads.add(key)
    result["path_reads"] = sorted(path_reads)
    return result


def two_case_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    result: dict = {
        "case_two_handler": "",
        "case_two_reads": 0,
        "case_two_path_reads": [],
        "case_two_verdict": "",
    }
    if session.identity_two is not None:
        result["case_two_verdict"] = (
            session.identity_two.get("judgement", {}).get("verdict", "")
        )
    if not session.two_case_prestate:
        return result
    question = next(
        (
            item
            for item in session.human_questions
            if item["stage"] == "identity_check_two"
        ),
        None,
    )
    if question is None:
        return result
    cutoff = next(
        (
            event["sequence"]
            for event in participant.recorder.events
            if event.get("kind") == "safety.human_question"
            and event.get("stage") == "identity_check_two"
        ),
        0,
    )
    acts = [
        act
        for values in participant.runtime.threads.values()
        for act in values
    ]
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    handler_id = handler.sender if handler is not None else ""
    result["case_two_handler"] = handler_id
    prestate_ids = {
        key: value
        for key, value in session.two_case_prestate.items()
        if value
    }
    paths: set[str] = set()
    for event in participant.recorder.events:
        if (
            event.get("sequence", 0) <= cutoff
            or event.get("kind") != "core.tool_end"
            or event.get("actor_id") != handler_id
            or event.get("tool") != "world_references_from"
            or not event.get("ok")
        ):
            continue
        result["case_two_reads"] += 1
        text = json.dumps(event.get("value") or {}, ensure_ascii=False)
        for key, object_id in prestate_ids.items():
            if object_id in text:
                paths.add(key)
    result["case_two_path_reads"] = sorted(paths)
    return result


def new_position_metrics(participant: Participant, session: SafetyReviewSession) -> dict:
    result: dict = {
        "new_position_handler": "",
        "new_position_created": False,
        "method_found": False,
        "new_position_reads": 0,
        "new_position_verdict": "",
        "method_present": session.method_present,
    }
    if session.new_position is not None:
        result["new_position_verdict"] = (
            session.new_position.get("judgement", {}).get("verdict", "")
        )
    if not session.new_position_prestate:
        return result
    question = next(
        (item for item in session.human_questions if item["stage"] == "new_position"),
        None,
    )
    if question is None:
        return result
    runtime = participant.runtime
    acts = [act for values in runtime.threads.values() for act in values]
    broker_questions = {
        act.act_id
        for act in acts
        if act.kind == "question" and act.reply_to == question["act_id"]
    }
    handler = next(
        (
            act
            for act in acts
            if act.kind == "answer" and act.reply_to in broker_questions
        ),
        None,
    )
    handler_id = handler.sender if handler is not None else ""
    result["new_position_handler"] = handler_id
    if handler_id in runtime.actors:
        result["new_position_created"] = bool(
            runtime.actors[handler_id].spec.created_by
            and runtime.actors[handler_id].spec.created_by != "initialization"
        )
    method_id = session.new_position_prestate.get("method", "")
    prestate_ids = {
        key: value
        for key, value in session.new_position_prestate.items()
        if value and key not in {"method"}
    }
    paths: set[str] = set()
    for event in participant.recorder.events:
        if (
            event.get("kind") != "core.tool_end"
            or event.get("actor_id") != handler_id
            or event.get("tool") != "world_references_from"
            or not event.get("ok")
        ):
            continue
        result["new_position_reads"] += 1
        text = json.dumps(event.get("value") or {}, ensure_ascii=False)
        if method_id and method_id in text:
            result["method_found"] = True
        for key, object_id in prestate_ids.items():
            if object_id in text:
                paths.add(key)
    result["new_position_path_reads"] = sorted(paths)
    return result


def result_summary(
    session: SafetyReviewSession,
    participant: Participant,
    recorder: Recorder,
    *,
    error: str,
    wall_seconds: float,
) -> dict:
    metrics = mechanism_metrics(participant, session)
    return {
        "status": session.status(),
        "outcome": session.outcome,
        "branches": session.branches,
        "directives": [
            {
                "phase": item["phase"],
                "act_id": item["act_id"],
                "content": item["content"],
                "judgement": item["judgement"],
                "branch": item.get("branch", ""),
            }
            for item in session.directives
        ],
        "responses": session.responses,
        "human_questions": session.human_questions,
        "review": session.review,
        "case_two": session.case_two,
        "compliance": session.compliance,
        "repair": session.repair,
        "recheck": session.recheck,
        "closure": session.closure,
        "closure_office": session.closure_office,
        "revision": session.revision,
        "identity_check": session.identity_check,
        "identity_two": session.identity_two,
        "new_position": session.new_position,
        "reuse_check": session.reuse_check,
        "reuse_office": session.reuse_office,
        "reuse_recheck": session.reuse_recheck,
        "reuse_prestate": session.reuse_prestate,
        "process_submit": session.process_submit,
        "process_check": session.process_check,
        "process_prestate": session.process_prestate,
        "propagation_check": session.propagation_check,
        "propagation_prestate": session.propagation_prestate,
        "author_revision": session.author_revision,
        "author_check": session.author_check,
        "author_prestate": session.author_prestate,
        "flip_check": session.flip_check,
        "flip_prestate": session.flip_prestate,
        "dispute_office": session.dispute_office,
        "dispute_recheck": session.dispute_recheck,
        "dispute_prestate": session.dispute_prestate,
        "use_gap_check": session.use_gap_check,
        "fact_finding": session.fact_finding,
        "fact_consequence": session.fact_consequence,
        "fact_revision": session.fact_revision,
        "use_gap_office": session.use_gap_office,
        "use_gap_recheck": session.use_gap_recheck,
        "use_gap_prestate": session.use_gap_prestate,
        "mechanisms": metrics,
        "usage": recorder.usage(),
        "wall_seconds": wall_seconds,
        "simulated_hours": session.clock_hours,
        "stop_reason": session.stop_reason,
        "error": error,
    }


async def smoke(args, directory: Path) -> None:
    recorder = Recorder(directory)
    session = SafetyReviewSession(
        recorder,
        enable_review=args.review_independent,
        enable_case_two=args.case_two,
        enable_compliance=args.compliance,
        enable_compliance_repair=args.repair,
        enable_closure=args.closure,
        enable_revision_probe=args.revision_probe,
        enable_identity_probe=args.identity_probe,
        identity_with_revision=not args.identity_pristine,
        identity_structure=args.identity_structure,
        enable_two_case_probe=args.two_case_probe,
        enable_new_position_probe=args.new_position_probe,
        enable_reuse_probe=args.reuse_probe,
        enable_process_probe=args.process_probe,
        process_self_report=args.process_self_report,
        dynamic_record_present=args.dynamic_record,
        method_present=not args.no_method,
        ablation="" if args.ablate == "none" else args.ablate,
        soft_repair=args.soft_repair,
        strict_compliance=args.strict_compliance,
        enable_full_chain=args.full_chain,
        reproducible_check=args.reproducible_check,
        enable_propagation_probe=args.propagation_probe,
        criterion_structure=args.criterion_structure,
        enable_author_probe=args.author_probe,
        enable_flip_probe=args.flip_probe,
        enable_dispute_probe=args.dispute_probe,
        enable_use_gap_probe=args.use_gap_probe,
        e34_variant=args.e34_variant,
        enable_cross_org_probe=args.cross_org_probe,
        enable_cross_org_complete=args.e36_complete,
        enable_fact_probe=args.fact_probe,
        enable_fact_revision=args.e38_revision,
        enable_e39_provenance=args.e39_provenance,
        enable_e41_anchor_link=args.e41_anchor_link,
    )
    participant = Participant(
        session,
        recorder,
        model_port=ScriptedModel(script(), auto_yield=False),
        initial_actors=declarations(
            include_facility=(
                args.compliance
                or args.identity_probe
                or args.two_case_probe
                or args.new_position_probe
                or args.reuse_probe
                or args.process_probe
                or args.propagation_probe
                or args.author_probe
                or args.flip_probe
                or args.dispute_probe
                or args.use_gap_probe
                or args.cross_org_probe
                or args.fact_probe
            )
        ),
    )
    session.bind(participant.runtime)
    started = time.perf_counter()
    error = ""
    try:
        await asyncio.wait_for(participant.run(), timeout=args.wall_limit)
    except Exception as exc:  # keep the artifact even on failure
        error = f"{type(exc).__name__}: {exc}"
    result = result_summary(
        session,
        participant,
        recorder,
        error=error,
        wall_seconds=time.perf_counter() - started,
    )
    save_json(directory / "manifest.json", manifest("smoke", args, session))
    save_json(directory / "result.json", result)
    save_json(
        directory / "public-acts.json",
        [
            asdict(act) if hasattr(act, "__dataclass_fields__") else act
            for values in participant.runtime.threads.values()
            for act in values
        ],
    )
    save_json(directory / "core-snapshot.json", participant.runtime.snapshot())
    print(json.dumps(result["status"], ensure_ascii=False), flush=True)


async def live(args, directory: Path) -> None:
    recorder = Recorder(directory)
    session = SafetyReviewSession(
        recorder,
        enable_review=args.review_independent,
        enable_case_two=args.case_two,
        enable_compliance=args.compliance,
        enable_compliance_repair=args.repair,
        enable_closure=args.closure,
        enable_revision_probe=args.revision_probe,
        enable_identity_probe=args.identity_probe,
        identity_with_revision=not args.identity_pristine,
        identity_structure=args.identity_structure,
        enable_two_case_probe=args.two_case_probe,
        enable_new_position_probe=args.new_position_probe,
        enable_reuse_probe=args.reuse_probe,
        enable_process_probe=args.process_probe,
        process_self_report=args.process_self_report,
        dynamic_record_present=args.dynamic_record,
        method_present=not args.no_method,
        ablation="" if args.ablate == "none" else args.ablate,
        soft_repair=args.soft_repair,
        strict_compliance=args.strict_compliance,
        enable_full_chain=args.full_chain,
        reproducible_check=args.reproducible_check,
        enable_propagation_probe=args.propagation_probe,
        criterion_structure=args.criterion_structure,
        enable_author_probe=args.author_probe,
        enable_flip_probe=args.flip_probe,
        enable_dispute_probe=args.dispute_probe,
        enable_use_gap_probe=args.use_gap_probe,
        e34_variant=args.e34_variant,
        enable_cross_org_probe=args.cross_org_probe,
        enable_cross_org_complete=args.e36_complete,
        enable_fact_probe=args.fact_probe,
        enable_fact_revision=args.e38_revision,
        enable_e39_provenance=args.e39_provenance,
        enable_e41_anchor_link=args.e41_anchor_link,
        max_requests=args.max_requests,
        max_tokens=args.token_limit,
    )
    model = os.environ.get("DEEPSEEK_MODEL", "deepseek-flash")
    base_url = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
    manifest_value = manifest("live", args, session)
    manifest_value.update(
        {
            "model": model,
            "base_url": base_url,
            "thinking": "enabled",
            "purpose": (
                "E1 live run: whether the office can form a load-bearing "
                "cross-position judgment and revise it after the facility's "
                "response exists."
            ),
            "human_interventions": "None after launch.",
        }
    )
    save_json(directory / "manifest.json", manifest_value)
    if not os.environ.get("DEEPSEEK_API_KEY"):
        raise RuntimeError("DEEPSEEK_API_KEY is required for a live run")
    judge = LLMJudge(None, model, max_tokens=args.judge_tokens)
    started = time.perf_counter()
    error = ""
    async with AsyncOpenAI(
        api_key=os.environ["DEEPSEEK_API_KEY"],
        base_url=base_url,
        max_retries=0,
        timeout=180,
    ) as client:
        judge.client = client
        session.judge = judge
        participant = Participant(
            session,
            recorder,
            client=client,
            model=model,
            max_tokens=args.max_output_tokens,
            max_rounds=None,
            initial_actors=declarations(
                include_facility=(
                    args.compliance
                    or args.identity_probe
                    or args.two_case_probe
                    or args.new_position_probe
                    or args.reuse_probe
                    or args.process_probe
                    or args.propagation_probe
                    or args.author_probe
                    or args.flip_probe
                    or args.dispute_probe
                    or args.use_gap_probe
                    or args.cross_org_probe
                    or args.fact_probe
                )
            ),
        )
        session.bind(participant.runtime)
        try:
            await asyncio.wait_for(participant.run(), timeout=args.wall_limit)
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
            if not session.stopped:
                session._stop("runner_error")
        result = result_summary(
            session,
            participant,
            recorder,
            error=error,
            wall_seconds=time.perf_counter() - started,
        )
        result["judge"] = judge.summary()
        result["judge_records"] = judge.records
        save_json(directory / "result.json", result)
        save_json(
            directory / "public-acts.json",
            [
                asdict(act) if hasattr(act, "__dataclass_fields__") else act
                for values in participant.runtime.threads.values()
                for act in values
            ],
        )
        save_json(directory / "core-snapshot.json", participant.runtime.snapshot())
        print(json.dumps(result["status"], ensure_ascii=False), flush=True)


def manifest(mode: str, args, session: SafetyReviewSession) -> dict:
    return {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "kind": f"safety_review_{mode}",
        "mode": mode,
        "arguments": vars(args),
        "scope": session.scope,
        "case": CASE_TITLE,
        "object_keys": session.objects,
        "reference_keys": session.references,
        "document_sha256": {
            key: hashlib.sha256(value.encode("utf-8")).hexdigest()
            for key, value in DOCUMENTS.items()
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("calibrate", "smoke", "live"))
    parser.add_argument("--name", required=True)
    parser.add_argument("--max-requests", type=int, default=320)
    parser.add_argument("--token-limit", type=int, default=16_000_000)
    parser.add_argument("--max-output-tokens", type=int, default=16384)
    parser.add_argument("--judge-tokens", type=int, default=8192)
    parser.add_argument("--wall-limit", type=int, default=3600)
    parser.add_argument("--review-independent", action="store_true")
    parser.add_argument("--case-two", action="store_true")
    parser.add_argument("--compliance", action="store_true")
    parser.add_argument("--repair", action="store_true")
    parser.add_argument("--closure", action="store_true")
    parser.add_argument("--revision-probe", action="store_true")
    parser.add_argument("--identity-probe", action="store_true")
    parser.add_argument("--identity-pristine", action="store_true")
    parser.add_argument(
        "--identity-structure",
        choices=("update", "case", "supplement"),
        default="update",
    )
    parser.add_argument("--two-case-probe", action="store_true")
    parser.add_argument("--new-position-probe", action="store_true")
    parser.add_argument("--reuse-probe", action="store_true")
    parser.add_argument("--process-probe", action="store_true")
    parser.add_argument("--process-self-report", action="store_true")
    parser.add_argument("--dynamic-record", action="store_true")
    parser.add_argument(
        "--ablate",
        choices=("none", "anomaly", "trigger", "both"),
        default="none",
        help=(
            "反事实消融：anomaly = 移除异常迹象材料（E19/E20）；"
            "trigger = 移除标准 5.3 的异常触发条款（E22）；both = 两者"
        ),
    )
    parser.add_argument(
        "--soft-repair",
        action="store_true",
        help="P0 续：repair 问题只报缺口，不规定修法（E20）",
    )
    parser.add_argument(
        "--strict-compliance",
        action="store_true",
        help="E24：核对结论用于责任认定，须核对办公室自己的处置条件",
    )
    parser.add_argument(
        "--full-chain",
        action="store_true",
        help="E25：把 判据写入→跨案件复用→过程证据→独立核对 串成一条链",
    )
    parser.add_argument(
        "--reproducible-check",
        action="store_true",
        help="E26：核对结论须可由未接触其他案件材料的位置复现（结果约束）",
    )
    parser.add_argument(
        "--propagation-probe",
        action="store_true",
        help="E27：跨案件判据修订的传播探针（副本 vs 同一身份）",
    )
    parser.add_argument(
        "--criterion-structure",
        choices=("identity", "copy"),
        default="identity",
    )
    parser.add_argument(
        "--author-probe",
        action="store_true",
        help="E28：办公室自己发起判据修订（作者侧）",
    )
    parser.add_argument(
        "--flip-probe",
        action="store_true",
        help="E30：修订使旧案闭合失效的传播探针",
    )
    parser.add_argument(
        "--dispute-probe",
        action="store_true",
        help="E32：陈旧结论已被使用 → 争议暴露修订 → 是否回溯修正",
    )
    parser.add_argument(
        "--use-gap-probe",
        action="store_true",
        help="E33：由只能读记录的位置报告核对失败，逼出办公室写入",
    )
    parser.add_argument(
        "--e34-variant",
        choices=("", "clause", "identity"),
        default="",
        help="E34：clause = 修订版带显式适用条款；identity = 兼用同一身份判据引用",
    )
    parser.add_argument(
        "--cross-org-probe",
        action="store_true",
        help="E35：升温观察材料只在设施方；办公室能否自行建立跨组织联系",
    )
    parser.add_argument(
        "--e36-complete",
        action="store_true",
        help="E36：补全办公室 (a) 路径并公开异常判据，让跨组织材料成为决定变量",
    )
    parser.add_argument(
        "--fact-probe",
        action="store_true",
        help="E37：事实查明任务；必须给出是/否认定且不得以材料不足收尾",
    )
    parser.add_argument(
        "--e38-revision",
        action="store_true",
        help="E38：无依据认定 → 事故后果 → 调查带回记录 → 要求修订",
    )
    parser.add_argument(
        "--e39-provenance",
        action="store_true",
        help="E39：调查只说明原件由设施方保存；修订须以原始记录为依据",
    )
    parser.add_argument(
        "--e41-anchor-link",
        action="store_true",
        help="E41：调查说明补充“原件与案件 EV-0915 属同一次升温事件”的世界事实",
    )
    parser.add_argument("--no-method", action="store_true")
    args = parser.parse_args()
    if Path(args.name).name != args.name:
        parser.error("name must be one directory component")
    if args.e36_complete and not args.cross_org_probe:
        parser.error("--e36-complete requires --cross-org-probe")
    if args.e38_revision and not args.fact_probe:
        parser.error("--e38-revision requires --fact-probe")
    if args.e39_provenance and not args.e38_revision:
        parser.error("--e39-provenance requires --e38-revision")
    if args.e41_anchor_link and not args.e39_provenance:
        parser.error("--e41-anchor-link requires --e39-provenance")
    directory = HERE / "runs" / args.name
    directory.mkdir(parents=True, exist_ok=False)
    if args.mode == "calibrate":
        report = calibration_report()
        save_json(directory / "manifest.json", {"kind": "safety_review_calibrate"})
        save_json(directory / "calibration.json", report)
        print(json.dumps(report["checks"], ensure_ascii=False, indent=2))
    elif args.mode == "smoke":
        freeze_sources(directory)
        asyncio.run(smoke(args, directory))
    else:
        freeze_sources(directory)
        asyncio.run(live(args, directory))


if __name__ == "__main__":
    main()
